#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Friday Feb 21 18:38:58 2020

@author: shuxin.jin@hotmail.com
"""

import datetime
import calendar
#### import arrow
import pandas as pd
import numpy as np
import os
# for get the user id in session
from flask import session

#import pymysql
import pymysql
#converting to csv
import codecs
import csv
#scoring
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import spacy
from absl.logging import exception
sid = SentimentIntensityAnalyzer()

from nltk.tokenize import sent_tokenize

#import summary
from nltk_summarization import nltk_summarizer
from gensim.summarization import summarize
from spacy_summarization import text_summarizer
from sumy.parsers.plaintext import PlaintextParser
from sumy.summarizers.lex_rank import LexRankSummarizer
from spacy.lang.en import English
from sumy.nlp.tokenizers import Tokenizer
nlp2 = spacy.load('ja_ginza')
#database connection 
from sqlalchemy import create_engine

import logging
logger = logging.getLogger(__name__)

#japanese
#from nltk.translate import bleu
from asari.api import Sonar
sonar = Sonar()
#sonar = None
#author info
__author__  = "Shuxin Jin <shuxin.jin@hotmail.com>"
__status__  = "beta"
__version__ = "0.0.1"
__date__    = "18 Feb 2020"

A1= 'FromDB'
A2= 'FromCSV'
#fetch type
_data_f_type=A1

#re train flag
_train_flag = True
#language type,true is japanese, false is english
_lan_flg=False
#main content field name
_main_field_name = 'Article'
# path user data
_data_path1='user_data'

# path csv
_data_path2='csv'

#Database connection ,secret,keep it well 
DB_URL ='mysql+pymysql://admin:milize01@database-fg.cid1rmspjxuq.ap-northeast-1.rds.amazonaws.com:3306/moneyImpact?charset=utf8'
_list_cols_train_o = ['News_English_id',   'Article_nltk_sum', 'Article_spacy_sum','Article_gensim_sum','Article_sumy_sum',  'Article_positive', 'Article_negative', 'Article_neutral', 'Article_compound', 'Title_positive', 'Title_negative', 'Title_neutral', 'Title_compound'] 
#moneyimpact defination
_list_cols_train = ['news_id',   'article_nltk_sum', 'article_spacy_sum','article_gensim_sum','article_sumy_sum',  'article_positive', 'article_negative', 'article_neutral', 'article_compound', 'title_positive', 'title_negative', 'title_neutral', 'title_compound'] 






#detail page
_list_cols1 = ['Category', 'Source', 'Author','Link', 'Date', 'Title', 'Article_nltk_sum', 'Article', 'Article_positive', 'Article_negative', 'Article_neutral', 'Article_compound', 'Title_positive', 'Title_negative', 'Title_neutral', 'Title_compound']
_list_cols2 = ['Category', 'Source', 'Author','Link', 'Date', 'Title', 'Article_spacy_sum', 'Article', 'Article_positive', 'Article_negative', 'Article_neutral', 'Article_compound', 'Title_positive', 'Title_negative', 'Title_neutral', 'Title_compound']
_list_cols3 = ['Category', 'Source', 'Author','Link', 'Date', 'Title', 'Article_gensim_sum', 'Article', 'Article_positive', 'Article_negative', 'Article_neutral', 'Article_compound', 'Title_positive', 'Title_negative', 'Title_neutral', 'Title_compound']
_list_cols4 = ['Category', 'Source', 'Author','Link', 'Date', 'Title', 'Article_sumy_sum', 'Article', 'Article_positive', 'Article_negative', 'Article_neutral', 'Article_compound', 'Title_positive', 'Title_negative', 'Title_neutral', 'Title_compound']


#list page,English csv_index list
_list_cols_h1 = ['Category', 'Author','Link', 'Date', 'Title', 'Article_nltk_sum',  'Article_compound', 'Title_compound','News_English_id']
_list_cols_h2 = ['Category', 'Author','Link', 'Date', 'Title', 'Article_spacy_sum',  'Article_compound', 'Title_compound','News_English_id']
_list_cols_h3 = ['Category', 'Author','Link', 'Date', 'Title', 'Article_gensim_sum',  'Article_compound', 'Title_compound','News_English_id']
_list_cols_h4 = ['Category', 'Author','Link', 'Date', 'Title', 'Article_sumy_sum',  'Article_compound', 'Title_compound','News_English_id']


#Japanese and Chinese,csv_index list records
_list_cols_h1_jp = ['Category', 'Author','Link', 'Date', 'Title', 'Article_nltk_sum',  'Article_positive', 'Title_positive','News_English_id']
_list_cols_h2_jp = ['Category', 'Author','Link', 'Date', 'Title', 'Article_spacy_sum',  'Article_positive', 'Title_positive','News_English_id']
_list_cols_h3_jp = ['Category', 'Author','Link', 'Date', 'Title', 'Article_gensim_sum',  'Article_positive', 'Title_positive','News_English_id']
_list_cols_h4_jp = ['Category', 'Author','Link', 'Date', 'Title', 'Article_sumy_sum',  'Article_positive', 'Title_positive','News_English_id']
# ['Category', 'Date', 'Author','Link', 'Title','Article_compound','Title_compound', 'Source','edit_flag','del_flag','News_English_id']

#the precision number ,
vip_n =4
#
_db_url = 'database-fg.cid1rmspjxuq.ap-northeast-1.rds.amazonaws.com'
#_news_sql='select News_English_id,Category,Source,Link,Date,Author,Title,Article FROM News_English'
_news_flds=['News_English_id','Category','Source','Link','Date','Author','Title','Article']


#pd.set_option('precision',vip_n)
np.set_printoptions(precision=vip_n)
np.set_printoptions(suppress=True) # remove the e-....
pd.set_option('display.float_format', lambda x: '%.5f' % x) #---为了直观的显示数字，不采用科学计数法

#the crawler max number scraping from goog news
News_scrape_max=500



###the MAIN data fetching method ,return a dataframe
def fetchDA(lang,startn,totaln):
    filep1 = './'+_data_path1+'/'+_data_path2+'/'+lang+'_scraping_news.csv'
    try:
        retrain,df5 = mysql_to_csv(filep1,lang )
        # if true,it is train again just now.
        if retrain:

            print('begin to rewrite the training into  csv file and database records of :')
            #update the newest records with NLP summary and scoring
            analyzeCSV(df5,filep1,lang)
                       
            ############# read from database
            try:
                return doconn(lang,0,1000,None)
            except Exception as e:
                print(str(e))

                return None
        #if return false,means not re-train again
        else:
            ###### BE INTERT DB Fetching ####### read from database
            try:
                return doconn(lang,0,1000,None)
            except Exception as e:
                print(str(e))
                #'which file you want ?'
                return None
    #some issues if reading local csv or database exception
    except Exception as e:
        print(str(e))
        dfa = None #pd.read_csv(filep1.split('.csv')[0]+'_sentiment_bk.csv',encoding='utf-8') 
        print('database operating and normal csv reading failed,will with the backup csv file  ')
        #return the dataframe
        return dfa



#the  dataframe fetching method for special Category ,single Category,be called by 
def fetchCategory(com_name,lang):
    ###### BE INTERT DB Fetching ####### read from database
    com_name=str(com_name).strip()
    try:
        engine =get_conn()
        df5 = None
    
        #connect to db, and this mode can run with or without database 
        pre_sql=''

        if not (session['logged_in']):
            return redirect('/login',ee='login firstly,please.')
        if lang=='China':
            com_sql2 ='select * from News_CH a right join scr_ch b on a.News_English_id =b.News_English_id where b.del_flag !=True '+' and a.Category in (\''+com_name+'\')'
        #language is japanese
        elif lang=='Japan':
                    com_sql2 ='select * from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True '+' and a.Category in (\''+com_name+'\')'
        #english
        else:
            com_sql2 ='select * from News_English a right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True '+' and a.Category in (\''+com_name+'\')'
            #print(str(com_sql2))
        df5 = pd.read_sql_query(com_sql2, engine)
        print(' WITH THE single Category TO SHOW TO CUSTOMER')
        return df5 
    
    #if failed, with the backup file
    except:
        #read the backup csv file
        filep=_common_file
        #'which file you want ?'
        return indexCSV(filep)


#abstract    return the dataframe with the database table . PUBLIC PART
def inner_conn():
    #get the filter
    engine =get_conn()
    df5 = None
    
    # get_prefer

    #connect to db, and this mode can run with or without database 
    pre_sql=''
    #try:
    if  (session['logged_in']):
        #user name getout
        email1= session['email'] 
        
        data_df1 = None
        usr_id=-999
      
        com_sql2=''
        com_sql2 ='select  * from  user  where email=\''+email1+'\''
  
        data_df1 = pd.read_sql_query(com_sql2, engine)
    
        #get the user id
        usr_id= str(data_df1['id'][0] )
        
        #checking the prefer os this user
        com_sql2 ='select  distinct(Category) from  usr_pref  where prefer_id='+usr_id
        #print(com_sql2)
        data_df1 = pd.read_sql_query(com_sql2, engine)
        if len(data_df1)<1:
            return ''
#         cc=data_df1['Category'].tolist()
#         hh =data_df1['Category'].values.tolist()
#         kk = tuple(data_df1.itertuples(index=False, name=None))
        complist = tuple (data_df1['Category'].values.tolist() )
        
        #tuple 
        print(str(complist))
        #print("limit 1000 is a temp limit,need to improve the paging function to a more complicated")
        pre_sql = ' and a.Category not in '+str(complist) 
        print( pre_sql[-2:-1] )
        if( pre_sql[-2:-1] ) ==',':
            pre_sql =pre_sql[:-2]+')'
            print(pre_sql)
        print( 'get the prefered Category list,will filter the result' )
        #list all Category into one list and connect them
        
        
    else:
        pre_sql=''
        print( 'not get the prefered Category list,not filter the result' )
    return pre_sql   
#connect        ,startn is the start position in beginning, and totaln is the total number of records you want,will be set in the sql sentence
def doconn(lang,startn,totaln,idx):
    pre_sql =inner_conn()
    engine =get_conn()
    if idx is not None:
        #del_flag  this record had been filter by user
        if lang =='Japan':
            com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True'+pre_sql+' and b.News_English_id ='+str(idx)
        #Chinese
        elif lang =='China':
            com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_CH a right join scr_ch b on a.News_English_id =b.News_English_id where b.del_flag !=True'+pre_sql+' and b.News_English_id ='+str(idx)
        #English news
        else:
            com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True'+pre_sql+' and b.News_English_id ='+str(idx)
        
    else:

        #del_flag  this record had been filter by user
        if lang =='Japan':
            com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True'+pre_sql+' limit '+str(startn)+','+str(totaln)
        #Chinese
        elif lang =='China':
            com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_CH a right join scr_ch b on a.News_English_id =b.News_English_id where b.del_flag !=True'+pre_sql+' limit '+str(startn)+','+str(totaln)
        #English news
        else:
            com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True'+pre_sql+' limit '+str(startn)+','+str(totaln)
    #print(com_sql2)
    #         df8 = pd.read_sql_query('select * from News_English', engine)
    #         df8.set_index(["News_English_id"], inplace=True)
    #         df8.to_csv('english_news.csv', mode='a', header=False, line_terminator="\n", encoding='utf-8')  
            
        #print(com_sql2)
    df5 = pd.read_sql_query(com_sql2, engine)
    #return df5
    #need to optimize the pagig function in future ,only get the last 1000 records as a demo now
#     print('this is a temp filter of head 1000,pls MODIFY it with a new paging method')
#     df5 = df5.head(1000)
    return df5


#connect
def get_conn():
    #Connect to database ,_db_url,port,usr,passwd,dbtbl   
    engine = create_engine(DB_URL)
    return engine




#insert training result into database table
def up_data(df4,tbl_name):
    try:
        engine =get_conn()
    #             - fail: If table exists, do nothing.
    #             - replace: If table exists, drop it, recreate it, and insert data.
    #             - append: If table exists, insert data. Create if does not exist.
        df4.to_sql(tbl_name, engine, if_exists='append', index= False)
        print("Write to MySQL successfully!")
        return True
    except Exception as e:
        print(str(e))
        print("Write to MySQL failed!")
        return False
   


#define one read api function
def indexCSV(filep):
    print('read sentiment analysis result to csv_index page ')

    #filepp = BASE_PATH+'\\'+_data_path1+'\\'+_data_path2+'\\'+filep
    #windows os
    #filepp = '.'+'\\'+_data_path1+'\\'+_data_path2+'\\'+filep
    #linux op
    filepp = './'+_data_path1+'/'+_data_path2+'/'+filep
    print(filepp)
    try:
        df = pd.read_csv(filepp)  
    except:
        if _train_flag:
            sent_trn_csv('notusenow')
            df = pd.read_csv(filepp)
        else:
            print("you lost the training output file of csv,and the retrain flag not be set as open in config file")  
            return None
    #cols = list(df.columns.str.lower() )
      
    #print(cols)
#     # for index,row in otu.iterrows():
#     for date, data in df.iterrows():
#         print('abc')
    #['unnamed: 0', 'Category', 'source', 'link', 'date', 'title', 'article', 'article_positive', 'article_negative', 'article_neutral', 'article_compound', 'title_positive', 'title_negative', 'title_neutral', 'title_compound']    
    print( 'ready return to front page')
    #print(df['Category'])
    return df

#daily update records for News_JP,fetch data from web_news
def webnews_to_newsjp(lang,dtime ):
    #connect to db, and this mode can run with or without database 
    try:
        engine =get_conn()
        df5 = None
        if lang =='Japan':
            com_sql2 ='select last_update,last_update_tbl from upt_record order by last_update;'
        #English news
        else:
            #nnot update
            return False,None
        try:
            df2 = pd.read_sql_query(com_sql2, engine)
            lupdate = df2['last_update'][0]
            print(str( lupdate))
            com_sql1 ='select NEWS_URL as Link,NEWS_SITE as Source,NEWS_DATE as Date,NEWS_TITLE as Title,NEWS_DETAILS as Article,from web_news where NEWS_UPDATE>'+str(lupdate)+' ;'
        #take as this table not exist
        except Exception as e:
            #perhaps later will pass it,not rewrite
            print( 'Failed when read data from upt_record table :,'+str(e) )
            return False,None
        df1 = pd.read_sql_query(com_sql1, engine)  
        #before save to db table, some dataframe processing
        print(df1.columns)  
        print(df1.head(10))
        #save the news data into "News_JP"
        if up_data(df1,'News_JP'):
            print( 'Succ update data from web_news to News_JP' )
            #return Ture enough
            return True,None
        else:
            print( 'Fail update data from web_news to News_JP' )
            return False,None
    except Exception as e:
        print( 'Failed update data from web_news to News_JP:,'+str(e) )
        #should running with local csv supporting,not care the database.
        return True,None





#save json file to DB
def json_to_db(tbl_name,link,link_datetime,full_title,content,source):
    full_title = full_title.replace("'", "")
    content = content.replace("'", "")
    engine =get_conn()
    
    com_sql2=''
#     valuess='VALUES (\'{}\',\'{}\',\'%s\',\'%s\',\'{}\')'.format(link,link_datetime,full_title,content,source )
#     com_sql2 ='insert into '+tbl_name+' (Link,Date,Title,Article,Source) '+valuess
    com_sql2 =""" insert into %s (Link,Date,Title,Article,Source) VALUES ('%s','%s','%s','%s','%s') """ % (tbl_name,link,link_datetime,pymysql.escape_string(full_title),pymysql.escape_string(content),source )
    com_sql1=''
    com_sql1='select * from {} where link= \'{}\''.format(tbl_name,pymysql.escape_string(link))
    
    #print(com_sql2)
    try:
        dd=pd.read_sql_query(com_sql1, engine)
        if len(dd)<1:
            dd=pd.read_sql_query(com_sql2, engine)
        else:
            #same title ,same link
            com_sql1='select * from {} where Title= \'{}\''.format(tbl_name,pymysql.escape_string(full_title))
            dd=pd.read_sql_query(com_sql1, engine)
            if len(dd)<1:
                print('news save to db')
                dd=pd.read_sql_query(com_sql2, engine)
            else:
                logger.error("news data duplication,discard it")
                return False
        #return True
    except Exception as e:
        print(str(e))
        logger.error("This DB error caused by thread session,it should not be used like this."+e)
        return False
    return True   
   
#Train one time if not have this file
def sent_trn_csv(file):
    analyzeCSV(None,file,None)
#     print(" to generate sentiment file.")
#     list_files = os.listdir( os.path.join(BASE_PATH,_data_path1,_data_path2) )
#     for i,csvj in enumerate(list_files):
#         print(str(i)+' - ' + csvj)
#         #append just .csv part later
#         tempp = os.path.join(BASE_PATH,_data_path1,_data_path2,csvj)
#         analyzeCSV(tempp)
#         print('sentiment analysis done by nltk')
        
    
    return True


# Sumy , https://qiita.com/hideki/items/5e9892094ae786d2ad6c
# Sumy
def sumy_summary(docx,lang):
    lex_summarizer = LexRankSummarizer()
    
    if lang =='English':
        parser = PlaintextParser.from_string(docx, Tokenizer("english"))
    #Japanese NLP,NOT SUPPORT Chinese now,not begin coding of CH
    else:
        # nlp8 = spacy.load('ja_ginza_nopn')
        corpus = []
        originals = []
        doc = nlp2(docx)
        for s in doc.sents:
            originals.append(s)
            tokens = []
            for t in s:
                tokens.append(t.lemma_)
            corpus.append(' '.join(tokens))
        
        
        # 連結したcorpusを再度tinysegmenterでトークナイズさせる
        parser = PlaintextParser.from_string(''.join(corpus), Tokenizer('japanese'))
        lex_summarizer.stop_words = [' ']  # スペースも1単語として認識されるため、ストップワードにすることで除外する
        
    # sentencres_countに要約後の文の数を指定します。
    summary = lex_summarizer(parser.document, 3)
    summary_list = [str(sentence) for sentence in summary]
    result = ' '.join(summary_list)
    return result


####csv ,news prefer setting configure file, operator
en_user_file= '/en_news_like.csv'
jp_user_file= '/jp_news_like.csv'
#news label definatin, CSV fields.

label_news_like=["name"]

def read_csv(filen):
    stories = []
    try:
        with open(filen, "r",encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                #remove the blank row
                if  len(row):
                    stories.append(row)
                else:
                    pass
        csvfile.close()
    except Exception as e:
        print(filen+str(e))
        
    return stories


def append_csv(story,filen):
    with open(filen, "a",encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(story)

    csvfile.close()

def write_csv(stories,filen):
    with open(filen, "w",encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        for story in stories:
            #remove the blank row
            if  len(story):
                writer.writerow(story)
            else:
                pass
    csvfile.close()

def edit_csv(stories, new_story,filen):
    with open(filen, "w",encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        for story in stories:
            if not len(story):
                pass
            else:
                if story[0] == new_story[0]:
                    writer.writerow(new_story)
                    continue
                writer.writerow(story)
    csvfile.close()



########################### money impact #############

######################################################
#base paras
moneyi_news_scr_tbl=['nw_scores','othersnewsScoreNameNeeded']

news_field_index='news_id'

#japanese scoring function
def score_jp(Article):  
    try:
        res=sonar.ping(text=str(Article))
        #print(str(res ) )
        #print(res.get('classes') )
        rell = res.get('classes')
        #print(rell[1].get('confidence'))
        sent = {'neg': 0.0, 'neu': 0.0, 'pos': 0.0, 'compound': 0.0}
    #         pos = []
    #         neg = []
    #         com = []
    #         neu = []
        #positive
        sent['pos']= res.get('classes')[1].get('confidence')
        sent['neg']= res.get('classes')[0].get('confidence')
    
        #print(str(sent))
        return sent 
    except Exception as e:
        return {'neg': 0.0, 'neu': 0.0, 'pos': 0.0, 'compound': 0.0}



#compare 2 tables ,check whether the newest records,if not return false
def compare_tbl():
    #connect to db, and this mode can run with or without database 
    try:
        engine =get_conn()
        df5 = None

        com_sql1 =' select max(news_id) as id1  from moneyImpact.nw_news where category_id is not null '
        com_sql2 =' select max(news_id) as id2  from moneyImpact.nw_scores '
        
        try:

            df2 = pd.read_sql_query(com_sql2, engine)
            #because it max( ) function, so only one value here
            id2 = df2.iloc[0, 0]   
            #print( df2['id2'][0])
            #print( df2['id2'][:-1])
        
        #take as this table not exist
        except:
            #perhaps later will pass it,not rewrite
            print('not find table of score or any records in this table,will cover it.')
            id2=0
        if id2 is None:
            id2=0
        if id2<1:
            id2=0
        df1 = pd.read_sql_query(com_sql1, engine)    
        #None values in News table,will none be show
        if (df1.iloc[0, 0]) is None:
            return True,None
        #print(str(df1['id1'][0]) )
        
        #print( str(df1.iloc[0, 0]) )

     
        if int(df1.iloc[0, 0]) ==int(id2):
            print('already the newest news records,will not nlp train again.Last news id:'+str(id2) )
            return True,df1
        else:
            com_sql2 ='select *  from  moneyImpact.nw_news where news_id >{} and  category_id is not null limit 200 '.format(id2)
            print(com_sql2)
            df5 = pd.read_sql_query(com_sql2, engine)
            return False,df5
    except Exception as e:
        print('1r1:'+str(e))
        #should running with local csv supporting,not care the database.
        return True,None
    
# 
#original: def mysql_to_csv(filen,lang):
#lang keep for future english news
def process_bef_train(lang):
    #compare_tbl if true, means no difference in datetime
    newest,df5 = compare_tbl()
    #newest,df5 = False,None
    #not the newest  scoring ,need scoring and suammary again to the new records.
    if not newest and len(df5)>0:
        df5.columns=df5.columns.str.lower()
        print('not the newest news training result,begin nlp train again now...')
        #clean the data
        df5['title'] = df5['title'].str.strip()
        #keep inconsistent between the 2 files and db
        #the 50 limits is for testing, will run it in the server
        return True,df5
    else:
        #false means not need retrain again for the  data
        return False,None  
    


#File analysis with score,Englishi score, Japanese score, Chinese score
#have to with some true field name in it,will change it later
def analyzeCSV(df,file,lang):
    #df=df.head(10)
    df.columns=df.columns.str.lower()
    print(df.columns)
    cols = list(df.columns )
    #re.sub('[\n]+', '\n', 'dfadf   d\n \n\n \nfa  ds ')
    #print(cols)
    for col in cols:
        if 'article' in cols:
            pref = 'article'
            cols.remove('article')
        elif 'title' in cols:
            pref = 'title'
            cols.remove('title')
        else:
            continue
        sent = {}
        pos = []
        neg = []
        com = []
        neu = []
        summary1=[]
        summary2=[]
        summary3=[]
        summary4=[]
        final_summary_gensim=''
        final_summary_spacy=''
        final_summary_nltk=''
        final_summary_sumy=''
        print(len(df))
        texto=''
        i = 0
        scr_tbl='scr_table'
        # for index,row in otu.iterrows():
        for date, data in df.iterrows():
            #print(data)
            #print( data[pref] )
            i+=1
            
            if lang =='Japan':
                sent[i] = score_jp( str(data[pref]) )
                pos.append(sent[i]['pos'])
                neg.append(sent[i]['neg'])
                neu.append(sent[i]['neu'])
                com.append(sent[i]['compound'])
            #english
            else:
                try:
                    sent[i] = sid.polarity_scores( str(data[pref]) )
                except:
                    sent[i] = {'neg': 0.0, 'neu': 0.0, 'pos': 0.0, 'compound': 0.0}
                    
                pos.append(sent[i]['pos'])
                neg.append(sent[i]['neg'])
                neu.append(sent[i]['neu'])
                com.append(sent[i]['compound'])
            if pref == 'article':
                ###########
                texto=str(data[pref])
                #texto = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",texto)
                texto = texto.replace('。','\n')
                texto = texto.replace('、','\n')
                #print (str(data[pref]) )
                try:
                    final_summary_spacy = text_summarizer(texto)
                    final_summary_spacy = final_summary_spacy.replace('\n', '')
                    final_summary_spacy = final_summary_spacy.replace('\r', '')

                except Exception as e:
                    print('11:'+str(e))
                    final_summary_spacy = ''
                #append summary
                summary1.append(final_summary_spacy)
                
                # Gensim Summarizer
                try:
                    print('dont worry, gensim')
                    final_summary_gensim = summarize(texto )
                    final_summary_gensim = final_summary_gensim.replace('\n', '')
                    final_summary_gensim = final_summary_gensim.replace('\r', '')
                except Exception as e:
                    print('gensim:'+str(e))
                    final_summary_gensim = ''
                #append summary
                summary2.append(final_summary_gensim)
                    
                try:
                    # NLTK
                    final_summary_nltk = nltk_summarizer(texto ,lang )
                    final_summary_nltk = final_summary_nltk.replace('\n', '')
                    final_summary_nltk = final_summary_nltk.replace('\r', '')
                except Exception as e:
                    print('nltk :'+str(e))
                    final_summary_nltk= ''
                #append summary
                summary3.append(final_summary_nltk)
                
                try:
                    # Sumy
                    final_summary_sumy = sumy_summary( texto,lang )
                    final_summary_sumy = final_summary_sumy.replace('\n', '')
                    final_summary_sumy = final_summary_sumy.replace('\r', '')
                except Exception as e:
                    print('sumy:'+str(e))
                    final_summary_sumy = ''
                #append summary
                summary4.append(final_summary_sumy)
                ##########
                print('dont worry, trainninig the new data'+str(i))

        df[pref+'_positive'] = pos
        df[pref+'_negative'] = neg
        df[pref+'_neutral'] = neu
        df[pref+'_compound'] = com
        
        #append summary
        if pref == 'article':
            df[pref+'_spacy_sum'] = summary1
            df[pref+'_gensim_sum'] = summary2
            df[pref+'_nltk_sum']   = summary3
            df[pref+'_sumy_sum']   = summary4
    print('base df be finished,,, porgram 0999,')  
    #print(df.head(10) )   #appending mode only, 
    #print(df.columns)
    ##this field only used in money impact db, should change it if use others name
    df.index.rename(news_field_index,inplace=True)
    #print(df.head(10) )   #appending mode only, 
    #print(df.columns)
    
    df.set_index(["news_id"],drop=False, inplace=True)
    df.to_csv('money_impact_sentiment1.csv',encoding='utf-8')
    df.to_csv(file.split('.csv')[0]+'money_impact_sentiment.csv', mode='a', header=True, line_terminator="\n", encoding='utf-8')
    #print(df.head(10) )   #appending mode only, 
    #print(df.columns)
    #df = df.set_index("news_id", drop=True)
    #append new index
    #df =df.reset_index(level=None, drop=False, inplace=False)
    print(df.head(10) )   #appending mode only, 
    print(df.columns)
    #print('read update into db,')  

#     data1['Date']=data1.index   #pd.to_datetime(data1.index, format='%Y%m%d')
#     
#     index1 = data1['Date']
#     data1.drop(labels=['Date'], axis=1,inplace = True)
#     data1.insert(0, 'Date', index1)
#     std_df.index.rename('Date',inplace=True)
#     std_df.reset_index(drop = True,inplace=True)

    #database name is your defination, the temp_table is the data be into
    df4 = df[_list_cols_train]
    print(df4.head(10) )   #appending mode only, 
    print(df4.columns)
    if lang=='Japan':
        #this table not defined in money impact
        scr_tbl=moneyi_news_scr_tbl[0]
    else:
        scr_tbl= moneyi_news_scr_tbl[1]
        
    if up_data(df4,scr_tbl):
        print('update the newest records into DB successfully')
    else:
        print('update the newest records into DB failed')
    
    # print('sentiment result saved to :'+file.split('.csv')[0]+'_sentiment'+'.csv')
    


###########check the trained data timely in future
def chk_train_data(filep,lang):
    try:
        retrain,df5 = process_bef_train(lang )
        # if true,it is train again just now.
        if retrain:
    
            print('begin to re-train the news data of new appending,saving training to database.')
            #update the newest records with NLP summary and scoring
            analyzeCSV(df5,filep,lang)
            return True,True
        else:
            return False,True
        
    except Exception as e:
        print(str(e))
        return False,False
