#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Friday April 21 18:38:58 2021

@author: shuxin.jin@hotmail.com
"""
###money impact begin#########

#####################

import spacy
import sys
#for japanese NLP BELOW
import pickle      
from spacy import displacy

import logging
import json

import flask
#for the extension
from fnmatch import fnmatch
import xlrd
import logging
from datetime import datetime 




logger = logging.getLogger(__name__)
nlp2 = spacy.load('ja_ginza')
#nlp2 =spacy.load('ja_ginza_nopn')
# for p in nlp2.pipeline:
#     print(p)

#for ginza testing
import MeCab
import numpy as np
#below to split japanese sentence
import re
#for the data scraping, need a single thread to run it behind of server.
import threading
threads = []

#from __future__ import unicode_literals
from bs4 import BeautifulSoup
from flask import Flask, render_template, url_for, request,session, Response, redirect,flash
from gensim.summarization import summarize
from nltk_summarization import nltk_summarizer
from spacy_summarization import text_summarizer
from sumy.nlp.tokenizers import Tokenizer
from sumy.parsers.plaintext import PlaintextParser
from sumy.summarizers.lex_rank import LexRankSummarizer
from spacy.lang.en import English
#japanese


import requests

import spacy_summarization
import time
import docker
### not using now, maybe later , from selenium import webdriver
import pandas as pd
import os
#for the progress bar
import tempfile
import random
import string


#resolve the problem of services importing
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(curPath)
sys.path.append(curPath+'/services')
#sid ,for pdf to text 

#Upload file security key
from uuid import uuid4

#upload folder checking
import glob
#logging
logger = logging.getLogger(__name__)



from PIL import Image

__author__ = 'Jinshuxin'
#speech key



#download
from flask import send_file
#zip files
import zipfile





##########MORE FUNCTIONS

from services.sentence_tokenizer import SentenceTokenizer
from services.word_tokenizer import WordTokenizer
from services.StopWords import StopWords
from services.stemming import Stemming
from services.partOfSpeechTagging import PartOfSpeechTagging
from services.namedEntityRecognizer import NamedEntityRecognizer
from services.lemmatizer import Lemmatizer
from services.wordNet import WordDetails


#by jin,import text sentiment analysis for pure text
from sentiment import analyzeText,analyzeCSV
from mp_config import inner_conn,doconn,fetchCategory,get_conn,DB_URL,fetchDA,_data_f_type,_db_url,_list_cols1,_list_cols2,_list_cols3,_list_cols4,_list_cols_h1,_list_cols_h2,_list_cols_h3,_list_cols_h4,_train_flag
#from mp_config import _list_cols_h1_jp,_list_cols_h2_jp,_list_cols_h3_jp,_list_cols_h4_jp,sent_trn_csv,_data_path1,_data_path2,webnews_to_newsjp,sid
#for the news like CSV file
from mp_config import read_csv,append_csv,write_csv,edit_csv,en_user_file,jp_user_file,label_news_like,News_scrape_max

#####form 

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, EqualTo

############ user login auth begin################
#below to resolve linux error
import pymysql
pymysql.install_as_MySQLdb()
###session
from sqlalchemy.orm import sessionmaker


#import for user auth
from flask_sqlalchemy import SQLAlchemy
#
from goog_news_scraper import main_vpn
#pdf to text
from PDFtotext import pdftotext
#companys pictures scraping
from google_image_scraper.scrape_company_jpg import scrape_company_jpg



#BERT lib end-----------------

##configuration of timely calling function
class Config(object):  # 创建配置，用类
    # 任务列表
    JOBS = [  
        # {  # 第一个任务
        #     'id': 'job1',
        #     'func': '__main__:job_1',
        #     'args': (1, 2),
        #     'trigger': 'cron', # cron表示定时任务
        #     'hour': 19,
        #     'minute': 27
        # },
        {  # 第二个任务，每隔10005S执行一次
            'id': 'job2',
            'func': '__main__:auto_timely', # 方法名
            'args': (1,2), # 入参
            'trigger': 'interval', # interval表示循环任务
            'seconds': 432000000,   #12000 hours
        }
    ]
    
#calling any functions you want in timely
def auto_timely(a,b):
    print(a+b)
    print('this is a timely calling function')
    
    scraping()
    
    

app = Flask(__name__)

#calling function timely,configuration
app.config.from_object(Config())  # 为实例化的flask引入配置

#connect
app.config['SQLALCHEMY_DATABASE_URI'] = DB_URL
#should change it,otherwise will report one error
app.config["SQLALCHEMY_COMMIT_ON_TEARDOWN"] = True
db = SQLAlchemy(app)


t1=['Category','Date', 'Title']
t3=['Article Score',  'Title Score']

#have to append SDGs part ,not original designing purpose
t4=['Article Score',  'SDGs Check']

ct1=['公司','日期', '标题']
ct3=['文章正评分',  '标题正评分']

jt1=['カテゴリ','日付','タイトル']
jt3=['記事の正スコア','タイトル正スコア']
## database table of user
class User(db.Model):
    """ Create user table"""
    id = db.Column(db.Integer,primary_key = True,autoincrement = True)
    username = db.Column(db.String(80), unique=True)
    email = db.Column(db.String(80), unique=True)
    password = db.Column(db.String(80))
    active = db.Column(db.BOOLEAN, nullable=True)

    def __init__(self, username,email, password,active):
        self.username = username
        self.email =email
        self.password = password
        self.active=active
        
#user prefer
class UsrPref(db.Model):
    __tablename__ = 'usr_pref'
    id = db.Column(db.Integer,primary_key = True,autoincrement = True)
    Category = db.Column(db.String(45))
    usr_id = db.Column(db.Integer, comment='if with user id storing, means that it belong to one special user,please let it be blank at first.')
    prefer_id = db.Column(db.Integer, comment='with user id storing, means that user prefer to show the Category\\nuser id 0 ,not permit ,so the test user id should > 0')
    port_nm = db.Column(db.String(45), comment='portfolio name, it is a name define by customer.Identify the portfolio name.')
    eng_nm = db.Column(db.String(45), comment='the Category English name.')
    com_addr = db.Column(db.String(80), comment='The Category address')
    country = db.Column(db.String(45), comment='the Category registed country')
    com_url = db.Column(db.String(65), comment='The Category URL.')
    com_fld = db.Column(db.String(45), comment='the Category belong to what kind of field')
            
    def __init__(self, Category,usr_id,prefer_id,port_nm,eng_nm,com_addr,country,com_url,com_fld ):
        self.Category = Category
        self.usr_id = usr_id
        self.prefer_id =prefer_id
        self.port_nm =port_nm
        self.eng_nm=eng_nm
        self.com_addr=com_addr
        self.country=country
        self.com_url=com_url
        self.com_fld=com_fld
        
class Scr_Table(db.Model):
    __tablename__ = 'scr_table'
    News_English_id  =db.Column( db.Integer,primary_key = True,autoincrement = True)
    Article_nltk_sum =db.Column(db.Text)
    edit_flag = db.Column(db.BOOLEAN, nullable=False, comment='If edited by customer will set to true')
    del_flag = db.Column(db.BOOLEAN, nullable=False, comment='Delete or not by administrator')
    
    def __init__(self, Article_nltk_sum,edit_flag, del_flag):
        self.Article_nltk_sum = Article_nltk_sum
        self.edit_flag = edit_flag
        self.del_flag = del_flag

#store the japanese scoring
class scr_jp(db.Model):
    __tablename__ = 'scr_jp'
    News_English_id  =db.Column( db.Integer,primary_key = True,autoincrement = True)
    Article_nltk_sum =db.Column(db.Text)
    edit_flag = db.Column(db.BOOLEAN, nullable=False, comment='If edited by customer will set to true')
    del_flag = db.Column(db.BOOLEAN, nullable=False, comment='Delete or not by administrator')
    
    def __init__(self, Article_nltk_sum,edit_flag, del_flag):
        self.Article_nltk_sum = Article_nltk_sum
        self.edit_flag = edit_flag
        self.del_flag = del_flag

#store the chinese scoring
class Scr_ch(db.Model):
    __tablename__ = 'scr_ch'
    News_English_id  =db.Column( db.Integer,primary_key = True,autoincrement = True)
    Article_nltk_sum =db.Column(db.Text)
    edit_flag = db.Column(db.BOOLEAN, nullable=False, comment='If edited by customer will set to true')
    del_flag = db.Column(db.BOOLEAN, nullable=False, comment='Delete or not by administrator')
    
    def __init__(self, Article_nltk_sum,edit_flag, del_flag):
        self.Article_nltk_sum = Article_nltk_sum
        self.edit_flag = edit_flag
        self.del_flag = del_flag



#table model
class News(db.Model):
    __tablename__ = 'News_English'
    News_English_id = db.Column( db.Integer,primary_key=True,autoincrement = True)
    Company = db.Column(db.String(25))
    Source = db.Column(db.String(12))
    Link = db.Column(db.String(255))
    Date = db.Column(db.String(12))
    Author = db.Column(db.String(4000))
    Title = db.Column(db.String(255))
    Article = db.Column(db.Text)
    Category = db.Column(db.String(45))
    
    def __init__(self, Category,Title, Article):
        self.Category = Category
        self.Title = Title
        self.Article = Article

 
        
####### user login auth end ######################
capabilities = {
    "browserName": "chrome",
    "version": "77.0",
    "enableVNC": True,
    "enableVideo": False
}


#form of prefer of users
# 定义表单的模型类
class PreForm(FlaskForm):
    #   
    # DataRequired  ,will fil
    Category = StringField(label=u"CategoryName", validators=[DataRequired(u"CategoryName not null")],render_kw={'class': 'form-control',  'placeholder': u'Enter Category Name'})

    
    
    eng_nm = StringField(label=u"EnglishName", validators=[DataRequired(u"English Name not null")] ,render_kw={'class': 'form-control',  'placeholder': u'Enter English Name'} )
    com_addr = StringField(label=u"Address", validators=[DataRequired(u"Address not null")] ,render_kw={'class': 'form-control',  'placeholder': u'Enter Address'} )
    com_url = StringField(label=u"URL", validators=[DataRequired(u"URL not null")],render_kw={'class': 'form-control',  'placeholder': u'Enter URL'} )
    country = StringField(label=u"Language", validators=[DataRequired(u"Country not null")],render_kw={'class': 'form-control',  'placeholder': u'Enter Country'} )
    com_fld = StringField(label=u"Field", validators=[DataRequired(u"Field not null")],render_kw={'class': 'form-control',  'placeholder': u'Enter Field'} )
    submit = SubmitField(label=u"AppendCategory",render_kw={'class': 'btn btn-success'} )



# driver = webdriver.Remote(
#     command_executor="http://35.231.180.228:4444/wd/hub",    #    command_executor="http://35.231.180.228:4444/wd/hub",
#     desired_capabilities=capabilities)

headers = {
    'authority': 'triberocket.com',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/78.0.3904.108 Safari/537.36',
    'sec-fetch-user': '?1',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,'
              'application/signed-exchange;v=b3',
    'sec-fetch-site': 'none',
    'sec-fetch-mode': 'navigate',
    'accept-encoding': 'gzip, deflate, br',
    'accept-language': 'en-US,en;q=0.9'
}

nlp = spacy.load("en_core_web_sm")







# Reading Time
def readingtime(mytext):
    total_words = len([token.text for token in nlp(mytext)])
    estimatedTime = total_words / 200.0
    return estimatedTime


# Fetch Text From Url
def get_text(url):
    page = requests.get(url, headers=headers, timeout=30)
    # closed by shuxin.jin@hotmail.com  soup = BeautifulSoup(page.content, 'lxml')
    soup = BeautifulSoup(page.content, 'html.parser')
 
    print(page.content.decode('utf-8')[0:2000])
    fetched_text = ' '.join(map(lambda p: p.text, soup.find_all('p')))
    return fetched_text





@app.route('/text')
def index_txt():
    try:
        tact = request.args.get('tact')
    except:
        tact='1'  #initializing

    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')

    
    if session['lang'] =='Japan':
        return flask.render_template('j_index.html',tact=tact)
    elif  session['lang'] =='China':
        return flask.render_template('ch_index.html',tact=tact)
    else:
        return flask.render_template('index.html',tact=tact)

@app.route('/download', methods=['GET'])
def download():
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    lang = None
    try:

        lang=session['lang']
    except:
        lang='English'
    try:
        fn=""
        try:
            type = request.args.get('type')
            
        except:
            type=None
        if type=='tags':
            #create one csv,
            tags = request.args.get('fn')
            patho= tags_create_csv(tags)
      
            #send this patho
            patho = './'+patho
            

        else:
            fn = request.args.get('fn')
    
            #this function located in config.py, as public function.
            patho = './'+_data_path1+'/'+_data_path2+'/'+str(lang)+'_scraping_news.csv'
            #For windows you need to use drive name [ex: F:/Example.pdf]
        #patho = "./nlp_nltk.csv"
        return send_file(patho, as_attachment=True)
     
    except:
        tact='1'  #initializing
    return flask.render_template('index_main.html',tact=tact)


def tags_create_csv(tags):
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
        else:
            lang = None
            try:

                lang=session['lang']
            except:
                lang='English'
            #user name getout
            email1= session['email'] 
    except:
        return render_template('account_login.html')
    df2=get_usr_news(email1,lang,tags)
    filenm = 'data/{}'.format('temp_download.csv')

    df2.to_csv(filenm,encoding='utf-8')
    # csv to excel ,as a backup
    # csv to excel ,as a backup
    df_new =df2
      
    # saving xlsx file 
    GFG = pd.ExcelWriter('tempdownload.xlsx') 
    df_new.to_excel(GFG, index = False) 
      
    GFG.save() 


    return filenm


    
#show the setting news by user
# append one index page, processing the user like words field,
@app.route('/index_main', methods=['GET', 'POST'])
def index_main():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
        else:
        #user name getout
            email1= session['email'] 
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        pgmode=session['pgmode']
            
    except:
        session['pgmode'] = '1'
        pgmode='1'
        
    try:
        pgmode = request.args.get('pgmode').strip()
    except:
        pass
        
    usr_id,super_id,_=get_user(email1)
    lang = None
    try:

        lang=session['lang']
    except:
        lang='English'
        
    if flask.request.method == 'POST':

        #get the setting 
        #pre_str = request.args.get('tags_1')  
#         try:
#             pre_str = request.form['tags_1_tagsinput']
#         except:
#             pass
     
        pre_str = request.form['tags_1']

        #main data fetch and single Category view request
        #print(pre_str)
        
        #only super user can del record
        if not usr_id:
             flash('You are not user, no permission')
             
        else:
            #del the record ,name2 is the index,sum is ''
            if upd_setting_news(pre_str,usr_id):
                 #flash(' user, saving this setting')
          
                if lang=='Japan':
                    lang1='ja'
                elif lang=='China':
                    lang1='cn'
                else:
                    lang1='en'
                if save_srch(pre_str,lang1):
                    logger.info('user %s  Save tags [%s] into DB,false.' % (email1, pre_str))
                else:
                    logger.info('user %s  Save tags [%s] into DB,success.' % (email1, pre_str))
            else:
                flash(' user,error when saving this setting')
        #get user prefer again
 
        data_df1= get_usr_news(email1,lang,None)
    #method of get    
    else:

        #get prefer news directly
        data_df1= get_usr_news(email1,lang,None)
        
    algm='spacy'
    _,_,pre_str=get_user(email1)
    
    try:
        data_df1 = data_df1[~( data_df1['Article'].isnull() )]
        #data_df2 = data_df2[~( data_df2['Article'].isnull() )]
           
        #clean the data of article ,clean the extra return
        data_df1=data_df1.replace('\n\n', '\n')
        #data_df2=data_df2.replace('\n\n', '\n')
    except:
        pass
    #jtag = 0,not show the prefer
    return show_nlp_index(data_df1,algm,lang,pre_str,-99,pgmode)
#get user news
def get_usr_news(email1,lang,tags):
    #get user prefer again,if no tags be input
    #cc1 ='-$()#+&*aa,bb，。【】-！@#￥%……——=[]{};；！！！！！！！！！！！@#￥%%%…………&&***（）——+‘’、、。，/'
    if tags==None or len(str(tags))<1:
        _,_,pre_str1=get_user(email1)
        
        
    #a tags be input
    else:
        pre_str1=str(tags)
        
    if pre_str1 is not None:
        if len(pre_str1)>2:
    
            # 使用正则表达式去匹配标点符号
            pre_str1 = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",pre_str1)
            #cc1=re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！，。？、~@#￥%……&*；（）]+", "",cc1)
            #print(cc1)
           
            # 所有标点--result = re.sub("[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？、~@#￥%……&*（）]+", "",result)
            pre_str1  = pre_str1.strip().replace(',', '|')
            pre_str1 = ' and Article RLIKE ' +'\''+pre_str1+'\''
        #pre_str1 = "|".join([x.repace(',','').strip() for x in pre_str1])
        
        else:
            #index page, 100 is enough
            pre_str1=' limit 0,500 '
    else:
        #index page, 100 is enough
        pre_str1=' limit 0,500 '
    print(pre_str1)
    #astr='{}|{}'.format(tuple name)

    engine =get_conn()
    #del_flag  this record had been filter by user
    
    #JP
    if lang=='Japan':
        com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True  '+ pre_str1
    else:
        #English news
        com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True  '+ pre_str1

    print(com_sql1)
    data_df1 = pd.read_sql_query(com_sql1, engine)
    

    
#######dna rudge temp issue#########
    pre_str1 = ' and Article RLIKE ' +'\''+'Nudge|COVID Nudge'+'\''
    com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True  '+ pre_str1
    data_dftmp = pd.read_sql_query(com_sql1, engine)
    data_dftmp.to_csv('rudge1.csv',encoding='utf-8')
    # csv to excel ,as a backup
    # csv to excel ,as a backup
    df_new =data_dftmp
      
    # saving xlsx file 
    GFG = pd.ExcelWriter('rudge1.xlsx') 
    df_new.to_excel(GFG, index = False) 
      
    GFG.save() 

########fffff############

    #data_df2 = pd.read_sql_query(com_sql2, engine)
    return data_df1  #,data_df2
    
    
# is the csv list index page
@app.route('/csv_index', methods=['GET', 'POST'])
def csv_index():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    lang = None
    try:
 
        lang=session['lang']
    except:
        lang='English'
        
    #main data fetch and single Category view request
    try:
        #one special Category name
        cname = request.args.get('file')
        if cname is not None:
            data_df1 = fetchCategory(str(cname).strip(),lang )
        else:
            data_df1 = fetchDA(lang,0,1000)  
    except:
        #checking details
        data_df1 = fetchDA(lang,0,1000)
    if data_df1 is None:
        return redirect('/index_main')
    try:
        algm = request.args.get('algm')
        if algm ==None:
            algm='nltk'
    except:
        algm='nltk'  #initializing
    try:
        idx = request.args.get('ddx')
    except:
        idx = None
    try:
        data_df1 = data_df1.drop_duplicates()
    except:
        pass
    print('len of before clean:'+ str(len(data_df1) ))
    #remove null line
    #data_df1 = data_df1.dropna(how='any',axis=0) 
    #only remove null of article,can not open ,not debugging
    try:
        data_df1 = data_df1[~( data_df1['Article'].isnull() )]
    except:
        pass
    print('len of after clean ,length of article:'+str( len(data_df1)) )
    #clean the data of article ,clean the extra return
    data_df1=data_df1.replace('\n\n', '\n')
    #df=df[~(df['col'].isnull())] #删掉空行

   
    return show_nlp(idx,data_df1,algm,lang)






#abstract the nlp list showing , for the new layout of 20200720
def show_nlp(idx,data_df1,algm,lang):
    try:
        if algm==None: 
            algm='nltk'
        #index of the record
        if idx  is not None: 
            #locate the record
            #data_df1=data_df1[_list_cols1]
            data_df = data_df1.loc[ ( data_df1.index == int(idx) ) ]
       
            if algm=='sumy':
                data_df = data_df[_list_cols4]
            elif algm=='spacy':
                data_df = data_df[_list_cols2]
            elif algm=='gensim':
                data_df = data_df[_list_cols3]
            #nltk
            else:
                data_df = data_df[_list_cols1]
                
            print('ready to front page679')
             
            #version 1,  read the result, return one line table content
            #return flask.render_template('csv_index2.html', data_df=[data_df.to_html()],titles = _list_cols1 )    
            #version 2 
            #column_names=data_df.columns.values
            #这里加一个zip函数
            news = data_df.values.tolist()
            
            if algm=='sumy':
                zipnews = zip(_list_cols4,news[0])
            elif algm=='spacy':
                zipnews = zip(_list_cols2,news[0])
            elif algm=='gensim':
                zipnews = zip(_list_cols3,news[0])

            #nltk
            else:
                data_df = data_df[_list_cols1]
            
            
            return flask.render_template('csv_detail.html',news=zipnews)
        #not single  record,but batch records
        else:
            #这个流程是废代码，演时后 删除data_df=data_df1
            #will train it again if true
#             if _train_flag:
#                 sent_trn_csv('notusenow')
            print('this is a temp filter of head 1000,pls modify it with a new paging method')
            #data_df = data_df1.head(1000)
            #print('hereeeee111:'+str(_list_cols_h1))
            #chinese language
            if lang =='China':
                if algm=='sumy':
                    data_df = data_df[_list_cols_h4]
                elif algm=='spacy':
                    data_df = data_df[_list_cols_h2]
                elif algm=='gensim':
                    data_df = data_df[_list_cols_h3]
                #nltk
                else:
                    data_df = data_df[_list_cols_h1]
            #Japanese language
            elif lang=='Japan':
                if algm=='sumy':
                    data_df = data_df[_list_cols_h4_jp]
                elif algm=='spacy':
                    data_df = data_df[_list_cols_h2_jp]
                elif algm=='gensim':
                    data_df = data_df[_list_cols_h3_jp]
                #nltk,not process sdg?
                else:
                    data_df = data_df[_list_cols_h1_jp]
            #english
            else:
                if algm=='sumy':
                    data_df = data_df[_list_cols_h4]
                elif algm=='spacy':
                    data_df = data_df[_list_cols_h2]
                elif algm=='gensim':
                    data_df = data_df[_list_cols_h3]
                #nltk
                else:
                    data_df = data_df[_list_cols_h1]     
#                                           _list_cols_h1 --    ['Category', 'Author','Link', 'Date', 'Title', 'Article_nltk_sum',  'Article_compound', 'Title_compound','News_English_id']
#                                 _list_cols6 = ['Category', 'Date', 'Author','Link', 'Title','Article_compound','Title_compound', 'Source','edit_flag','del_flag','News_English_id']
#                                   data_df1 =data_df1[_list_cols6]
            #next page
            nextpp={}
            newlines=""
            
            try:
                data_df=data_df.drop_duplicates()
            except:
                pass
#             cols_to_use = s.columns.difference(data.columns) # pandasç‰ˆæœ¬åœ¨0.15å�Šä¹‹ä¸Šçš„éƒ½å�¯ä»¥ç”¨è¿™ç§�æ–¹æ³•ï¼Œè¯¥æ–¹æ³•æ‰¾å‡ºSå’Œdataè¡¨çš„ä¸�å�Œåˆ—ï¼Œç„¶å�Žå†�è¿›è¡Œmerge
#             pd.merge(data, s[cols_to_use], left_index=True, right_index=True, how='outer')
            
            #processing before submit
            newlines= pdataframe2(data_df,algm)

            jsonfiles = json.loads(newlines.to_json(orient='records'))
            
            
            print('ready to front page')
            
            if session['lang'] =='Japan':
                if algm=='sumy':
                    colss = jt1+[ 'Sumy 概要']+jt3
                elif algm=='spacy':
                    colss =  jt1+['Spacy 概要']+jt3 
                elif algm=='gensim':
                    colss =jt1+['Gensim 概要']+jt3
                #have to append this SDGs part,not original designing purpose
                elif algm=='sdg':
                    colss =jt1+['NLTK 概要']+t4
                #nltk
                else:
                    colss = jt1+['NLTK 概要']+jt3
               
                return flask.render_template('j_csv_index_2.html', lines=jsonfiles ,titles = colss,algm=algm  )   
            elif session['lang'] =='China':
                if algm=='sumy':
                    colss = ct1+[ 'Sumy 概要']+ct3
                elif algm=='spacy':
                    colss =  ct1+['Spacy 概要']+ct3 
                elif algm=='gensim':
                    colss =ct1+['Gensim 概要']+ct3
                #nltk
                else:
                    colss = ct1+['NLTK 概要']+ct3
                return flask.render_template('ch_csv_index.html', lines=newlines ,titles = colss )  
            else:
                if algm=='sumy':
                    colss = t1+[ 'Sumy Summary']+t3
                elif algm=='spacy':
                    colss =  t1+['Spacy Summary']+t3 
                elif algm=='gensim':
                    colss =t1+['Gensim Summary']+t3
                #have to append this SDGs part,not original designing purpose
                elif algm=='sdg':
                    colss =t1+['NLTK Summary']+t4
                #nltk
                else:
                    colss = t1+['NLTK Summary']+t3

                return flask.render_template('csv_index_2.html', lines=jsonfiles ,titles = colss,algm=algm )  
            ######################
             
            #read the result
            #v1   return flask.render_template('csv_index.html', data_df=[data_df.to_html()],titles = _list_cols )      
    #not one special index,but all the records       
    except Exception as e:
        
        #will train csv file again if true
#         if _train_flag:
#             sent_trn_csv('notusenow')
        print(str(e))     
        data_df = data_df1
        #print('hereeeee22:'+str(_list_cols_h1))
        #chinese language
        if lang =='China':
            if algm=='sumy':
                data_df = data_df[_list_cols_h4]
            elif algm=='spacy':
                data_df = data_df[_list_cols_h2]
            elif algm=='gensim':
                data_df = data_df[_list_cols_h3]
            #nltk
            else:
                data_df = data_df[_list_cols_h1]
        #Japanese language
        elif lang=='Japan':
            if algm=='sumy':
                data_df = data_df[_list_cols_h4_jp]
            elif algm=='spacy':
                data_df = data_df[_list_cols_h2_jp]
            elif algm=='gensim':
                data_df = data_df[_list_cols_h3_jp]
            #nltk
            else:
                data_df = data_df[_list_cols_h1_jp]
        #english
        else:
            if  algm=='sumy':
                data_df = data_df[_list_cols_h4]
            elif algm=='spacy':
                data_df = data_df[_list_cols_h2]
            elif algm=='gensim':
                data_df = data_df[_list_cols_h3]
                
            #nltk
            else:
                data_df = data_df[_list_cols_h1]
        #next page
        nextpp={}
        newlines=""
         
        #processing before submit
        newlines= pdataframe(data_df,algm)
        print('ready to front page')
        
        if session['lang'] =='Japan':
            if algm=='sumy':
                colss = jt1+[ 'Sumy 概要']+jt3
            elif algm=='spacy':
                colss =  jt1+['Spacy 概要']+jt3 
            elif algm=='gensim':
                colss =jt1+['Gensim 概要']+jt3
            #nltk
            else:
                colss = ct1+['NLTK 概要']+ct3
            return flask.render_template('j_csv_index.html', lines=newlines ,titles = colss )     

        elif session['lang'] =='China':
            if algm=='sumy':
                colss = ct1+[ 'Sumy 概要']+ct3
            elif algm=='spacy':
                colss =  ct1+['Spacy 概要']+ct3 
            elif algm=='gensim':
                colss =ct1+['Gensim 概要']+ct3
            #nltk
            else:
                colss = ct1+['NLTK 概要']+ct3
            return flask.render_template('ch_csv_index.html', lines=newlines ,titles = colss )  

        else:
            if algm=='sumy':
                colss = t1+[ 'Sumy Summary']+t3
            elif algm=='spacy':
                colss =  t1+['Spacy Summary']+t3 
            elif algm=='gensim':
                colss =t1+['Gensim Summary']+t3
            #nltk
            else:
                colss = t1+['NLTK Summary']+t3
            return flask.render_template('csv_index.html', lines=newlines ,titles = colss )     

      


        ######################
         
        #read the result
        #v1   return flask.render_template('csv_index.html', data_df=[data_df.to_html()],titles = _list_cols )      
 

# # is the csv list index page
# @app.route('/csv_index2', methods=['GET', 'POST'])
# def csv_index2():
#     #will open it later
#     #will train it again if true
# 
#         
#     data_df =fetchDA()
#     #next page
# 
#     
#     ######################
#     #nltk output
#     list_cols = ['Category', 'Source', 'Link', 'Date', 'Title','Article_nltk_sum','Article_positive', 'Article_negative', 'Article_neutral', 'Article_compound', 'Title_positive', 'Title_negative', 'Title_neutral', 'Title_compound']
# 
#     data_df = data_df[list_cols]
#     data_df.columns = list_cols
#     #curPath = os.path.abspath(os.path.dirname(__file__))
#     #pd.DataFrame(data_df).to_csv(curPath+'\\' + 'algo.csv')
#     data_df['Title'] = data_df['Title'].str.strip()
#     #suit for linux os ,change to below
#     pd.DataFrame(data_df).to_csv('.'+'/' + 'nlp_nltk.csv',index=False)
#     #read the result
#     return flask.render_template('csv_index2.html', data_df=[data_df.to_html()],titles = list_cols )      
    #return flask.render_template('csv_index.html', lines=newlines ,titles = _list_cols )     


#abstract the nlp list showing , for the new layout of 20200720
def show_nlp_index(data_df1,algm,lang,pre_str,jtag,pgmode):
    if not algm: 
        algm='spacy'
    if algm=='':
        algm='spacy'
    #print(data_df1.columns)
    #print(data_df2.columns)
    #chinese language

    
#     if algm=='sumy':
#      
#         data_df2 = data_df2[_list_cols_h4_jp]
#     elif algm=='spacy':
#      
#         data_df2 = data_df2[_list_cols_h2_jp]
#     elif algm=='gensim':
#     
#         data_df2 = data_df2[_list_cols_h3_jp]
#     #nltk,not process sdg?
#     else:
#         data_df2 = data_df2[_list_cols_h1_jp]
    
    if algm=='sumy':
        data_df1 = data_df1[_list_cols_h4]
     
    elif algm=='spacy':
        data_df1 = data_df1[_list_cols_h2]
     
    elif algm=='gensim':
        data_df1 = data_df1[_list_cols_h3]
    
    #nltk
    else:
        data_df1 = data_df1[_list_cols_h1]    
        
    
    #next page
    nextpp={}
    newlines=""
    
    try:
        data_df1=data_df1.drop_duplicates()
#         data_df2=data_df2.drop_duplicates()
    except:
        pass
    
    #processing before submit
    
    
    jsonfiles1 = json.loads(data_df1.to_json(orient='records'))
#     jsonfiles2 = json.loads(data_df2.to_json(orient='records'))
    
    
    print('ready to front page')
#     if lang == 'Japan':
#         return flask.render_template('main_index.html', lines1=None,lines2=jsonfiles1 ,algm=algm,lang=lang )  
#     else:
    if str(pgmode)=='2':
        return flask.render_template('index_main_dark.html', lines1=jsonfiles1,lines2=None ,algm=algm,lang=lang,pre_str=pre_str,jtag=jtag )  
    else:
        return flask.render_template('index_main.html', lines1=jsonfiles1,lines2=None ,algm=algm,lang=lang,pre_str=pre_str,jtag=jtag )  



#can add a looping method here. 
@app.route('/analyze', methods=['GET', 'POST'])
def analyze():
    global summary_reading_time_nltk
    # Here are multi methods to generate a sentiment score 
    #  https://www.programcreek.com/python/example/100005/nltk.sentiment.vader.SentimentIntensityAnalyzer
    
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
    start = time.time()
    if flask.request.method == 'POST':
        #locate to the algorithm tab, show the special tab
        try:
            tact = flask.request.form['tact']
            #tact = request.form.get('tact')
        except:
            tact='1'  #initializing
        try:
            ginza_plus = flask.request.form['ginza']
            #tact = request.form.get('tact')
        except:
            ginza_plus='0'  #initializing
        rawtext = flask.request.form['rawtext']
        
        return analyze_public(rawtext,lang,lang,start,tact)

#public analyze part， will be implemented,lang is the user lang mode, lang1 is the processing text language.
def analyze_public(rawtext,lang,lang1,start,tact):
    final_reading_time = readingtime(rawtext)
    
    try:
        final_summary_spacy = text_summarizer(rawtext)
    except:
        final_summary_spacy = '002,Maybe you input some illegal text for this NLP library,please input at least one sentence.'
    summary_reading_time = readingtime(final_summary_spacy)
    
    # Gensim Summarizer
    try:
        final_summary_gensim = summarize(rawtext)
    except:
        final_summary_gensim = '003,Maybe you input some illegal text for this NLP library ,please input at least one sentence.'
    summary_reading_time_gensim = readingtime(final_summary_gensim)
    
    try:
        # NLTK
        final_summary_nltk = nltk_summarizer(rawtext,lang)
    except Exception as e:
        print(str(e))
        final_summary_nltk= '004,Maybe you input some illegal textfor this NLP library,please input at least one sentence.'
    summary_reading_time_nltk = readingtime(final_summary_nltk)
    
    try:
        # Sumy ,https://qiita.com/hideki/items/5e9892094ae786d2ad6c
        final_summary_sumy = sumy_summary(rawtext,lang)
    except Exception as e:
        print('sumy sum:'+str(e)) 
        final_summary_sumy = '005,Maybe you input some illegal text for this NLP library,please input at least one sentence.'
    summary_reading_time_sumy = readingtime(final_summary_sumy)

    end = time.time()
    final_time = end - start
    #Sentiment score return
    sent = analyzeText(rawtext,lang)


    if lang=='China':
        return flask.render_template('ch_index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                     final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                     final_time=final_time, final_reading_time=final_reading_time,
                                     summary_reading_time=summary_reading_time,
                                     summary_reading_time_gensim=summary_reading_time_gensim,
                                     final_summary_sumy=final_summary_sumy,
                                     summary_reading_time_sumy=summary_reading_time_sumy,
                                     summary_reading_time_nltk=summary_reading_time_nltk,
                                     sent = sent,tact=tact)
    elif lang=='Japan':
        #ginza is a algorithm ,be added lately, so there is a seperate index page to show it
        if not ginza_plus:
            return flask.render_template('j_index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                     final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                     final_time=final_time, final_reading_time=final_reading_time,
                                     summary_reading_time=summary_reading_time,
                                     summary_reading_time_gensim=summary_reading_time_gensim,
                                     final_summary_sumy=final_summary_sumy,
                                     summary_reading_time_sumy=summary_reading_time_sumy,
                                     summary_reading_time_nltk=summary_reading_time_nltk,
                                     sent = sent,tact=tact)
        #ginza plus processing
        else:
            doc_sents=ginza_analysis(rawtext,lang)
            return flask.render_template('j_index_ginza.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                     final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                     final_time=final_time, final_reading_time=final_reading_time,
                                     summary_reading_time=summary_reading_time,
                                     summary_reading_time_gensim=summary_reading_time_gensim,
                                     final_summary_sumy=final_summary_sumy,
                                     summary_reading_time_sumy=summary_reading_time_sumy,
                                     summary_reading_time_nltk=summary_reading_time_nltk,
                                     sent = sent,tact=tact,ginza_sents=doc_sents)
            
    else:
        return flask.render_template('index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                     final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                     final_time=final_time, final_reading_time=final_reading_time,
                                     summary_reading_time=summary_reading_time,
                                     summary_reading_time_gensim=summary_reading_time_gensim,
                                     final_summary_sumy=final_summary_sumy,
                                     summary_reading_time_sumy=summary_reading_time_sumy,
                                     summary_reading_time_nltk=summary_reading_time_nltk,
                                     sent = sent,tact=tact)

#ginza analysis for japanese. 

def ginza_analysis(rawtext,lang):
       # refer to :https://github.com/mashyko/NLP_Mecab
       #  most theory from  https://www.koi.mashykom.com/nlp.html
       #  have to copy this example if no idea :https://github.com/mashyko/NLP_Mecab/blob/master/gensim_topic.ipynb
    ####test########
    #mehtod 1

    
    MECAB_MODE = 'mecabrc'                                                                                                                                                   
    tagger = MeCab.Tagger(MECAB_MODE)
    tagger.parse("")
    #be parse to node tree of words
    node = tagger.parseToNode(rawtext)
      
    words = []
    nouns = []
    verbs = []
    adjs = []
    while node:
            pos = node.feature.split(",")[0]
            word = node.surface
            if pos == "名詞":
                nouns.append(word)
            elif pos == "動詞":
                verbs.append(word)
            elif pos == "形容詞":
                adjs.append(word)
            words.append(word)
            node = node.next
    words_dict = {
            "text": words[1:-1], # 最初と最後には空文字列が入るので除去                                                                                                
            "nouns": nouns,
            "verbs": verbs,
            "adjs": adjs
            }
      
    print ("文: \n", words[:80])
    print ("名詞: \n", nouns[:50])
    print ("動詞: \n", verbs[:50])
    print ("形容詞: \n", adjs[:50])
     
    # method 2
    tagger = MeCab.Tagger('-Owakati')
    tagger.parse("")
      
    text = tagger.parse(rawtext)
    #print ("method 2: \n", str(text) )
    #with open('./corpora/bocchan_wakati.txt', mode='w') as f:
    #f.write(text)
    text = text.replace('。','\n')
    text = text.replace('、','\n')
    words =text.split(' ')
    #split to word s, and the words canbe convert to corpus
    print (words)
     
    #convert words to corpus
     
    
    
    word_to_id = {}
    id_to_word = {}
    for word in words:
        if word not in word_to_id:
            new_id = len(word_to_id)
            word_to_id[word] = new_id
            id_to_word[new_id] = word
      
    corpus = np.array([word_to_id[w] for w in words])
      
    print ('id_to_word \n', id_to_word)
    print ('word_to_id \n', word_to_id)
    print ('corpus \n',corpus)
             
     
     
    # convert to one hhot
    vocab_size = len(word_to_id)
    N = corpus.shape[0]
      
    one_hot = np.zeros((N, vocab_size), dtype=np.int32)
    for idx, word_id in enumerate(corpus):
        one_hot[idx, word_id] = 1
      
    print ('one-hot 表現: \n',one_hot)
     
     
     
    # import the gensim to processing some
    #import os
    #import tempfile
    #TEMP_FOLDER = tempfile.gettempdir()
    #print('Folder "{}" will be used to save temporary dictionary and corpus.'.format(TEMP_FOLDER))
        
    linetext= "".join(rawtext.split("\n")[3:])
    print ('line split : \n',linetext)
     
     
     
     
    #***********  another method for Japanese NLP , spacy ginza  *******
    #  https://github.com/mashyko/Mecab_Juman_Ginza/blob/master/Ginza_SpaCy.ipynb
    
    doc = nlp2(rawtext)
    for sent in doc.sents:
        for token in sent:
            info = [
                token.i,         # トークン番号
                token.text,     # テキスト
                token._.reading, # 読みカナ
                token.lemma_,    # 基本形
                token.pos_,      # 品詞
                token.tag_,      # 品詞詳細
                token._.inf      # 活用情報
            ]
            print(info)    
    
    
    #token print
    for token in doc:
        print(token.text, token.pos_, token.vector[:2]) # 単語ベクトルの最初の2次元のみ出力   
    #english dictionary key word label    
    for ent in doc.ents:
        print(ent.text, ent.start_char, ent.end_char, ent.label_)
    return doc.sents
        
@app.route('/analyze_url', methods=['GET', 'POST'])
def analyze_url():
    start = float( time.time() )

    global summary_reading_time_nltk
    # Here are multi methods to generate a sentiment score 
    #  https://www.programcreek.com/python/example/100005/nltk.sentiment.vader.SentimentIntensityAnalyzer
    
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        

    if flask.request.method == 'POST':
        raw_url = request.form['raw_url']
        rawtext = str(get_text(raw_url) )
        final_reading_time = readingtime(rawtext)
        #locate to the algorithm tab, show the special tab
        try:
            tact = flask.request.form['tact']
            #tact = request.form.get('tact')
        except:
            tact='1'  #initializing
        try:
            ginza_plus = flask.request.form['ginza']
            #tact = request.form.get('tact')
        except:
            ginza_plus='0'  #initializing
       
        final_reading_time = readingtime(rawtext)
        
        try:
            final_summary_spacy = text_summarizer(rawtext)
        except:
            final_summary_spacy = '002,Maybe you input some illegal text for this NLP library,please input at least one sentence.'
        summary_reading_time = readingtime(final_summary_spacy)
        
        # Gensim Summarizer
        try:
            final_summary_gensim = summarize(rawtext)
        except:
            final_summary_gensim = '003,Maybe you input some illegal text for this NLP library ,please input at least one sentence.'
        summary_reading_time_gensim = readingtime(final_summary_gensim)
        
        try:
            # NLTK
            final_summary_nltk = nltk_summarizer(rawtext,lang)
        except:
            final_summary_nltk= '004,Maybe you input some illegal textfor this NLP library,please input at least one sentence.'
        summary_reading_time_nltk = readingtime(final_summary_nltk)
        
        try:
            # Sumy
            final_summary_sumy = sumy_summary(rawtext,lang)
        except:   
            final_summary_sumy = '005,Maybe you input some illegal text for this NLP library,please input at least one sentence.'
        summary_reading_time_sumy = readingtime(final_summary_sumy)

        end = time.time()
        final_time = end - start
        #Sentiment score return
        sent = analyzeText(rawtext,lang)


        if lang=='China':
            return flask.render_template('ch_index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                         final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                         final_time=final_time, final_reading_time=final_reading_time,
                                         summary_reading_time=summary_reading_time,
                                         summary_reading_time_gensim=summary_reading_time_gensim,
                                         final_summary_sumy=final_summary_sumy,
                                         summary_reading_time_sumy=summary_reading_time_sumy,
                                         summary_reading_time_nltk=summary_reading_time_nltk,
                                         sent = sent,tact=tact)
        elif lang=='Japan':
            if not ginza_plus:
                return flask.render_template('j_index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                         final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                         final_time=final_time, final_reading_time=final_reading_time,
                                         summary_reading_time=summary_reading_time,
                                         summary_reading_time_gensim=summary_reading_time_gensim,
                                         final_summary_sumy=final_summary_sumy,
                                         summary_reading_time_sumy=summary_reading_time_sumy,
                                         summary_reading_time_nltk=summary_reading_time_nltk,
                                         sent = sent,tact=tact)
            #ginza plus processing
            else:
                doc_sents=ginza_analysis(rawtext,lang)
                return flask.render_template('j_index_ginza.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                         final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                         final_time=final_time, final_reading_time=final_reading_time,
                                         summary_reading_time=summary_reading_time,
                                         summary_reading_time_gensim=summary_reading_time_gensim,
                                         final_summary_sumy=final_summary_sumy,
                                         summary_reading_time_sumy=summary_reading_time_sumy,
                                         summary_reading_time_nltk=summary_reading_time_nltk,
                                         sent = sent,tact=tact,ginza_sents=doc_sents)
                
        else:
            return flask.render_template('index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                         final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                         final_time=final_time, final_reading_time=final_reading_time,
                                         summary_reading_time=summary_reading_time,
                                         summary_reading_time_gensim=summary_reading_time_gensim,
                                         final_summary_sumy=final_summary_sumy,
                                         summary_reading_time_sumy=summary_reading_time_sumy,
                                         summary_reading_time_nltk=summary_reading_time_nltk,
                                         sent = sent,tact=tact)



    else:
        return flask.render_template('analyze_url.html')
    



#dataframe processing
def staticfile(request):
    print("enter staticfile")
    
    request.encoding='utf-8'           
    filename = request.GET['fn']
    #ainame = request.POST.getlist('ainame')
    #codeid = request.GET['cde']
    filename = str(filename).split("/")[-1]  
    filename1 = './web/templates/{}'.format(filename)  
    print("enter static file show,got :",filename1)

    if os.path.isfile(filename1):
        return render(request,filename1,locals())
    else:
        return HttpResponse("static file , there is no such file")
   


### do the pandas dataframe to django template loop data ###########################
def pdataframe2(df_html1,algm):
    df_html=None
    # df_html1.drop_duplicates()
    #col_n = ['report_id', 'sec_code', 'sec_name','broker_name', 'report_date','summary', '繧ｻ繝ｳ繝√Γ繝ｳ繝医せ繧ｳ繧｢�ｼ医�吶け繝医Ν繝吶�ｼ繧ｹ�ｼ�', '繧ｻ繝ｳ繝√Γ繝ｳ繝医せ繧ｳ繧｢�ｼ域･ｵ諤ｧ蛟､繝吶�ｼ繧ｹ�ｼ�','繧ｻ繝ｳ繝√Γ繝ｳ繝医せ繧ｳ繧｢�ｼ亥盾閠�蛟､�ｼ�', '繝ｬ繧ｳ繝｡繝ｳ繝�繝ｼ繧ｷ繝ｧ繝ｳ繧ｹ繧ｳ繧｢', '繝ｬ繧ｳ繝｡繝ｳ繝�繝ｼ繧ｷ繝ｧ繝ｳ繧ｹ繧ｳ繧｢�ｼ亥盾閠�蛟､�ｼ�']
    try:
        #
        df_html1 = df_html1.where(df_html1.notnull(),"")
    except:
        pass
    #df_htmllink = convert_html_link(df_html1["Link"])
    df_htmllink = df_html1["Link"]
    df_author   = df_html1["Author"]
    #
    id4 = df_html1["News_English_id"] #add by jin 0408,2020
    id4 =pd.DataFrame(id4)
    print(str( len(id4.columns) ))
    multi_flg=False
    if len(id4.columns)>1:
        col=id4.iloc[:,0]
        multi_flg=True
        #取表中的第2列的所有值
        df_html1 = df_html1.drop(columns = ['News_English_id'])
        id5=col.values
    else:
        id5 = id4.values
    print(df_html1.columns)
    return df_html1


### do the pandas dataframe to django template loop data ###########################
def pdataframe(df_html1,algm):
    df_html=None
    # df_html1.drop_duplicates()
    #col_n = ['report_id', 'sec_code', 'sec_name','broker_name', 'report_date','summary', '繧ｻ繝ｳ繝√Γ繝ｳ繝医せ繧ｳ繧｢�ｼ医�吶け繝医Ν繝吶�ｼ繧ｹ�ｼ�', '繧ｻ繝ｳ繝√Γ繝ｳ繝医せ繧ｳ繧｢�ｼ域･ｵ諤ｧ蛟､繝吶�ｼ繧ｹ�ｼ�','繧ｻ繝ｳ繝√Γ繝ｳ繝医せ繧ｳ繧｢�ｼ亥盾閠�蛟､�ｼ�', '繝ｬ繧ｳ繝｡繝ｳ繝�繝ｼ繧ｷ繝ｧ繝ｳ繧ｹ繧ｳ繧｢', '繝ｬ繧ｳ繝｡繝ｳ繝�繝ｼ繧ｷ繝ｧ繝ｳ繧ｹ繧ｳ繧｢�ｼ亥盾閠�蛟､�ｼ�']
    try:
        #
        df_html1 = df_html1.where(df_html1.notnull(),"")
    except:
        pass
    #df_htmllink = convert_html_link(df_html1["Link"])
    df_htmllink = df_html1["Link"]
    df_author   = df_html1["Author"]
    #
    id4 = df_html1["News_English_id"] #add by jin 0408,2020
    id4 =pd.DataFrame(id4)
    print(str( len(id4.columns) ))
    multi_flg=False
    if len(id4.columns)>1:
        col=id4.iloc[:,0]
        multi_flg=True
        #取表中的第2列的所有值
        id5=col.values
    else:
        id5 = id4.values

    df_html = df_html1.drop(columns = ['Author','Link','News_English_id'])
    
    #clean
    #df_html= re.sub('[\n]+', '\n', df_html)
    lines = ""
    j = 0 
    
    for idx, row in df_html.iterrows():
    
        for i, p in enumerate(row):
    
            if  (p != None):
                st =  str(p).strip()              
    
            else:
                st = str("")
                 
            #st=st.split(".")[-2]
            #append link  
            if i == 0:
                #(filepath,linkstr) = os.path.split((df_htmllink[j][2:]))
                #filepath=os.path.dirname(df_htmllink[j]) ,remove the '..'
                #line = "<TR><TD style=\" width:8%;text-align: left;\"><a href=\""+(df_htmllink[j])+"\" target = \"new blank\"  >"  + "<span class=\"label label-primary\">" + st + "</span></a></TD>"
                line = "<TR><TD style=\" width:8%;text-align: left;\">"  + "<span class=\"label label-primary\">" + st + "</span></TD>"
           
            #Datetime,append time clock
            elif i==1:
                
                line += "<TD  width =10% >" + "<i class=\"fa fa-clock-o\"></i>" + st.strip() + "</TD>"
                            #Datetime,append time clock
            #title
            elif i==2:
                
                #print(str( id4 ))
               
                #print(str( id5[j] ))
                if st ==None:
                    st=''
                else:
                    pass
#                 print(len(df_author[j]))
#                 print(len(str(df_author[j]).strip() ))
                try:
                    if ( df_author[j] is None ):
                        df_author[j]=''
                    elif  len(df_author[j])== 0 :
                        df_author[j]=''
                    elif  len(df_author[j])== 'NULL' :
                        df_author[j]=''
                    elif str(df_author[j]).strip() =='':
                        df_author[j]=''      
                    else:
                        pass
                except:
                    #print("except with the data of author")
                    df_author[j]='-'
               
                    pass
                if not multi_flg:
                    
                    #print(str( id5[j][0] ))
                    line += "<TD width =15% ><a href=\"/csv_index3?ddx="+str( id5[j][0] )+"&algm="+str(algm)+"&article=view&pre=view \" target = \"new blank\" title=\"Author:"+(str(df_author[j]))+"\" >"  + st.strip()  + "</a></TD>"
                else:
                    line += "<TD width =15% ><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm="+str(algm)+"&article=view&pre=view \" target = \"new blank\" title=\"Author:"+(str(df_author[j]))+"\" >"  + st.strip()  + "</a></TD>"
        
            # Number 5 defined by the table td numbers.
            elif i==3 :
                #clean the extra blank line
                st = st.strip()
                st = st.replace('\n', '')
                st = st.replace('\r', '')
                #st = " ".join([x.strip() for x in st]) 
                ###st = " ".join([x.replace(r"\n", "") for x in st]) 
#                 st = st.replace('\n', '')
#                 
#                 st = st.replace(r"\n", "")
#                 re.sub(r'([^\S\n]*\n(?:[^\S\n]*\n)+[^\S\n]*)|[^\S\n]*\n[^\S\n]*', lambda x: x.group(1) or ' ', st )
#           
#                 st = re.sub('[\n]+', '\n', st)
                
                line += "<TD width = 49%><div id=\"tdspecial\" style=\"text-align: left;\"><span title=\"Author:"+(df_author[j])+"\" class=\"span1\">" + st + "</span></div></TD>"
            #append color
            elif (i == len(row) - 2) or (i == len(row) - 3) or (i == len(row) - 4) :
                
                #convert to percent format
                try:
                    line += "<TD  style=\"width:8%;text-align:right \"  class=\"text-navy\" ><h4 class=\"no-margins\">" + str( "%.3f" % (float(st)) )+ "</h4></TD>"
                except:
                    line += "<TD  style=\"width:8%;text-align:right \"  class=\"text-navy\" ><h4 class=\"no-margins\">" +'--'+ "</h4></TD>"
              
            #append color and end of tr
            elif (i == len(row) - 1):
                
                #print(str(math.floor(float(st))))
                #line += "<TD  style=\"width:10%;text-align:right \"  class=\"text-navy\" ><h4 class=\"no-margins\">" + str( "%.2f" % (float(st)*100) )+ "%</h4></TD></TR>\n"
                try:
                    if algm =='sdg':
                        if not multi_flg:
                    
                            line += "<TD style=\"width:8%;text-align:right \"  class=\"text-navy\"> <a href=\"/csv_index3?ddx="+str( id5[j][0] )+"&algm="+str(algm)+"&article=view&pre=view \" target = \"new blank\">View SDGs</TD></TR>\n"
                        else:
                            line += "<TD style=\"width:8%;text-align:right \"  class=\"text-navy\"> <a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm="+str(algm)+"&article=view&pre=view \" target = \"new blank\">View SDGs</TD></TR>\n"
                    
                    else:
                        line += "<TD  style=\"width:8%;text-align:right \"  class=\"text-navy\" ><h4 class=\"no-margins\">" + str( "%.3f" % (float(st) ) )+ "</h4></TD></TR>\n"
                    # strong be added by SDGs,
                    
                        
                except:
                    line += "<TD  style=\"width:8%;text-align:right \"  class=\"text-navy\" ><h4 class=\"no-margins\">" + '--'+ "</h4></TD></TR>\n"

            else:
                line += "<TD>" + st.strip() + "</TD>"
    
        lines += line
        j += 1     
#     except:
#         lines=""
        #print("before to page",lines)
    
    return lines


#word token processing, retrun a list page of word token
def wd_pf(df_html1):
    #['Category','Date', 'Title',  'Article Score',  'Title Score','Source','Action']
    #print(df_html1.columns)
    df_html=None
    #clean
    #df_html1 = df_html1.where(df_html1.notnull(),"")
    df_html1 = df_html1.fillna("")
    #get the link
    df_htmllink = df_html1["Link"]
    #get the author
    df_author   = df_html1["Author"]
    #id5 = df_html1["News_English_id"] 

    col=pd.DataFrame(df_html1["News_English_id"]).iloc[:,0]
  
    #取表中的第2列的所有值
    id5=col.values

    #drop the 2 columns ,not drop News_English_id,will add action with this column
    df_html = df_html1.drop(columns = ['Author','Link'])
    
    ###  fields order as ['Category','Date', 'Title',  'ArticleScore',  'Title Score','Source','Edit Once','Deleted']

    lines = ""
    j = 0 
    
    for idx, row in df_html.iterrows():
        restore=False
        actionstr=''
        for i, p in enumerate(row):
    
            if  (p != None):
                st =  str(p).strip()              
    
            else:
                st = str("")
                 
            #Category title.   append link  
            if i == 0:
                try:
                    line = "<TR><TD style=\" width:10%;text-align: left;\"><a href=\""+(df_htmllink[j])+"\" target = \"new blank\"  >"  + "<span class=\"label label-primary\">" + st + "</span></a></TD>"
                except:
                    line = "<TR><TD style=\" width:10%;text-align: left;\"><a href=\"\" target = \"new blank\"  >"  + "<span class=\"label label-primary\">" +"--" + "</span></a></TD>"
            #Datetime,append time clock
            elif i==1:
                
                line += "<TD  width =10% >" + "<i class=\"fa fa-clock-o\"></i>" + st + "</TD>"
            #title
            elif i==2:
                try:
                    line += "<TD width =20% > <a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=view&pre=view \" target = \"new blank\"  title=\"Author:"+(df_author[j])+"\" >"  + st + "</a></TD>"
                except:
                    line += "<TD width =20% > <a href=\"/csv_index3?ddx=&algm=nltk"+"&article=view&pre=view \" target = \"new blank\"  title=\"Author:-\" >"  + "--" + "</a></TD>"
            # score 1，2
            elif i==3 or i==4 :
                #convert to percent format
                try:
                    line += "<TD  style=\"width:10%;text-align:right;padding-right:7rem; \"  class=\"text-navy\" ><h4 class=\"no-margins\">" + str( "%.3f" % (float(st)) )+ "</h4></TD>"
                except:
                    line += "<TD  style=\"width:10%;text-align:right;padding-right:7rem; \"  class=\"text-navy\" ><h4 class=\"no-margins\">" +'--'+ "</h4></TD>"
                    
            #Edit or not
            elif (i == 6):
                try:
                    if int(st.strip() )>0:
                        line += "<TD> <span class=\"label label-success\">" + 'Edited' + "</span></TD>"
                    else:
                       line += "<TD>  <span class=\"label label-info\">" + 'None' + "</span></TD>" 
                except: 
                    line += "<TD>" +'None'+ "</TD>"
             #del or not
            elif (i == 7):
                
                try:
                    if int(float(st))>0:
                        restore=True
                        line += "<TD> <span class=\"label label-danger\">" + 'Deleted' + "</span></TD>"
                    else:
                       line += "<TD> <span class=\"label label-info\">" + 'None' + "</span> </TD>" 
                except: 
                    line += "<TD>" +'None'+ "</TD>"           
            #last field with actions
            elif (i == len(row) - 1):
                
#                 #if already removed this record
#                 if restore:
#                     actionstr = "<button class=\"btn-dim btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=back&pre=rst \" target = \"new blank\">Restore</button></a>"
#                 else:
#                     actionstr = "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=back&pre=del \" target = \"new blank\">Delete</button></a>"
                    
                line += ("<TD class=\"text-left\"><div class=\"btn-group\">"
                              "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=view&pre=view \" target = \"new blank\">View</button></a>"
                              "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=edit&pre=wordtoken \" target = \"new blank\">WordToken</button></a>"+actionstr+"</div></TD>"     
                             )           
                
            else:
                line += "<TD style=\"width:10%;text-align:left \" >" + st.strip() + "</TD>"
                
    
        lines += line
        j += 1     
#     except:
#         lines=""
        #print("before to page",lines)
    
    return lines



#stemmer process data
def stem_pf(df_html1):
    #['Category','Date', 'Title',  'Article Score',  'Title Score','Source','Action']
    #print(df_html1.columns)
    df_html=None
    #clean
    #df_html1 = df_html1.where(df_html1.notnull(),"")
    df_html1 = df_html1.fillna("")
    #get the link
    df_htmllink = df_html1["Link"]
    #get the author
    df_author   = df_html1["Author"]
    ######id5 = df_html1["News_English_id"] 
    col=pd.DataFrame(df_html1["News_English_id"]).iloc[:,0]
  
    #取表中的第2列的所有值
    id5=col.values
    #
   

    #drop the 2 columns ,not drop News_English_id,will add action with this column
    df_html = df_html1.drop(columns = ['Author','Link'])
    
    ###  fields order as ['Category','Date', 'Title',  'ArticleScore',  'Title Score','Source','Edit Once','Deleted']

    lines = ""
    j = 0 
    
    for idx, row in df_html.iterrows():
        restore=False
        actionstr=''
        for i, p in enumerate(row):
    
            if  (p != None):
                st =  str(p).strip()              
    
            else:
                st = str("")
                 
            #Category title.   append link  
            if i == 0:
                try:
                    line = "<TR><TD style=\" width:10%;text-align: left;\"><a href=\""+(df_htmllink[j])+"\" target = \"new blank\"  >"  + "<span class=\"label label-primary\">" + st + "</span></a></TD>"
                except:
                    line = "<TR><TD style=\" width:10%;text-align: left;\"><a href=\"\" target = \"new blank\"  >"  + "<span class=\"label label-primary\">" +"--" + "</span></a></TD>"
            #Datetime,append time clock
            elif i==1:
                
                line += "<TD  width =10% >" + "<i class=\"fa fa-clock-o\"></i>" + st + "</TD>"
            #title
            elif i==2:
                try:
                    line += "<TD width =20% > <a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=view&pre=view \" target = \"new blank\"  title=\"Author:"+(df_author[j])+"\" >"  + st + "</a></TD>"
                except:
                    line += "<TD width =20% > <a href=\"/csv_index3?ddx=&algm=nltk"+"&article=view&pre=view \" target = \"new blank\"  title=\"Author:-\" >"  + "--" + "</a></TD>"
            # score 1，2
            elif i==3 or i==4 :
                #convert to percent format
                try:
                    line += "<TD  style=\"width:10%;text-align:right;padding-right:7rem; \"  class=\"text-navy\" ><h4 class=\"no-margins\">" + str( "%.3f" % (float(st)) )+ "</h4></TD>"
                except:
                    line += "<TD  style=\"width:10%;text-align:right;padding-right:7rem; \"  class=\"text-navy\" ><h4 class=\"no-margins\">" +'--'+ "</h4></TD>"
                    
            #Edit or not
            elif (i == 6):
                try:
                    if int(st.strip() )>0:
                        line += "<TD> <span class=\"label label-success\">" + 'Edited' + "</span></TD>"
                    else:
                       line += "<TD>  <span class=\"label label-info\">" + 'None' + "</span></TD>" 
                except: 
                    line += "<TD>" +'None'+ "</TD>"
             #del or not
            elif (i == 7):
                
                try:
                    if int(float(st))>0:
                        restore=True
                        line += "<TD> <span class=\"label label-danger\">" + 'Deleted' + "</span></TD>"
                    else:
                       line += "<TD> <span class=\"label label-info\">" + 'None' + "</span> </TD>" 
                except: 
                    line += "<TD>" +'None'+ "</TD>"           
            #last field with actions
            elif (i == len(row) - 1):
                
#                 #if already removed this record
#                 if restore:
#                     actionstr = "<button class=\"btn-dim btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=back&pre=rst \" target = \"new blank\">Restore</button></a>"
#                 else:
#                     actionstr = "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=back&pre=del \" target = \"new blank\">Delete</button></a>"
                    
                line += ("<TD class=\"text-left\"><div class=\"btn-group\">"
                              "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=view&pre=view \" target = \"new blank\">View</button></a>"
                              "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=edit&pre=stemmer \" target = \"new blank\">Stemmer</button></a>"+actionstr+"</div></TD>"     
                             )           
                
            else:
                line += "<TD style=\"width:10%;text-align:left \" >" + st.strip() + "</TD>"
                
    
        lines += line
        j += 1     
#     except:
#         lines=""
        #print("before to page",lines)
    
    return lines




########use for user portfolio management
### do the pandas dataframe to django template loop data ###########################
def pdataframe_pf(df_html1):
    #print(df_html1.columns)
    df_html=None
    #clean
    try:
        df_html1 = df_html1.where(df_html1.notnull(),"")
    except:
        pass
    df_html1 = df_html1.fillna("")
    #get the link
    df_htmllink = df_html1["Link"]
    #get the author
    df_author   = df_html1["Author"]

    id4 = df_html1["News_English_id"] #add by jin 0408,2020
    id4 =pd.DataFrame(id4)
    print(str( len(id4.columns) ))
    multi_flg=False
    if len(id4.columns)>1:
        col=id4.iloc[:,0]
        multi_flg=True
        #取表中的第2列的所有值
        id5=col.values
    else:
        #id5 = id4.values
        col=id4.iloc[:,0]
        multi_flg=True
        #取表中的第2列的所有值
        id5=col.values
   

    #drop the 2 columns ,not drop News_English_id,will add action with this column
    df_html = df_html1.drop(columns = ['Author','Link'])
    
    ###  fields order as ['Category','Date', 'Title',  'ArticleScore',  'Title Score','Source','Edit Once','Deleted']

    lines = ""
    j = 0 
    
    for idx, row in df_html.iterrows():
        restore=False
        actionstr=''
        for i, p in enumerate(row):
    
            if  (p != None):
                st =  str(p).strip()              
    
            else:
                st = str("")
                 
            #Category title.   append link  
            if i == 0:
                try:
                    line = "<TR><TD style=\" width:10%;text-align: left;\"><a href=\""+(df_htmllink[j])+"\" target = \"new blank\"  >"  + "<span class=\"label label-primary\">" + st + "</span></a></TD>"
                except:
                    line = "<TR><TD style=\" width:10%;text-align: left;\"><a href=\"\" target = \"new blank\"  >"  + "<span class=\"label label-primary\">" +"--" + "</span></a></TD>"
            #Datetime,append time clock
            elif i==1:
                
                line += "<TD  width =10% >" + "<i class=\"fa fa-clock-o\"></i>" + st + "</TD>"
            #title
            elif i==2:
                try:
                    if not multi_flg:
                        line += "<TD width =20% > <a href=\"/csv_index3?ddx="+str( id5[j][0] )+"&algm=nltk"+"&article=view&pre=view \" target = \"new blank\"  title=\"Author:"+(df_author[j])+"\" >"  + st + "</a></TD>"
                    else:
                        line += "<TD width =20% > <a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=view&pre=view \" target = \"new blank\"  title=\"Author:"+(df_author[j])+"\" >"  + st + "</a></TD>"

                except:
                    line += "<TD width =20% > <a href=\"/csv_index3?ddx=&algm=nltk"+"&article=view&pre=view \" target = \"new blank\"  title=\"Author:-\" >"  + "--" + "</a></TD>"
            # score 1，2
            elif i==3 or i==4 :
                #convert to percent format
                try:
                    line += "<TD  style=\"width:10%;text-align:right;padding-right:7rem; \"  class=\"text-navy\" ><h4 class=\"no-margins\">" + str( "%.3f" % (float(st)) )+ "</h4></TD>"
                except:
                    line += "<TD  style=\"width:10%;text-align:right;padding-right:7rem; \"  class=\"text-navy\" ><h4 class=\"no-margins\">" +'--'+ "</h4></TD>"
                    
            #Edit or not
            elif (i == 6):
                try:
                    if int(st.strip() )>0:
                        line += "<TD> <span class=\"label label-success\">" + 'Edited' + "</span></TD>"
                    else:
                       line += "<TD>  <span class=\"label label-info\">" + 'None' + "</span></TD>" 
                except: 
                    line += "<TD>" +'None'+ "</TD>"
             #del or not
            elif (i == 7):
                
                try:
                    if int(float(st))>0:
                        restore=True
                        line += "<TD> <span class=\"label label-danger\">" + 'Deleted' + "</span></TD>"
                    else:
                       line += "<TD> <span class=\"label label-info\">" + 'None' + "</span> </TD>" 
                except: 
                    line += "<TD>" +'None'+ "</TD>"           
            #last field with actions
            elif (i == len(row) - 1):
                
                #if already removed this record
                if restore:
                    if not multi_flg:
                        actionstr = "<button class=\"btn-dim btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j][0] )+"&algm=nltk"+"&article=back&pre=rst \" target = \"new blank\">Restore</button></a>"
                    else:
                        actionstr = "<button class=\"btn-dim btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=back&pre=rst \" target = \"new blank\">Restore</button></a>"
               
                else:
                    if not multi_flg:
                        actionstr = "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j][0] )+"&algm=nltk"+"&article=back&pre=del \" target = \"new blank\">Delete</button></a>"
                    else:
                        actionstr = "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=back&pre=del \" target = \"new blank\">Delete</button></a>"
                #make sure the width of td column    
                line += ("<TD style=\"width:12%;\" class=\"text-left\"><div class=\"btn-group\">"
                              "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=view&pre=view \" target = \"new blank\">View</button></a>"
                              "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( id5[j] )+"&algm=nltk"+"&article=edit&pre=edit \" target = \"new blank\">Edit</button></a>"+actionstr+"</div></TD>"     
                             )           
                
            else:
                line += "<TD style=\"width:10%;text-align:left \" >" + st.strip() + "</TD>"
                
    
        lines += line
        j += 1     
#     except:
#         lines=""
        #print("before to page",lines)
    
    return lines

########use for user prefer management，generate the dataframe for user prefer comanpy
def pdataframe_pre(df_html1,usr_id,super_flg):
    #print(df_html1.columns)
    usr_id=str(usr_id)
    #clean
    try:
        #
        df_html1 = df_html1.where(df_html1.notnull(),"")
    except:
        pass

    #get the link
    df_htmllink = df_html1["com_url"]

    #drop the 2 columns ,not drop News_English_id,will add action with this column
    df_html = df_html1.drop(columns = ['com_url'])
    
    ###  fields order as ['Category','eng_nm','com_addr','country','com_fld', 'prefer_id','id']
    lines = ""
   
    j = 0 
    
    for idx, row in df_html1.iterrows():
        name2=''  
        noprefer=False
        actionstr1=''
        actionstr2=''
        for i, p in enumerate(row):
    
            if  (p != None):
                st =  str(p).strip()              
    
            else:
                st = str("")
                
            #Category title.   append link  
            if i == 0:
                if df_htmllink[j]=='' or df_htmllink[j]==None:
                    df_htmllink[j]=''
                #line = "<TR><TD style=\" width:8%;text-align: left;\"><a href=\""+(df_htmllink[j])+"\" target = \"new blank\"  >"  + "<span class=\"label label-primary\">" + st + "</span></a></TD>"
                line = "<TR><TD style=\" width:8%;text-align: left;\"><span class=\"label label-primary\">" + st + "</span></TD>"
                name2=str(st)
    
            
            # hide or show button
            elif (i == len(row) - 2) :
                
                try:
                    #
                    if int(float(st))>0:
                        noprefer=True
                        line += "<TD style=\" width:10%;\"> <span class=\"label label-success\">" + 'Hide' + "</span></TD>"
                    else:
                       line += "<TD style=\" width:10%;\">  <span class=\"label label-info\">" + 'Show' + "</span></TD>" 
                except: 
                    line += "<TDstyle=\" width:10%;\">"+ "<span class=\"label label-primary\">"  +'Show'+ "</span></TD>"
#             #hide or not
#             elif (i == 2):
#                 prefer=False
#                 try:
#                     if int(st.strip() )>0:
#                         restore=True
#                         line += "<TD> <span class=\"label label-danger\">" + 'Prefer' + "</span></TD>"
#                     else:
#                        line += "<TD> <span class=\"label label-info\">" + '-' + "</span> </TD>" 
#                 except: 
#                     line += "<TD>" +'None'+ "</TD>"           
            #last field with actions
            elif (i == len(row) - 1):

                #if already hide this record
#                 if hide:
#                     actionstr1 = "<button class=\"btn-white btn btn-xs\"><a href=\"/csv_index3?ddx="+str( df_htmllink)+"&algm=nltk"+"&article=back \" target = \"new blank\">Show</a></button>"
#                 else:
                actionstr1 = "<button class=\"btn-dim btn btn-xs\"><a href=\"/pre_do?ddx="+str( usr_id )+"&nm="+name2+"&pre=edit\" title='Edit this record.' target = \"new blank\">Edit</a></button>"
                #if super_flg:
                actionstr1+= "<button class=\"btn-white btn btn-xs\"><a href=\"/pre_do?ddx="+str( usr_id )+"&nm="+name2+"&pre=del\" title='Will delete this record,danger operation!' target = \"new blank\">Del</a></button>"
                    
                actionstr1+= "<button type='submit' class=\"btn-white btn btn-xs\"><a href=\"/pre_do?ddx="+str( usr_id )+"&nm="+name2+"&pre=view\" title='Check all records' target = \"new blank\">View</a></button>"

                
                #if already prefer this record
                if noprefer:
                    actionstr2 = "<button class=\"btn-white btn btn-xs\"><a href=\"/pre_do?ddx="+str( usr_id)+"&nm="+name2+"&pre=show \" title='Will show records again' target = \"new blank\">Show</a></button>"
                else:
                    actionstr2 = "<button class=\"btn-warning btn btn-xs\"><a href=\"/pre_do?ddx="+str( usr_id )+"&nm="+name2+"&&pre=hide \" title='Will hide all related records' target = \"new blank\">Hide</a></button>"
                    
                line += ("<TD style=\" width:12%;\" class=\"text-left\"><div class=\"btn-group\">"+actionstr2+actionstr1+"</div></TD></TR> "  )      
                                     
                
            else:
                if len(st)>0:
                    line += "<TD style=\"width:10%;text-align:left \" >" + st.strip() + "</TD>"
                else:
                    line += "<TD style=\"width:10%;text-align:left \" >" + '-' + "</TD>"
    
        lines += line
        j += 1     
#     except:
#         lines=""
        #print("before to page",lines)
    
    return lines


############################
def convert_html_link(col_data):
    cwd = os.getcwd()
    f_url = lambda x : os.path.abspath(os.path.join(cwd, x)).replace('\\', '/')
    return col_data.apply(f_url)


@app.route('/about')
def about():
    return flask.render_template('company_intro.html')



@app.route('/terms', methods=['GET', 'POST'])
def terms():
    return flask.render_template('account_terms.html' )      

########APPEND MORE FUNCTIONS BELOW,NEED INTEGRATING################
# is word token index page
@app.route('/word_token', methods=['GET', 'POST'])
def word_token():
    return flask.render_template('word_token.html' )      


"""
Controller to split the sentences into words
"""
@app.route("/wordTokenize", methods=['POST'])
def word_tokenize():
    text = request.form.get('text')
    word_tokenizer_object = WordTokenizer(text)
    tokenized_words = word_tokenizer_object.tokenizer()
    return render_template("WordTokenizer.html", words = tokenized_words)


# is sentence token index page
@app.route('/sent_token', methods=['GET', 'POST'])
def sent_token():
    return flask.render_template('sent_token.html' ) 

"""
Controller to convert the string into sentences
"""
@app.route("/sentenceTokenize", methods=['POST'])
def sentence_tokenize():
    text = request.form.get('text')
    sentence_tokenizer_object = SentenceTokenizer(text)
    tokenized_sentences = sentence_tokenizer_object.tokenizer()
    return render_template("SentenceTokenizer.html", sentences = tokenized_sentences)


# is stop word remover index page
@app.route('/stop_rem', methods=['GET', 'POST'])
def stop_rem():
    return flask.render_template('stop_rem.html' ) 

"""
Controller to remove all the stop words from the string
"""
@app.route("/stopWordRemover", methods=['POST'])
def stop_word_remover():
    text = request.form.get('text')
    stop_words_object = StopWords(text)
    filtered_text = stop_words_object.StopWordRemove()
    return render_template("StopWords.html", sentence = filtered_text)


# is stemmer_i index page
@app.route('/stemmer_i', methods=['GET', 'POST'])
def stemmer_i():
    return flask.render_template('stemmer_i.html' ) 


"""
Controller to get the root words from a sentence
"""
@app.route("/stemmer", methods = ['POST'])
def stemmer():
    text = request.form.get('text')
    stemming_object = Stemming(text)
    stemmer_words = stemming_object.stemmer()
    return render_template("stemmer.html", words = stemmer_words)

# is posTagging index page
@app.route('/posTagging_i', methods=['GET', 'POST'])
def posTagging_i():
    return flask.render_template('posTagging_i.html' ) 


"""
Controller for applying part fo speech tagging for sample text
"""
@app.route("/pos_tagging", methods = ['GET', 'POST'])
def pos_tagging():
    text = request.form.get('text')
    pos_object = PartOfSpeechTagging(text)
    all_tags = pos_object.partOfSpeechTagging()
    return render_template("partOfSpeechtagging.html" , all_tags = all_tags)



# is posTagging index page
@app.route('/namedEntityRec_i', methods=['GET', 'POST'])
def namedEntityRec_i():
    return flask.render_template('namedEntityRec_i.html' ) 


"""
Controller for identifying named entities from sample text
"""
@app.route("/namedEntityRecognizer", methods = ['GET','POST'])
def named_entity_recognize():
    try:
        named_enitoty_recognizer_object = NamedEntityRecognizer()
        named_entities = named_enitoty_recognizer_object.namedEntityRecognizer()
    except Exception as e:
        print('this is name entity error,'+str(e))
        return flask.render_template('namedEntityRec_i.html' ) 
    return render_template("namedEntityRecognizer.html", named_entities = named_entities)


# is posTagging index page
@app.route('/lemmatize_i', methods=['GET', 'POST'])
def lemmatize_i():
    return flask.render_template('lemmatize_i.html' ) 


"""
Controller for finding the useful route word for a word
"""
@app.route("/lemmatize", methods = ['GET','POST'])
def lemmatize():
    text =  request.form.get("text")
    obj = Lemmatizer(text)
    lemmatized_word = [text,obj.wordLemmatize()]
    return render_template("lemmatizer.html", lemmatized_word = lemmatized_word)

# is posTagging index page
@app.route('/detail_i', methods=['GET', 'POST'])
def detail_i():
    return flask.render_template('detail_i.html' ) 


"""
Controller to get details of the word such as definition, synonyms, antonyms and examples
"""
@app.route("/wordDetails", methods = ['GET','POST'])
def wordDetails():
    text =  request.form.get("text")
    obj = WordDetails(text)
    details = []
    details.append(text)
    details.append(obj.definition())
    details.append(obj.synonyms())
    details.append(obj.antonyms())
    details.append(obj.examples())
    #print(details)
    return render_template("wordDetails.html",details = details)

######################END OF INTEGRATING


###### user auth part bein#############
#login in vie,后续要和flask-login 结合
@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login Form"""
    if request.method == 'GET':
        return render_template('account_login.html')
    else:
       
        name = request.form['email']
        passw = request.form['password']

        data = User.query.filter_by(email=name, password=passw).first()
        if data is not None:
            session['logged_in'] = True
            session['username'] = data.username
            session['email'] = data.email
            session['lang'] = 'English'
            session['pgmode'] = '1'
            #to the index page
            #return redirect(url_for('/index'))
            #return flask.render_template('index.html')
            return redirect('/index_main')
        else:
            return render_template('account_login.html',ee='No user or wrong password')
#         except:
#             return render_template('account_login.html')
#         
#### register
@app.route('/register', methods=['GET', 'POST'])
def register():
    """Register Form"""
    if request.method == 'POST':
        try:
            name1= request.form['username']
            password = request.form.get("password",type=str,default=None)
            email=request.form['email']
            new_user = User(
                username=name1,
                email=email,
                password=password,
                active=True)
            db.session.add(new_user)
            db.session.commit()
                    
            session['logged_in'] = True
            session['username'] = name1
            session['email'] = email
            session['lang'] = 'English'
            session['pgmode']='1'
            return render_template('index.html')
        except:
            return render_template('account_reg.html',ee='Error,user existed or others')
        
    return render_template('account_reg.html')

####log out
@app.route("/logout")
def logout():
    """Logout Form"""
    session['logged_in'] = False
    session['username'] = None
    session['email'] = None
    
    return flask.render_template('index.html')


#portfolio word token list 
@app.route('/word_tk_mg', methods=['GET', 'POST'])
def word_tk_mg():
    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
#     try:
    engine =get_conn()
    data_df1 = None
    if lang =='China':
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_compound, b.Title_compound from News_CH a right join scr_ch b on a.News_English_id =b.News_English_id'
    
    elif lang=='Japan':
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_compound, b.Title_compound from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id'

    #nglish
    else:
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_compound, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id'
    
    data_df1 = pd.read_sql_query(com_sql2, engine)
    #special to anas  source data set
    data_df1=data_df1.replace('\n\n', '\n')
    return wd_mg_page(data_df1)

#word token list front page
def wd_mg_page(data_df1):
    #clean the data of article ,clean the extra return
    #print(data_df1.columns)
    #colss = ['Category','Date', 'Title',  'Article Score',  'Title Score','Source','Edit Once','Deleted','Action']
    
        #colss = ['Category','Date', 'Title',  'Article Score',  'Title Score','Source','Edit Once','Deleted','Action']
    
    if session['lang'] =='Japan':
       
        colss = jt1 +jt3 + ['ソース','一度編集','削除','アクション']
    
    elif session['lang'] =='China':
      
        colss = ct1+ct3+ ['来源','编辑','删除','操作']
    
    else:
        colss = t1 +t3 + ['Source','Edit Once','Deleted','Action']
        
    if data_df1 is None:
       
        return flask.render_template('portfolio.html', lines=None ,titles = colss )   
    _list_cols6 = ['Category', 'Date', 'Author','Link', 'Title','Article_compound','Title_compound', 'Source','edit_flag','del_flag','News_English_id']
    data_df1 =data_df1[_list_cols6]
    nextpp={}
    newlines=""
    data_df1 = data_df1.drop_duplicates()
    #processing before submit
    newlines= wd_pf(data_df1)
    #xuyao chongxie zhe bufen 

    
    print('ready to front page')        

    return flask.render_template('portfolio.html', lines=newlines ,titles = colss )   
        
#portfolio nLP stemmer list 
@app.route('/stem_mg', methods=['GET', 'POST'])
def stem_mg():
    #fetch data
    #connect to db, and this mode can run with or without database 
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
#     try:
    engine =get_conn()
    data_df1 = None
    if lang =='China':
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_compound, b.Title_compound from News_CH a right join scr_ch b on a.News_English_id =b.News_English_id'
    
    elif lang=='Japan':
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_compound, b.Title_compound from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id'
    
    #nglish
    else:
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_compound, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id'
    
    data_df1 = pd.read_sql_query(com_sql2, engine)
    #special to anas  source data set
    data_df1=data_df1.replace('\n\n', '\n')
    return stem_page(data_df1)

#stemmer detail front page
def stem_page(data_df1):
    #clean the data of article ,clean the extra return
    #print(data_df1.columns)
    #colss = ['Category','Date', 'Title',  'Article Score',  'Title Score','Source','Edit Once','Deleted','Action']
    
        #colss = ['Category','Date', 'Title',  'Article Score',  'Title Score','Source','Edit Once','Deleted','Action']
    
    if session['lang'] =='Japan':
       
        colss = jt1 +jt3 + ['ソース','一度編集','削除','アクション']
    
    elif session['lang'] =='China':
      
        colss = ct1+ct3+ ['来源','编辑','删除','操作']
    
    else:
        colss = t1 +t3 + ['Source','Edit Once','Deleted','Action']
        
    if data_df1 is None:
       
        return flask.render_template('portfolio.html', lines=None ,titles = colss )   
    _list_cols6 = ['Category', 'Date', 'Author','Link', 'Title','Article_compound','Title_compound', 'Source','edit_flag','del_flag','News_English_id']
    data_df1 =data_df1[_list_cols6]
    nextpp={}
    newlines=""
    data_df1 = data_df1.drop_duplicates()
    #processing before submit
    newlines= stem_pf(data_df1)
    #xuyao chongxie zhe bufen 

    
    print('ready to front page')        

    return flask.render_template('portfolio.html', lines=newlines ,titles = colss )   
        
            
#portfolio manangement
@app.route('/pf_mg', methods=['GET', 'POST'])
def pf_mg():
    #fetch data
    #connect to db, and this mode can run with or without database 
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
#     try:
    engine =get_conn()
    data_df1 = None

    if lang =='China':
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_compound, b.Title_compound from News_CH a right join scr_ch b on a.News_English_id =b.News_English_id'
    
    elif lang=='Japan':
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_positive, b.Title_positive from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id'
    
    #nglish
    else:
        com_sql2 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,b.edit_flag,b.del_flag,b.Article_compound, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id'
    
    data_df1 = pd.read_sql_query(com_sql2, engine)
    #special to anas  source data set
    data_df1=data_df1.replace('\n\n', '\n')
    return pf_mg_page(data_df1,lang)

#abstract this to one public methods . return to prefer management page with data set
def pf_mg_page(data_df1,lang):
    #clean the data of article ,clean the extra return
    #print(data_df1.columns)
    #colss = ['Category','Date', 'Title',  'Article Score',  'Title Score','Source','Edit Once','Deleted','Action']
    
    if lang =='Japan':
       
        colss = jt1 +jt3 + ['ソース','一度編集','削除','アクション']
    
    elif lang =='China':
      
        colss = ct1+ct3+ ['来源','编辑','删除','操作']
    
    else:
        colss = t1 +t3 + ['Source','Edit Once','Deleted','Action']
                 
                    
                    
                    
    if data_df1 is None:
        lines=None
    else: 
        if lang =='Japan':
               
            _list_cols6 = ['Category', 'Date', 'Author','Link', 'Title','Article_positive','Title_positive', 'Source','edit_flag','del_flag','News_English_id']
        elif lang =='China':
             _list_cols6 = ['Category', 'Date', 'Author','Link', 'Title','Article_compound','Title_compound', 'Source','edit_flag','del_flag','News_English_id']
        else:
             _list_cols6 = ['Category', 'Date', 'Author','Link', 'Title','Article_compound','Title_compound', 'Source','edit_flag','del_flag','News_English_id']
        data_df1 =data_df1[_list_cols6]
        nextpp={}
        newlines=""
        data_df1 = data_df1.drop_duplicates()
        #processing before submit
        newlines= pdataframe_pf(data_df1)
        #xuyao chongxie zhe bufen 

    
    print('ready to front page')        
    if lang == 'China':
        return flask.render_template('ch_portfolio.html', lines=newlines ,titles = colss )
    elif lang =='Japan':
        return flask.render_template('j_portfolio.html', lines=newlines ,titles = colss )
    else:
        return flask.render_template('portfolio.html', lines=newlines ,titles = colss )   
        
         
#     except:
#         return 'Error when connect to DB'

# #prefer Category
# @app.route('/prefer1', methods=['GET', 'POST'])
# def prefer1():
#     
#     return ''
    
#prefer Category
@app.route('/prefer', methods=['GET', 'POST'])
def prefer():
    #fetch data
    ee=''
    jtag = -99
    #connect to db, and this mode can run with or without database 
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
           
        else:
            try:
                lang = None
                lang=session['lang']
            except:
            
                lang='English'
            #user name getout
            email1= session['email'] 
    except:
        return render_template('account_login.html')
  
#     try:
    engine =get_conn()
    data_df1 = None
    usr_id=-999
  
    com_sql2=''
    com_sql2 ='select  * from  user  where email=\''+email1+'\''
    #print(com_sql2)
    data_df1 = pd.read_sql_query(com_sql2, engine)
    print( str( data_df1['id'][0] ) )
    usr_id=  data_df1['id'][0]
    super_flg =  data_df1['super_flg'][0]
  
    #get the form
    form = PreForm()
    #  
    # If  submit 
    if form.validate_on_submit():
    #if form.validate():     #经测试两种验证方法都可行，上边是提交时候验证，validate也能达到同样的效果，validate应用领域应该会大一些；
        # 表示验证合格
        # 提取数据
        Category = form.Category.data
        eng_nm = form.eng_nm.data
        com_addr = form.com_addr.data
        com_url = form.com_url.data
        country = lang
        #country = form.country.data
        com_fld = form.com_fld.data
        #submit and refresh,initialize,with prefer_id 0 and port_nm ''
        new_data = UsrPref(Category = Category,
                            usr_id = int(usr_id),
                            prefer_id =0,  #the user prefer it  # 0 means show it
                            port_nm ='',
                            eng_nm=eng_nm,
                            com_addr=com_addr,
                            country=country,
                            com_url=com_url,
                            com_fld=com_fld
                            )
        
        #set one permission contral flag
        if _train_flag and super_flg:
            db.session.add(new_data)
            db.session.commit()
            ee='Super user:already append Category sucessfully'
        else:
            ee='You have no super user permission'


    #-----Method 1
    #all Category only with basic data
    if lang =='China':
        com_sql2 ="select a.id,a.usr_id,a.prefer_id,a.eng_nm,a.com_addr,a.country,a.com_url,a.com_fld,distinct(a.Category) from usr_pref  as a   right join ( select distinct(Category) from News_CH) as b on a.Category =b.Category and  a.country like '%%%%%s%%%%' "  % lang
    
    elif lang=='Japan':
        #com_sql2 ="select a.id,a.usr_id,a.prefer_id,a.eng_nm,a.com_addr,a.country,a.com_url,a.com_fld,a.Category from usr_pref  as a   where a.usr_id="+str(usr_id)+"  a.country like '%%%%%s%%%%' "  % lang 
        com_sql2 ="select a.id,a.usr_id,a.prefer_id,a.eng_nm,a.com_addr,a.country,a.com_url,a.com_fld,a.Category from usr_pref  as a   where   a.country like '%%%%%s%%%%' "  % lang 
    
    #nglish
    else:
        #method 1
        #com_sql2 ="select a.id,a.usr_id,a.prefer_id,a.eng_nm,a.com_addr,a.country,a.com_url,a.com_fld,b.Category from usr_pref  as a   left join ( select distinct(Category) from News_English) as b on a.Category =b.Category  and  a.country like '%%%%%s%%%%' "  % lang
        #method 2
        com_sql2 ="select a.id,a.usr_id,a.prefer_id,a.eng_nm,a.com_addr,a.country,a.com_url,a.com_fld,b.Category from usr_pref  as a   right join ( select distinct(Category) from News_English) as b on a.Category =b.Category  and  a.country like '%%%%%s%%%%' "  % lang
        #method3
        com_sql2 ="select * from usr_pref  as a  where  a.country like '%%%%%s%%%%' "  % lang
    
    print(com_sql2)
    # ----Method2
    #com_sql2 ='select id,usr_id,prefer_id,eng_nm,com_addr,country,com_url,com_fld, Category from usr_pref as a where a.usr_id='+str(usr_id)
    
    data_df1 = pd.read_sql_query(com_sql2, engine)
   
    _list_cols7 = ['Category','eng_nm','com_addr','country','com_url','com_fld', 'prefer_id','id']
    
    data_df1 =data_df1[_list_cols7]
    nextpp={}
    newlines=""
    data_df1=data_df1.drop_duplicates()
    #processing before submit
    newlines= pdataframe_pre(data_df1,usr_id,super_flg)
    
    #xuyao chongxie zhe bufen 

    _,_,pre_str=get_user(email1)
        #colss = ['Category','Date', 'Title',  'Article Score',  'Title Score','Source','Edit Once','Deleted','Action']
    print('ready to front page')  
    if session['lang'] =='Japan':
        colss = ['カテゴリ','英語名','住所','言語','会社のURL',',会社のフィールド','優先ステータス','アクション']
        return flask.render_template('j_portfolio.html',form=form,lines=newlines ,titles = colss,ee=ee ,pre_str=pre_str,jtag=jtag )  
    elif session['lang'] =='China':
      
        colss =colss = ['名称','英文名称','地址','语言','公司主页','主业','偏好状态','操作']
        return flask.render_template('ch_portfolio.html',form=form,lines=newlines ,titles = colss,ee=ee ,pre_str=pre_str,jtag=jtag )  
    else:
        colss =  ['Category','English Name','Address','Language','Category URL','Category Field','PreferStatus','Action']
        return flask.render_template('portfolio.html',form=form,lines=newlines ,titles = colss,ee=ee ,pre_str=pre_str,jtag=jtag )  
          

    #return flask.render_template('prefer_box.html' )   
        
         
#     except:
#         return 'Error when connect to DB'


#prefer Category action, config the action setting from prefer() user posting
@app.route('/pre_do', methods=['GET', 'POST'])
def pre_do():
    #fetch data
    #connect to db, and this mode can run with or without database 
    ee=''
    
    try:
        if not (session['logged_in']):
            return render_template('account_login.html')
        else:
            #user name getout
            email1= session['email'] 
    except:
        return render_template('account_login.html')
    #only give permission when it open.
    if not  _train_flag:
        flash('You have no permission,not open this permission,please check train flag in globle file')
        return redirect('/prefer')
    else:
    #     try:
        engine =get_conn()
        data_df1 = None
        usr_id=-999
      
        com_sql2=''
        com_sql2 ='select  * from  user  where email=\''+email1+'\''
        #print(com_sql2)
        data_df1 = pd.read_sql_query(com_sql2, engine)
        print( str( data_df1['id'][0] ) )
        usr_id=  data_df1['id'][0]
        super_flg =  data_df1['super_flg'][0]

        #if acton setting
        # two parameters : hide ,show
        
        #if this not blank ,will return in this part codes
        pre = str(request.args.get('pre') ).strip()
        #user id
        ddx = str(request.args.get('ddx') ).strip()
        #Category name
        name2 = str(request.args.get('nm') ).strip()
        #should check this name function appending
        #
        #not same user id,not security
        if int(ddx)!=int(usr_id):
            print('some issue with the user integrity,878')
            return redirect('/prefer')
            
        if pre=='hide' or pre=='show' :
            pre_db(pre,int(usr_id),str(name2) )
            return redirect('/prefer')
        
        # , should call one single Category calling function， F
        # From pre_do() calling the function of csv_index() ,from csv_index() calling the fetchCategory()
        elif pre=='view':
            return redirect('/csv_index?file='+str(name2))
        elif pre=='edit' and super_flg:
            return edit_Category(usr_id,name2)
     
        elif pre=='del':
            #only super user can del record
            if not super_flg:
                 flash('You are not super user,has no permission')
            else:
                #del the record
                if pre_db(pre,int(usr_id),str(name2) ):
                     flash('Super user,ONLY delete this record from PERSONAL perfer record,but if basic data contains lots records of this Category,  will keep showed in panel,you can choose to hide it.')
                else:
                    flash('You are super user,error when delete this record from your prefer record')
            return redirect('/prefer')
        #can not accept this para if not the 3.will over it.
        else:
            flash('some issues with the user,or you have no permission.')
        
            return redirect('/prefer')
                

def edit_Category(usr_id,Category):
    #get data
    data = UsrPref.query.filter_by( Category=Category, usr_id= int(usr_id) ).first()
    if data ==None:
        flash('Those Category seem not belong to you,you can hide it from your prefer')
        return redirect('/prefer')
    if request.method == 'GET':
        id=data.id
    else:
        flash('We not accept such operation method')
        return redirect('/prefer')
    #form
    form = PreForm(Category = data.Category, usr_id = data.usr_id, prefer_id =data.prefer_id,port_nm =data.port_nm,eng_nm=data.eng_nm, com_addr=data.com_addr, country=data.country,com_url=data.com_url, com_fld=data.com_fld )
    return flask.render_template('comp_edit.html',form=form ,iid=id)    

         
#     except:
#         return 'Error when connect to DB'

# modify the table of usr_pref,user prefers
def pre_db(pre,user_id,Category):
    #search it in table firstly
    try: 
        data = UsrPref.query.filter_by( Category=str(Category), usr_id= int(user_id) ).first()
        #remove one record with the super user
        if pre=='del':
            UsrPref.query.filter_by( Category=str(Category), usr_id= int(user_id) ).delete()
        # 1 means hide it in the prefer_id. so append True to the flag ,or edit it to True
        elif pre=='hide':
            if data is not None:
                data.prefer_id=user_id
                data.user_id=user_id
                db.session.commit()
            #add one record to this table
            else:
                new_data = UsrPref(Category=Category,
                                    usr_id=user_id,
                                    prefer_id= user_id,
                                    port_nm='', 
                                    eng_nm=Category, 
                                    com_addr='', 
                                    country='',
                                    com_url='', 
                                    com_fld=''
                                   )
                db.session.add(new_data)
                db.session.commit()
            
        #already filter ,so only 'show'. #remove the flag, 1 means hide it in the prefer_id. so append False to the flag ,or edit it to False
        else:
            if data is not None:
                data.prefer_id=0
                db.session.commit()
            #should not edit it if not exist in this table
            else:
                print('should not edit it if not exist in this usr_pref table')
                flash('No related records in DB,will not change the status.')
                pass
    
        return True    
    except:
        return False
    
#operating the table of english_news
#del
def rec_db(pre,user_id,idx,sum,lang):
    #search it in table firstly
    try: 
        if lang=='China':
            data1 = Scr_ch.query.filter_by( News_English_id=int(idx) ).first()
        elif lang=='Japan':
            data1 = scr_jp.query.filter_by( News_English_id=int(idx) ).first()
        else:
            data1 = Scr_Table.query.filter_by( News_English_id=int(idx) ).first()
   
        if pre=='del' or pre=='rst':
            if data1 is not None:
                try:
                    if pre=='del':
                        data1.del_flag=True
                        #data1.edit_flag=True
                    else:
                        data1.del_flag=False
                        #data1.edit_flag=False
                    db.session.commit()
                    return True
                except:
                    return False
            #should not edit it if not exist in this table
            else:
                flash('can not del it if not exist in this english news table')
                return False
        #operating failed, False
        else:
            flash('Not accept.If summary too small,will not be edited.')
            return False
        
    except:
        return False
    #use to accept the edit summary posting request
@app.route('/rec_edit',methods=['GET','POST'])
def rec_edit():
 
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except Exception as e:
        print('error reported 16:'+str(e))
        lang='English'
        
    #search it in table firstly
    try:
        idx = request.args.get('ddx')
    except Exception as e:
        print('error reported 7:'+str(e))
        flash(' not right permission')
        return redirect('/pf_mg')
    
    #checking logging status
    if idx  is not None: 
        try:
            if not (session['logged_in']):
                return render_template('account_login.html')
            else:
                #user name getout
                email1= session['email'] 
        except Exception as e:
            print('error reported 8:'+str(e))
            return render_template('account_login.html')
        #only give permission when it open.
        if not  _train_flag:
            flash('You have no permission')
            return redirect('/pf_mg')
        else:
        #     try:
            engine =get_conn()
            d_df1 = None
            usr_id=-999
          
            com_sql2=''
            com_sql2 ='select  * from  user  where email=\''+email1+'\''
            #print(com_sql2)
            d_df1 = pd.read_sql_query(com_sql2, engine)
            print( str( d_df1['id'][0] ) )
            usr_id=  d_df1['id'][0]
            super_flg =  d_df1['super_flg'][0]
            if not  super_flg:
                flash('You have no permission')
                return redirect('/pf_mg')
       
            #if this not blank ,will return in this part codes
            try:
                sum = str(request.form.get('sum')).strip()
                pre = str(request.args.get('pre') ).strip()
            except Exception as e:
                flash('no article')
                return redirect('/pf_mg')
    else:
        flash('not a right index')
        return redirect('/pf_mg')
    try: 
        if lang =='China':
             data1 = Scr_ch.query.filter_by( News_English_id=int(idx) ).first()
        elif lang=='Japan':
            data1 = scr_jp.query.filter_by( News_English_id=int(idx) ).first()
        #nglish
        else:
            data1 = Scr_Table.query.filter_by( News_English_id=int(idx) ).first()
        #remove one record with the super user
        #if less than 10,no meaning editing.
        if pre=='edit' and len(sum)>10:
            try:
                data1.Article_nltk_sum=sum
                #the flag be true
                data1.edit_flag=True
                #data1.del_flag=False
                db.session.commit()
            #add one record to this table
            except Exception as e:
                print('error reported 6:'+str(e))
                db.session.rollback()
            finally:
                #flash('not find this record')
                db.session.close()
                return redirect('/pf_mg')
            return redirect('/pf_mg')
        else:
            flash('not a valid summary,keep it')
            return redirect('/pf_mg')
    except Exception as e:
        print('error reported 9:'+str(e))
        flash('update sum failed.')
        return redirect('/pf_mg')

######### edit the form of list
@app.route('/edit_comp',methods=['GET','POST'])
def edit_comp():
    #search
    form = PreForm()
    if request.method =='POST':
        iid = request.form.get('iid')
        #iid = request.form['iid'] 
        data =UsrPref.query.filter_by(id=int(iid) ).first()
        print(request.form.get('Category'))
        #data.Category = request.form['Category']
        data.Category= request.form.get('Category')
        #data.usr_id = int(request.form['usr_id']),
        #data.prefer_id =int(usr_id),  #the user prefer it
        #data.port_nm ='',
        data.eng_nm=str(request.form.get('eng_nm'))
        data.com_addr=str(request.form.get('com_addr') )
        data.country=str(request.form.get('country') )
        data.com_url=str(request.form.get('com_url') )
        data.com_fld=str(request.form.get('com_fld') )

        db.session.commit()
      
    else:
        return redirect('/prefer') 
    
   
    return redirect('/prefer')    

###############################    
#searching in the table news english
@app.route('/news_sch',methods=['GET','POST'])
def news_sch():
    if not session['logged_in']:
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
    if request.method =='POST':
        wrd = str(request.form.get('search')).strip()
        
      
        d_df1= get_search(wrd)
        #data =News.query.filter(Title.ilike('%'+wrd+'%') , Article.ilike('%'+wrd+'%') ).all()
    
        algm = str(request.args.get('algm') ).strip()
        #avoid exception
        if not algm:
            algm='nltk'
        if len(algm)<2:
            algm='nltk'
        
        #index is None
        return show_nlp(None,d_df1,algm,lang)
    
    else:
        return 'We not understand your searching'
    print('')





#searching in the table news english,after searching, can manage those records
@app.route('/mg_sch',methods=['GET','POST'])
def mg_sch():
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
    if request.method =='POST':
        wrd = str(request.form.get('search')).strip()
        
      
        d_df1= get_search(wrd)
        #data =News.query.filter(Title.ilike('%'+wrd+'%') , Article.ilike('%'+wrd+'%') ).all()
        
        algm = str(request.args.get('algm') ).strip()
        #avoid exception
        if not algm:
            algm='nltk'
        if len(algm)<2:
            algm='nltk'
        
        #index is None
        #duplicate index ,
#         d_df1.drop(columns = ['News_English_id'])
#         if df_html1.News_English_id.duplicated():
#       

        return pf_mg_page(d_df1,lang)
    else:
        return 'We not understand your searching'
    print('')    


#bert
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%


        
@app.route('/bert_sent', methods=['GET', 'POST'])
def bert_sent():
    start = float( time.time() )

    global summary_reading_time_nltk
    # Here are multi methods to generate a sentiment score 
    #  https://www.programcreek.com/python/example/100005/nltk.sentiment.vader.SentimentIntensityAnalyzer
    
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except Exception as e:
        print(str(e))
        pass
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        

    if flask.request.method == 'POST':
        raw_url = request.form['raw_url']
        rawtext = str((raw_url) )
        final_reading_time = readingtime(rawtext)
        #locate to the algorithm tab, show the special tab
        try:
            tact = flask.request.form['tact']
            #tact = request.form.get('tact')
        except:
            tact='1'  #initializing
        try:
            ginza_plus = flask.request.form['ginza']
            #tact = request.form.get('tact')
        except:
            ginza_plus='0'  #initializing
       
        final_reading_time = readingtime(rawtext)
        
        try:
            final_summary_spacy = text_summarizer(rawtext)
        except:
            final_summary_spacy = '0056,Maybe you input some illegal text for this NLP library,please input at least one sentence.'
        summary_reading_time = readingtime(final_summary_spacy)
        
        # Gensim Summarizer
        try:
            final_summary_gensim = summarize(rawtext)
        except:
            final_summary_gensim = '003,Maybe you input some illegal text for this NLP library ,please input at least one sentence.'
        summary_reading_time_gensim = readingtime(final_summary_gensim)
        
        try:
            # NLTK
            final_summary_nltk = nltk_summarizer(rawtext,lang)
        except:
            final_summary_nltk= '004,Maybe you input some illegal textfor this NLP library,please input at least one sentence.'
        summary_reading_time_nltk = readingtime(final_summary_nltk)
        
        try:
            # Sumy
            final_summary_sumy = sumy_summary(rawtext,lang)
        except:   
            final_summary_sumy = '005,Maybe you input some illegal text for this NLP library,please input at least one sentence.'
        summary_reading_time_sumy = readingtime(final_summary_sumy)


        #Sentiment score return
        sent = analyzeText(rawtext,lang)
        bert_scr,bert_sum=bert_sent(rawtext)
        end = time.time()
        final_time = end - start

        if lang=='China':
            return flask.render_template('ch_index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                         final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                         final_time=final_time, final_reading_time=final_reading_time,
                                         summary_reading_time=summary_reading_time,
                                         summary_reading_time_gensim=summary_reading_time_gensim,
                                         final_summary_sumy=final_summary_sumy,
                                         summary_reading_time_sumy=summary_reading_time_sumy,
                                         summary_reading_time_nltk=summary_reading_time_nltk,
                                         sent = sent,tact=tact)
        elif lang=='Japan':
            #ginza is a algorithm ,be added lately, so there is a seperate index page to show it,below without ginza
            if not ginza_plus:
                return flask.render_template('j_index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                         final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                         final_time=final_time, final_reading_time=final_reading_time,
                                         summary_reading_time=summary_reading_time,
                                         summary_reading_time_gensim=summary_reading_time_gensim,
                                         final_summary_sumy=final_summary_sumy,
                                         summary_reading_time_sumy=summary_reading_time_sumy,
                                         summary_reading_time_nltk=summary_reading_time_nltk,
                                         sent = sent,tact=tact,bert_scr=bert_scr,bert_sum=bert_sum)
            #ginza plus processing, 
            else:
                doc_sents=ginza_analysis(rawtext,lang)
                return flask.render_template('j_index_ginza.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                         final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                         final_time=final_time, final_reading_time=final_reading_time,
                                         summary_reading_time=summary_reading_time,
                                         summary_reading_time_gensim=summary_reading_time_gensim,
                                         final_summary_sumy=final_summary_sumy,
                                         summary_reading_time_sumy=summary_reading_time_sumy,
                                         summary_reading_time_nltk=summary_reading_time_nltk,
                                         sent = sent,tact=tact,ginza_sents=doc_sents,bert_scr=bert_scr,bert_sum=bert_sum)
                
        else:
            return flask.render_template('index.html', ctext=rawtext, final_summary_spacy=final_summary_spacy,
                                         final_summary_gensim=final_summary_gensim, final_summary_nltk=final_summary_nltk,
                                         final_time=final_time, final_reading_time=final_reading_time,
                                         summary_reading_time=summary_reading_time,
                                         summary_reading_time_gensim=summary_reading_time_gensim,
                                         final_summary_sumy=final_summary_sumy,
                                         summary_reading_time_sumy=summary_reading_time_sumy,
                                         summary_reading_time_nltk=summary_reading_time_nltk,
                                         sent = sent,tact=tact,bert_scr=bert_scr,bert_sum=bert_sum)



    else:
        
        if session['lang'] =='Japan':
            return flask.render_template('j_bert.html')
        elif  session['lang'] =='China':
            return flask.render_template('bert.html')
        else:
            return flask.render_template('bert.html')

    



def bert_sent(text1):
#     #load pre-train model
#     model = BertForMaskedLM.from_pretrained(BERT_BASE_DIR)
#     #load mecab tokenizer
#     model.output_hidden_states = False #APPEND TEMPRARY JIN
#     #if error raised ,please uninstall transformers, and re-install version 2.8.0 it  2.7.0, 2.8.0, 2.9.0, 2.9.1, 2.10.0, 2.11.0, 3.0.0, 3.0.1, 3.0.2)
#     #currently , only transformers version 2.8.0 worked on this ,comments by jin 20200828
#     tokenizer = MecabBertTokenizer(vocab_file=f'{BERT_BASE_DIR}/vocab.txt')
#     # Use MecabCharacterBertTokenizer instead for char-4k models
#     
#     text = '朝食に[MASK]を焼いて食べました。'
#     
#     token_ids = tokenizer.encode(text, add_special_tokens=True)
#     
#     tokens = tokenizer.convert_ids_to_tokens(token_ids)
#     
#     token_ids = torch.tensor([token_ids])
#     #填空的mask，临时保留了，因为不确定后续的开发需求
#     predictions, = model(token_ids)
#     _, top10_pred_ids = torch.topk(predictions, k=10, dim=2)
#     
#     for correct_id, pred_ids in zip(token_ids[0], top10_pred_ids[0]):
#         correct_token = tokenizer.convert_ids_to_tokens([correct_id.item()])
#         pred_tokens = tokenizer.convert_ids_to_tokens(pred_ids.tolist())
#         print(correct_token, pred_tokens)
        
    

    #japan sentence
    bert_scr = (nlp_bert_sent_pipe(text1))
    #summary
    from summarizer import Summarizer
    #model of summary
    model_sum = Summarizer()
    #? work on English ,JP not worked?.
    result_sum = model_sum(text1 , min_length=60)
    full_sum = ''.join(result_sum)
    
    bert_sum= (full_sum)

    return bert_scr,bert_sum
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


# verify user permission ,return user id
def get_user(email1):
    engine =get_conn()
    d_df1 = None
    usr_id=-999
    try:
        com_sql2=''
        com_sql2 ='select  * from  user  where email=\''+email1+'\''
        #print(com_sql2)
        d_df1 = pd.read_sql_query(com_sql2, engine)
        print( str( d_df1['id'][0] ) )
        usr_id=  d_df1['id'][0]
        super_flg =  d_df1['super_flg'][0]
        pre_str1 =  d_df1['like_news'][0]
    
        return usr_id,super_flg,pre_str1
    except Exception as e:
        print('user id getting issue:'+str(e) )
        return -99,0,None

#abstract the public part, reuse it   save and  search key word from db
def save_srch(wrd,lang1):
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    #user name getout
    email1= session['email'] 
        
    usr_id,super_id,_=get_user(email1)
    now        =datetime.datetime.now()
    curr       =now.strftime('%Y-%m-%d')
    wrd=str(wrd).rstrip()

    engine =get_conn()
    valuess='VALUES ({},\'{}\',\'{}\',\'{}\')'.format(usr_id,wrd,curr,lang1)
    com_sql2 ='insert into news_spec (user_id,news_tag,date,language) '+valuess
    print(com_sql2)
    try:
        pd.read_sql_query(com_sql2, engine)
        #return True
    except:
        return False
    return True   


 
    
#abstract the public part, reuse it   save and  search key word from db, the user index page portfolio
def upd_setting_news(wrd,usr_id):
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
        
    wrd=str(wrd).rstrip()

    if wrd==None or len(str(wrd))<1:
        return False

    # 使用正则表达式去匹配标点符号
    wrd = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",wrd)

    engine =get_conn()

    com_sql2 ='update user set like_news='+'\''+wrd+'\''+" where id="+str(usr_id)
    print(com_sql2)
    try:
        pd.read_sql_query(com_sql2, engine)
        #return True
    except:
        pass
    return True    
    
#abstract the public part, reuse it    .search key word from db
def get_search(wrd):
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
    wrd=str(wrd)
    #2 part right last 1 split
    lnstr=1    
    wrd= re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",wrd)

    wdlst= wrd.rsplit(' ', 1)

    lnstr=len(wdlst)
    
    pre_sql= inner_conn()
    
    engine =get_conn()
    d_df1 = None  
    com_sql2=''
    
    if lang =='China':
        if lnstr>1:
            com_sql2 ="select a.News_English_id,a.Category,a.Title,a.Article,a.Author,a.Link,a.Source,a.Date,b.Article_nltk_sum,b.Article_spacy_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive,b.Article_negative,b.Article_neutral,b.Article_compound,b.Title_positive,b.Title_negative,b.Title_neutral,b.Title_compound,b.edit_flag,b.del_flag from News_CH a  right join scr_ch b on a.News_English_id =b.News_English_id where b.del_flag !=True and  Article like '%%%%%s%%%%' "  % wdlst[0] +" or  Article like '%%%%%s%%%%' " % wdlst[1] +pre_sql
        else:
            com_sql2 ="select a.News_English_id,a.Category,a.Title,a.Article,a.Author,a.Link,a.Source,a.Date,b.Article_nltk_sum,b.Article_spacy_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive,b.Article_negative,b.Article_neutral,b.Article_compound,b.Title_positive,b.Title_negative,b.Title_neutral,b.Title_compound,b.edit_flag,b.del_flag from News_CH a  right join scr_ch b on a.News_English_id =b.News_English_id where b.del_flag !=True and  Article like '%%%%%s%%%%' "  % wrd +pre_sql
    
    elif lang=='Japan':
        if lnstr>1:
            com_sql2 ="select a.News_English_id,a.Category,a.Title,a.Article,a.Author,a.Link,a.Source,a.Date,b.Article_nltk_sum,b.Article_spacy_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive,b.Article_negative,b.Article_neutral,b.Article_compound,b.Title_positive,b.Title_negative,b.Title_neutral,b.Title_compound,b.edit_flag,b.del_flag from News_JP a  right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True and  Article like '%%%%%s%%%%' "  % wdlst[0] +" or  Article like '%%%%%s%%%%' " % wdlst[1] +pre_sql
    
        else:
            com_sql2 ="select a.News_English_id,a.Category,a.Title,a.Article,a.Author,a.Link,a.Source,a.Date,b.Article_nltk_sum,b.Article_spacy_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive,b.Article_negative,b.Article_neutral,b.Article_compound,b.Title_positive,b.Title_negative,b.Title_neutral,b.Title_compound,b.edit_flag,b.del_flag from News_JP a  right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True and  Article like '%%%%%s%%%%' "  % wrd +pre_sql
    
    #nglish
    else:
    #com_sql2 ='select  * from  News_English  where Title like \'%'+wrd+'%\' or Article like \'%'+wrd+'%\';'
    #ss=" and  Article like '%%%%%s%%%%' " % wrd
        if lnstr>1:
            com_sql2 ="select a.News_English_id,a.Category,a.Title,a.Article,a.Author,a.Link,a.Source,a.Date,b.Article_nltk_sum,b.Article_spacy_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive,b.Article_negative,b.Article_neutral,b.Article_compound,b.Title_positive,b.Title_negative,b.Title_neutral,b.Title_compound,b.edit_flag,b.del_flag from News_English a  right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True and  Article like '%%%%%s%%%%' "  % wdlst[0] +" or  Article like '%%%%%s%%%%' " % wdlst[1] +pre_sql
        else:
            com_sql2 ="select a.News_English_id,a.Category,a.Title,a.Article,a.Author,a.Link,a.Source,a.Date,b.Article_nltk_sum,b.Article_spacy_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive,b.Article_negative,b.Article_neutral,b.Article_compound,b.Title_positive,b.Title_negative,b.Title_neutral,b.Title_compound,b.edit_flag,b.del_flag from News_English a  right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True and  Article like '%%%%%s%%%%' "  % wrd +pre_sql
    
    #print(com_sql2)
    d_df1 = pd.read_sql_query(com_sql2, engine)
    return d_df1
    
######### user auth end ###############
#  auto update the basic data set interface for the data maintainer
@app.route("/auto_up")
def auto_up():
    return 'please auto update your data ,and auto update the data into database,just return YES or No.Please supply your whole program with one INTERFACE function.'




##############################3  Perhaps is the temparory module???
# is the 17 goals index page
@app.route('/seven_i', methods=['GET', 'POST'])
def seven_i():

    #read the 17 goals index 
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
     
    if lang =='China':
        return flask.render_template('ch_HelpingScore.html' ) 
    elif lang =='Japan':
        return flask.render_template('j_seven_i.html' )
    else:
        
        return flask.render_template('seven_i.html' )  





##################### end of  module

#jp stock list 
@app.route('/jp_list', methods=['GET', 'POST'])
def jp_list():
    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
    df11= load_xls(lang)
    if df11 is not None:
        jsonfiles = json.loads(df11.to_json(orient='records'))
    else:
        jsonfiles = None
    print('ready to front page7')

    return flask.render_template('j_stock_list.html', lines1=jsonfiles,lang=lang )  

#only for updating the companys pictures. Those pictures will be using in news,cordirate
@app.route('/company_img_dw', methods=['GET', 'POST'])
def company_img_dw():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
        email1=session['email']
        usr_id,super_id,_=get_user(email1)
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    if super_id<2:
        flash("Only user level 2 can updating all the companys pictures,plz logout and login with level 2")
        return redirect('/index_main')

    try: 
        #scraping image thread
        th1 = threading.Thread(target = usa_jp_img_scrp )
        threads.append(th1)
        th1.start()
        flash('company images updating now.')
        
    except Exception as e:
        print('img updating,error:'+str(e))
        pass
    
    return redirect('/index_main')
    

def usa_jp_img_scrp():
        #usa company
        df11= load_xls('English')
        image_path = os.getcwd()+"/static/company_img"
        search_keys= df11['name']
        number_of_images = 5
        #important flag,means open 
        headless = False
        min_resolution=(0,0)
        max_resolution=(9999,9999)
        #usa nasdaq company
        scrape_company_jpg(image_path,search_keys,number_of_images,headless,min_resolution,max_resolution)
        
        #japan company
        df11= load_xls('Japan')
        #already  be convert to lower
        search_keys= df11['tname']
      
        #japan stock company pic
        scrape_company_jpg(image_path,search_keys,number_of_images,headless,min_resolution,max_resolution)


#jp stock list 
@app.route('/us_list', methods=['GET', 'POST'])
def us_list():
    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
    df11= load_xls(lang)
    if df11 is not None:
        jsonfiles = json.loads(df11.to_json(orient='records'))
    else:
        jsonfiles = None
    print('ready to front page57')

    return flask.render_template('stock_list.html', lines1=jsonfiles,lang=lang )  

#jp stock list ,ready scraping data of the stock ticker
@app.route('/us_list_scrape', methods=['GET', 'POST'])
def us_list_scrape():
    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
    df11= load_xls(lang)
    if df11 is not None:
        jsonfiles = json.loads(df11.to_json(orient='records'))
    else:
        jsonfiles = None
    print('ready to front page587')

    return flask.render_template('stock_list_scraping.html', lines1=jsonfiles,lang=lang )  

#doing 
# us stock list ,ready download data of the stock ticker
@app.route('/stock_news_dw', methods=['GET', 'POST'])
def stock_news_dw():
    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
    df11= load_xls(lang)
    if df11 is not None:
        jsonfiles = json.loads(df11.to_json(orient='records'))
    else:
        jsonfiles = None
    print('ready to front page587')
    if lang=='Japan':
        return flask.render_template('j_stock_list_news.html', lines1=jsonfiles,lang=lang )
    else:
        return flask.render_template('stock_list_news.html', lines1=jsonfiles,lang=lang )  





#history of searching special tags
@app.route('/spec_news_hsry', methods=['GET', 'POST'])
def spec_news_hsry():
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
        email1= session['email'] 
    except:
        lang='English'
    if lang=='Japan':
        lang1='ja'
    else:
        lang1='en'    
                #user name getout

    usr_id,super_id,_=get_user(email1)

    engine =get_conn()

    com_sql1 ='select * from news_spec where user_id={} and language =\'{}\' '.format(usr_id,lang1)

    #print(com_sql1)
    df11 = pd.read_sql_query(com_sql1, engine)
    jsonfiles=''
    if df11 is not None and len(df11)>0:
        for idx, row in df11.iterrows():
            #jsonfiles=df11['date'].dt.date.astype(str).to_json()
            df11['date'].apply(lambda x: x.strftime('%Y-%m-%d')) 
            #jsondt=df11['date'].astype(str).strftime('%Y-%m-%d').to_json()
            #jsondt=(df11['date']).apply(lambda x : str(x).strftime('%Y-%m-%d')).to_json()
            #jsonfiles=json.loads(df11.to_json(orient='records'))
            #jsonfiles=(json.dumps(df11, cls=JsonToDatetime))
            tempj="<tr><td>{}</td> <td>{}</td>  <td> {}</td> <td><a href=\"/jp_stk_news?ticker=\'{}\'&jtag=0&jtype=0&algm=spacy&chk=0\">見る</td></tr>".format( row['news_tag'],row['date'],row['language'],row['news_tag']) 
            jsonfiles+=tempj         
                                    
        #jsonfiles['date'] =jsondt['date'].astype(str)
    else:
        jsonfiles = None
    print('ready to front page667')
    #jsonfiles['date'].strftime('%Y-%m-%d') 
    #jsonfiles['date'].apply(lambda x: x.strftime('%Y-%m-%d'))
    if lang=='Japan':
        return flask.render_template('j_search_list.html', lines1=jsonfiles,lang=lang )
    else:
        return flask.render_template('search_list.html', lines1=jsonfiles,lang=lang )  

#manage download the specific files of news.
#history of searching special tags
@app.route('/spec_news_down', methods=['GET', 'POST'])
def spec_news_down():
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
        email1= session['email'] 
    except:
        lang='English'
    if lang=='Japan':
        lang1='ja'
    else:
        lang1='en'    
                #user name getout

    usr_id,super_id,_=get_user(email1)

    engine =get_conn()

    com_sql1 ='select * from news_spec where user_id={} and language =\'{}\' '.format(usr_id,lang1)
    
    #print(com_sql1)
    df11 = pd.read_sql_query(com_sql1, engine)
    jsonfiles=''
    
    #tmp_link_folder = 'data/{}/{}'.format(lang1, keyword)
    
    if df11 is not None and len(df11)>0:
        for idx, row in df11.iterrows():
            #jsonfiles=df11['date'].dt.date.astype(str).to_json()
            df11['date'].apply(lambda x: x.strftime('%Y-%m-%d')) 
            #jsondt=df11['date'].astype(str).strftime('%Y-%m-%d').to_json()
            #jsondt=(df11['date']).apply(lambda x : str(x).strftime('%Y-%m-%d')).to_json()
            #jsonfiles=json.loads(df11.to_json(orient='records'))
            #jsonfiles=(json.dumps(df11, cls=JsonToDatetime))
            tempj="<tr><td>{}</td> <td>{}</td>  <td> {}</td> <td><a href=\"/jp_stk_news?ticker=\'{}\'&jtag=0&jtype=0&algm=spacy&chk=0\">見る</td><td><a href=\'/download?fn={}&type=tags\'> DOWNLOAD ALL </a></td></tr>".format( row['news_tag'],row['date'],row['language'],row['news_tag'],row['news_tag']) 
            jsonfiles+=tempj         
                                    
        #jsonfiles['date'] =jsondt['date'].astype(str)
    else:
        jsonfiles = None
    print('ready to front page667')
    #jsonfiles['date'].strftime('%Y-%m-%d') 
    #jsonfiles['date'].apply(lambda x: x.strftime('%Y-%m-%d'))
    if lang=='Japan':
        return flask.render_template('j_search_list_down.html', lines1=jsonfiles,lang=lang )
    else:
        return flask.render_template('search_list_down.html', lines1=jsonfiles,lang=lang )  


#jp stock list ,scraping special stock news of Japan market
@app.route('/jp_list_scrape', methods=['GET', 'POST'])
def jp_list_scrape():
    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
    df11= load_xls(lang)
    if df11 is not None:
        jsonfiles = json.loads(df11.to_json(orient='records'))
    else:
        jsonfiles = None
    print('ready to front page7')

    return flask.render_template('j_stock_list_scrape.html', lines1=jsonfiles,lang=lang )  

# News scraring,progress bar ,the progessing bar of scraping news ,show it to user
@app.route('/progress/<keywords>')
def progress(keywords):
    try:
        lang = None
        lang=session['lang']
        email1= session['email'] 
    except:
        lang='English'
    tf_path=tempfile.gettempdir()
    session['path']=tf_path+"/tmp" + ''.join(random.choice(string.ascii_letters) for x in range(6))
    session['query']=keywords
    if lang=='English':
        return render_template('progress.html')
    else:
        return render_template('j_progress.html')

# News scraring,progress bar ,the sosearch pages submits progress, and save results to the temp file. Upon completion, it closes the result file and redirects to the showresult page.  
@app.route('/dosearch')
def dosearch():
    query=session['query']
    out=open(session['path']+"result", "w+")
    def generate(query):
        x = 0
        result=str()
        while x <= 100:
            # do some work on query
            result+=query+str(x)+" <br>"
            out.write(result)
            if x==100:
                out.close()
            yield "data:"+str(x)+"\n\n"
            x = x + 0.02
            time.sleep(5)
    return Response(generate(query), mimetype= 'text/event-stream')

#News scraring,progress bar ,
@app.route('/showresult')
def showresult():
    with open (session['path']+"result", "r") as f:
        result=f.read()
    return render_template('results.html', results=result)


#from us_list_scrape to this method
@app.route('/stk_news_scaping', methods=['GET', 'POST'])
def stk_news_scaping():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    else:
        #user name getout
        email1= session['email'] 
        
    usr_id,super_id,_=get_user(email1)
    
    try:
        lang = None
        lang=session['lang']
    except:
        lang='English'
        
   
    if request.method =='GET':
        #get the setting 
        wrd = request.args.get('ticker') 
        wrd = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",wrd)
        try:
            pgmode= request.args.get('pgmode') 
        except:
            pgmode= 1
        jtag= request.args.get('jtag')
        chk = request.args.get('chk') 
        
        if  int(super_id)<2:
            flash('You are not super user level 2, no download news permission')
            return render_template('account_login.html')
        else:
            #need saving this news setting
            pass
            
        #get user prefer again
        #run the  scrapihng and saving to the DB
        #JP
        if lang=='Japan':
            lang1='ja'
        elif lang=='China':
            lang1='cn'
        else:
            lang1='en'
        key_words=wrd.split(",")
        #run_goog_vpn_scraping_news(keywords: list = None, language='ja', limit=50, retrieve_content_behind_links=True, num_threads=1):
        
        #start threading of scraping
        try:
            #(keywords: list = None, language='ja', limit=100, retrieve_content_behind_links=True, num_threads=1)
            th1 = threading.Thread(target = main_vpn.run_goog_vpn_scraping_news, args=(key_words, lang1, News_scrape_max, True, 1,) )
  
            threads.append(th1)
            th1.start()
            #record the spec words
            
            if save_srch(wrd,lang1):
                logger.info('user %s  Save tags [%s] into DB,false.' % (email1, pre_str))
            print ("Scraping Thread(s) started..")
            #now can redirect to new page.
            return redirect(url_for("progress", keywords=wrd))
        except Exception as e:
            print ("Error: unable to start thread(s),"+str(e))
            logger.info('Error: user %s unable to start scraping thread-[%s].' % (email1, wrd)) 
            os._exit(1)
            
        
        #main_vpn.run_goog_vpn_scraping_news(key_words, lang1, 2, True, 1)  
        
        if save_srch(wrd,lang1):
            logger.info('user %s  Save tags [%s] into DB,false.' % (email1, wrd))
        else:
            logger.info('user %s  Save tags [%s] into DB,success.' % (email1, wrd))
        print('DO YOU WANT SAVE THIS DATA INTO DB?,Please coding')
     
        
        pre_str1  = wrd.strip()
        if pre_str1 is not None:
            if len(pre_str1)>2:
        
                # 使用正则表达式去匹配标点符号
                pre_str1 = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",pre_str1)
                #cc1=re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！，。？、~@#￥%……&*；（）]+", "",cc1)
                #print(cc1)
               
                # 所有标点--result = re.sub("[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？、~@#￥%……&*（）]+", "",result)
                pre_str1  = pre_str1.strip().replace(',', '|')
                pre_str1 = ' and Article RLIKE ' +'\''+pre_str1+'\''
            #pre_str1 = "|".join([x.repace(',','').strip() for x in pre_str1])
            
            else:
                #index page, 100 is enough
                pre_str1=' limit 0,100 '
        else:
            #index page, 100 is enough
            pre_str1=' limit 0,100 '
        
        
        print(pre_str1)
        
        engine =get_conn()
        #del_flag  this record had been filter by user
        
        #JP
        if lang=='Japan':
            com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True '+ pre_str1
        else:
            #English news
            com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True  '+ pre_str1
    
        #print(com_sql1)
        data_df1 = pd.read_sql_query(com_sql1, engine)
        #NOW,already get the df,will output to the front page
        try:
            algm = str(request.args.get('algm') ).strip()
        except:
            algm='spacy'
        #avoid exception
        if not algm:
            algm='spacy'
        if len(algm)<2:
            algm='spacy'
        print('ready to front page166')
        #index is None
        
        _,_,pre_str=get_user(email1)
    
        try:
            data_df1 = data_df1[~( data_df1['Article'].isnull() )]
            #data_df2 = data_df2[~( data_df2['Article'].isnull() )]
               
            #clean the data of article ,clean the extra return
            data_df1=data_df1.replace('\n\n', '\n')
            #data_df2=data_df2.replace('\n\n', '\n')
        except:
            pass

        #format type 1
        if str(chk)=='1':
            return show_nlp(None,data_df1,algm,lang)
        #format type 2
        else:
            return show_nlp_index(data_df1,algm,lang,pre_str,pre_str1,pgmode)
    else:
        return redirect('/jp_list')




# NASDAQ
# 
# https://old.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=nasdaq&render=download
# AMEX
# 
# https://old.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=amex&render=download
# NYSE
# 
# https://old.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=nyse&render=download
      
#jp stock list 
@app.route('/jp_stk_news', methods=['GET', 'POST'])
def jp_stk_news():
    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
   
    if request.method =='GET':
        #get the setting 
        wrd = request.args.get('ticker') 
        jtag= request.args.get('jtag')
        chk = request.args.get('chk') 
        pre_str1  = wrd.strip()
        try:
            pgmode= request.args.get('pgmode') 
        except:
            pgmode= 1
      
        if len(pre_str1)>2:
    
            # 使用正则表达式去匹配标点符号
            pre_str1 = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！，。？、~@#￥%……&*；（）]+", " ",pre_str1)
            #cc1=re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！，。？、~@#￥%……&*；（）]+", "",cc1)
            #print(cc1)
           
            # 所有标点--result = re.sub("[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？、~@#￥%……&*（）]+", "",result)
            pre_str1  = pre_str1.strip().replace(',', '|')
            pre_str1 = ' and Article RLIKE ' +'\''+pre_str1+'\''
        #pre_str1 = "|".join([x.repace(',','').strip() for x in pre_str1])
        
        else:
            #index page, 100 is enough
            pre_str1=' limit 0,1000'


        print(pre_str1)
        engine =get_conn()
        #del_flag  this record had been filter by user
        
        #JP
        if lang=='Japan':
            com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True '+ pre_str1
        else:
            #English news
            com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True '+ pre_str1
    
        print(com_sql1)
        data_df1 = pd.read_sql_query(com_sql1, engine)
        #NOW,already get the df,will output to the front page
        try:
            algm = str(request.args.get('algm') ).strip()
        except:
            algm='spacy'
        #avoid exception
        if not algm:
            algm='spacy'
        if len(algm)<2:
            algm='spacy'
        print('ready to front page166')
        #index is None
        
        _,_,pre_str=get_user(email1)
    
        try:
            data_df1 = data_df1[~( data_df1['Article'].isnull() )]
            #data_df2 = data_df2[~( data_df2['Article'].isnull() )]
               
            #clean the data of article ,clean the extra return
            data_df1=data_df1.replace('\n\n', '\n')
            #data_df2=data_df2.replace('\n\n', '\n')
        except:
            pass

        #format type 1
        if str(chk)=='1':
            return show_nlp(None,data_df1,algm,lang)
        #format type 2
        else:
            return show_nlp_index(data_df1,algm,lang,pre_str,pre_str1,pgmode)
    else:
        return redirect('/jp_list')


#PDF to text , convert doc docx rtf odt to text
@app.route('/docrtfodt_to_txt', methods=['GET', 'POST'])
def docrtfodt_to_txt():

    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
    start = time.time()
    #direct to the upload front page
    if request.method =='GET':
        return render_template("docrtfodt_to_text_idx.html",lang=lang)
    #POST method
    else:
        
        # Create a unique "session ID" for this particular batch of uploads.
        upload_key1 = str(uuid4())
        ###   the beginning of upload form processing
        """Handle the upload of a file."""
        form = request.form
    

    
        # Is the upload using Ajax, or a direct POST by the form?
        is_ajax = False
        if form.get("__ajax", None) == "true":
            is_ajax = True
    
        # Target folder for these uploads.
        target = "static/uploads/{}".format(upload_key1)
        try:
            os.mkdir(target)
        except:
            if is_ajax:
                return ajax_response(False, "Couldn't create upload directory: {}".format(target))
            else:
                return "Couldn't create upload directory: {}".format(target)
    
        print("=== Form Data ===")
        for key, value in list(form.items()):
            print(key, "=>", value)
            
        print(str(request.files.getlist("file")))
        try:
            for upload in request.files.getlist("file"):
                filename = upload.filename.rsplit("/")[0]
                destination = "/".join([target, filename])
                print("Accept incoming file:", filename)
                print("Save it to:", destination)
                upload.save(destination)
        except Exception as e:
            print(str(e))
            return "not supporting file"+str(e)
        if is_ajax:
            return ajax_response(True, upload_key1)
        else:
            return redirect(url_for("up_docrtfodt_cmp", uuid1=upload_key1))
   
#############the upload file part##############
@app.route("/files2/<uuid1>")
def up_docrtfodt_cmp(uuid1):
    """The location we send them to at the end of the upload."""

    # Get their files.
    
    root = "static/uploads/{}".format(uuid1)
    print("myroot:"+str(root))
    if not os.path.isdir(root):
        return "Error: UUID not found!"

    files2 = []
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    lang = None
    try:
        
        lang=session['lang']
        #user name getout
        email1= session['email'] 
        for file in glob.glob("{}/*.*".format(root)):
            fname = file.split(os.sep)[-1]
            files2.append(fname)
    except:
        lang='English'

    print("Please append file type detect method here")
 
    jsonfiles  = docrtfodt_text_nlp(root,files2,lang)  
    if jsonfiles is None:
        return "Error: empty content !"
    #jsonfiles = json.loads(df6.to_json(orient='records'))
#     return render_template("pdf_files.html",
#         uuid=uuid,
#         files=files,
#     )


#     if lang=='Japan':
#         #ginza is a algorithm ,be added lately, so there is a seperate index page to show it,below without ginza
#         
#         return flask.render_template('j_pdf_files.html', uuid=uuid,files=files,jsonfiles=jsonfiles )
#         #ginza plus processing, 
# 
#             
#     else:
    return flask.render_template('pdf_files.html' , uuid=uuid1,files=files2,jsonfiles=jsonfiles )
    

        

#PDF to text , convert PDF to text
@app.route('/pdf_to_text', methods=['GET', 'POST'])
def pdf_to_text():

    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        lang = None
        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
    start = time.time()
    #direct to the upload front page
    if request.method =='GET':
        return render_template("pdf_index.html",lang=lang)
    #POST method
    else:
        
        # Create a unique "session ID" for this particular batch of uploads.
        upload_key = str(uuid4())
        ###   the beginning of upload form processing
        """Handle the upload of a file."""
        form = request.form
    

    
        # Is the upload using Ajax, or a direct POST by the form?
        is_ajax = False
        if form.get("__ajax", None) == "true":
            is_ajax = True
    
        # Target folder for these uploads.
        target = "static/uploads/{}".format(upload_key)
        try:
            os.mkdir(target)
        except:
            if is_ajax:
                return ajax_response(False, "Couldn't create upload directory: {}".format(target))
            else:
                return "Couldn't create upload directory: {}".format(target)
    
        print("=== Form Data ===")
        for key, value in list(form.items()):
            print(key, "=>", value)
            
        print(str(request.files.getlist("file")))
        try:
            for upload in request.files.getlist("file"):
                filename = upload.filename.rsplit("/")[0]
                destination = "/".join([target, filename])
                print("Accept incoming file:", filename)
                print("Save it to:", destination)
                upload.save(destination)
        except Exception as e:
            print(str(e))
            return "not supporting file"+str(e)
        if is_ajax:
            return ajax_response(True, upload_key)
        else:
            return redirect(url_for("upload_complete", uuid=upload_key))
   

       
    
#############the upload file part##############
@app.route("/files/<uuid>")
def upload_complete(uuid):
    """The location we send them to at the end of the upload."""

    # Get their files.
    
    root = "static/uploads/{}".format(uuid)
    print("myroot:"+str(root))
    if not os.path.isdir(root):
        return "Error: UUID not found!"

    files = []
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    lang = None
    try:
        
        lang=session['lang']
        #user name getout
        email1= session['email'] 
        for file in glob.glob("{}/*.*".format(root)):
            fname = file.split(os.sep)[-1]
            files.append(fname)
    except:
        lang='English'

    print("Please append file type detect method here")
    file_type = 'pdf'
    jsonfiles  = pdf_text_nlp(root,files,lang,file_type)  
    if jsonfiles is None:
        return "Error: empty content !"
    #jsonfiles = json.loads(df6.to_json(orient='records'))
#     return render_template("pdf_files.html",
#         uuid=uuid,
#         files=files,
#     )


#     if lang=='Japan':
#         #ginza is a algorithm ,be added lately, so there is a seperate index page to show it,below without ginza
#         
#         return flask.render_template('j_pdf_files.html', uuid=uuid,files=files,jsonfiles=jsonfiles )
#         #ginza plus processing, 
# 
#             
#     else:
    return flask.render_template('pdf_files.html' , uuid=uuid,files=files,jsonfiles=jsonfiles )



   
#index of audio to nlp

@app.route('/audio_index', methods=['GET', 'POST'])
def audio_index():
    return render_template('audio_index.html')
#audio recorder page
@app.route('/audio_to_text', methods=['GET', 'POST'])
def audio_to_text():
    flash(" Press Start to start recording audio and press Stop to end recording audio")
        #get the language
    lang = None
    try:
        
        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
    ##return render_template('audio_to_text.html')
    return flask.render_template('audio_to_text.html', lang=lang )

#key function of the audio to text
@app.route('/audio', methods=['POST'])
def audio():

    return audio_f_txt('upload/audio.wav')
    
def  audio_f_txt(filen):
    lang = None
    try:
        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
    r = sr.Recognizer()
    with open(filen, 'wb') as f:
        f.write(request.data)
  
    with sr.AudioFile(filen) as source:
        audio_data = r.record(source)
        #english to text
        #text = r.recognize_google(audio_data, language='en-IN', show_all=True)
        
        if lang == 'Japan':
            #japanese,by shuxin.jin@hotmail.com
            text = r.recognize_google(audio_data, language='ja-JP', show_all=False)
        else:
            #english to text
            #text = r.recognize_google(audio_data, language='en-IN', show_all=True)
            text = r.recognize_google(audio_data, language='en-IN', show_all=False)
            #ch-ZN
        print(text)
        try:
            with open("audio_tmp.txt", "a") as myfile:
                    myfile.write(text)
                    myfile.write("\n")

        except Exception as e:
            print("Unable input into text"+str(e) )

#         return_text = " Did you say : <br> "
#         try:
#             for num, texts in enumerate(text['alternative']):
#                 return_text += str(num+1) +") " + texts['transcript']  + " <br> "
#         except:
#             return_text = " Sorry!!!! Voice not Detected "

        df6= audio_txt_nlp(text,lang) 
        
        jsonfiles = json.loads(df6.to_json(orient='records'))

        if lang=='Japan':
            #ginza is a algorithm ,be added lately, so there is a seperate index page to show it,below without ginza
            
            return flask.render_template('j_pdf_files.html', uuid=None,files=filen,jsonfiles=jsonfiles )
            #ginza plus processing, 
            os._exit(1)
                    
        else:
            return flask.render_template('pdf_files.html' , uuid=None,files=filen,jsonfiles=jsonfiles )
            os._exit(1)

#upload audio file to nlp
@app.route('/up_audio_idx', methods=['GET', 'POST'])
def up_audio_idx():
    transcript = ""
    lang = None
    try:

        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
    if request.method == "POST":  # if we posted the form

        
        
        print("FORM DATA RECEIVED")
        # here are 2 forms to make sure this file exist :
        if "file" not in request.files:  # no file exist/ uploaded
            print(" Debug: Line 1")
            return redirect(request.url)  # redirect the user to the home page

        file = request.files['file']  # if file exist it will give me that file
        if file.filename == "":  # if file is blank/empty, return to the main page
            print(" Debug: Line 2")
            return redirect(request.url)

        if file:
            print(" Debug: Line 3")
            recognizer = sr.Recognizer()  # initilaize instance of the speech recognition class
            audioFile = sr.AudioFile(file)  # pass in the file
            with audioFile as source:  # reading the file
                data = recognizer.record(source)  # through the recognizer
            try:
                if lang=='Japan':
                    transcript = recognizer.recognize_google(data, language='ja-JP')  # using Google API will return the text
                else:
                    transcript = recognizer.recognize_google(data, language='en-IN') 
            except:
                transcript = 'Please check the speech file language mode'
                
            df6= audio_txt_nlp(transcript,lang,file.filename) 
            
            jsonfiles = json.loads(df6.to_json(orient='records'))

            if lang=='Japan':
                #ginza is a algorithm ,be added lately, so there is a seperate index page to show it,below without ginza
                
                return flask.render_template('j_pdf_files.html', uuid=None,files=file.filename,jsonfiles=jsonfiles )
                #ginza plus processing, 
                os._exit(1)
                    
            else:
                return flask.render_template('pdf_files.html' , uuid=None,files=file.filename,jsonfiles=jsonfiles )
                os._exit(1)


    return render_template('up_audio_idx.html', transcript=transcript,lang=lang)


#img to text , convert img to text
@app.route('/img_to_txt', methods=['GET', 'POST'])

def img_to_txt():
    #fetch data
    #connect to db, and this mode can run with or without database 
    #get the language mode

    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    lang = None
    try:
        
        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
    start = time.time()
    #direct to the upload front page
    if request.method =='GET':
        return render_template("img_txt_index.html",lang=lang)
    
    #post method
    else:
        lang1 = request.form['lg']
        # Create a unique "session ID" for this particular batch of uploads.
        upload_key = str(uuid4())
        ###   the beginning of upload form processing
        """Handle the upload of a file."""
        form = request.form
 
        # Is the upload using Ajax, or a direct POST by the form?
        is_ajax = False
        if form.get("__ajax", None) == "true":
            is_ajax = True
    
        # Target folder for these uploads.
        target = "static/uploads/{}".format(upload_key)
        try:
            os.mkdir(target)
        except:
            if is_ajax:
                return ajax_response(False, "Couldn't create upload directory: {}".format(target))
            else:
                return "Couldn't create upload directory: {}".format(target)
    
        print("=== Form Data ===")
        for key, value in list(form.items()):
            print(key, "=>", value)
            
        print(str(request.files.getlist("file")))
        try:
            for upload in request.files.getlist("file"):
                filename = upload.filename.rsplit("/")[0]
                destination = "/".join([target, filename])
                print("Accept incoming file:", filename)
                print("Save it to:", destination)
                upload.save(destination)
        except:
            return "not supporting file"
        if is_ajax:
            return ajax_response(True, upload_key)
        else:
           
            return redirect(url_for("upload_img_complete", uuid=upload_key,lang1=lang1))
            os._exit(1)


#############the upload file part##############
@app.route("/files/<uuid>/<lang1>")
def upload_img_complete(uuid,lang1):
    """The location we send them to at the end of the upload."""

    # Get their files.
    
    root = "static/uploads/{}".format(uuid)
    print("myroot:"+str(root))
    if not os.path.isdir(root):
        return "Error: UUID not found!"

    files = []
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    lang = None
    try:
        for file in glob.glob("{}/*.*".format(root)):
            fname = file.split(os.sep)[-1]
            files.append(fname)
        

        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
        

    print("Please append file type detect method here")
    #list contains dict
    lst6 = img_text_nlp(root,files,lang1) 
    jsonfiles =  lst6
    if jsonfiles is None:
        return "Error: empty content !"


#     if lang=='Japan':
#         #ginza is a algorithm ,be added lately, so there is a seperate index page to show it,below without ginza
#         return flask.render_template('j_pdf_files.html', uuid=uuid,files=files,jsonfiles=jsonfiles )
#         #ginza plus processing, 
#     else:
    return flask.render_template('pdf_files.html' , uuid=uuid,files=files,jsonfiles=jsonfiles )

   
############end of NLP Pross part #####

#processing pdf files and output NLP array
def pdf_text_nlp(root,files,lang,file_type):
    i = 0
  
    
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    lang = None
    try:

        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
    start = time.time()
    rootfl=''
    d1=[]
    for file in files:
        #if pdf then 
        rootfl = root+"/{}".format(file)
        #pdf type
        ext1 = "*.pdf"
        ext2 = "*.txt"
        ext3 = "*.xls"
        ext4 = "*.xlsx"
        ext5 = "*.jpg"
        ext6 = "*.png"
        
        if fnmatch(file, ext1):
            try:
                file_type='pdf'
                rawtext = pdftotext.pdftotext(rootfl,str(file)+".txt")
            except:
                rawtext='convert failed'
        #text type
        if fnmatch(file, ext2):
            try:
                file_type='txt'
                with open(file, "r") as myfile:
                    rawtext = myfile.read().replace("\n", " ")
            except:
                rawtext='convert failed'        
        #excel file
        if fnmatch(file, ext3) or fnmatch(file,ext4):
            try:
                file_type='excel'
##method1 
#                 wb = xlrd.open_workbook(rootfl)
#                 wb.sheet_names()
#                 sh = wb.sheet_by_index(0)
#                 i = 0
#                 my_file = open(str(file)+".txt", "w")
#                 
#                 while sh.cell(i,0).value != 0:
#                     Load = sh.cell(i,0).value
#                     step_d = sh.row_values(i, 1, 2)
#                     result_d = sh.row_values(i, 2, 3)
#                     DB1 = Load+" "+(" ".join(step_d))
#                     DB2 = " ".join(result_d)
#                     my_file.write(DB1 + ' | ' + DB2 + "\n")
#                     i += 1
#                 my_file.close()  
#                 
                
                #method 2
                #df=pd.read_excel(file,header=0,dtype=object)
                xls = pd.ExcelFile(rootfl)
                a=xls.sheet_names
                sheet_to_df_map = {}
                for sheet_name in a:
                    sheet_to_df_map[sheet_name] = xls.parse(sheet_name,dtype=object)
                    
                for txtfile, dataframetxt in sheet_to_df_map.items(): 
                    print(txtfile)
                    filetext=str(file)+".txt"
                    dataframetxt.to_csv(filetext,sep='\t',index=False)
                
                
                
                #return text
                with open(str(file)+".txt", "r") as myfile:
                    rawtext = myfile.read().replace("\n", " ")
            except Exception as e:
                print(str(e))
                rawtext='convert failed'    
    
        
  
            

        final_reading_time = readingtime(rawtext)
        #locate to the algorithm tab, show the special tab
    
        tact='1'  #initializing
  
        ginza_plus='0'  #initializing
       
        final_reading_time = readingtime(rawtext)
        
        try:
            final_summary_spacy = text_summarizer(rawtext)
        except:
            final_summary_spacy = ''
        summary_reading_time = readingtime(final_summary_spacy)
        
        # Gensim Summarizer
        try:
            final_summary_gensim = summarize(rawtext)
        except:
            final_summary_gensim = ''
        summary_reading_time_gensim = readingtime(final_summary_gensim)
        
        try:
            # NLTK
            final_summary_nltk = nltk_summarizer(rawtext,lang)
        except:
            final_summary_nltk= ''
        summary_reading_time_nltk = readingtime(final_summary_nltk)
        
        try:
            # Sumy
            final_summary_sumy = sumy_summary(rawtext,lang)
        except:   
            final_summary_sumy = ''
        summary_reading_time_sumy = readingtime(final_summary_sumy)
    
        #Sentiment score return
        sent = analyzeText(rawtext,lang)
        bert_scr=None
        bert_sum=None #bert_sent(rawtext)
        print('Please re designing bert method,bert_sent(rawtext)')
        end = time.time()
        final_time = end - start
 
        print("pdf text nlp processing,"+str(i))
       
        d={}
        
        d['file']=str(file)
        d['rawtext'] =rawtext
        d['summary_spacy']=final_summary_spacy
        d['summary_gensim']=final_summary_gensim
        d['summary_nltk']=final_summary_nltk
        d['summary_sumy']=final_summary_sumy
        d['sent']=sent
        d['bert_scr']=bert_scr
        d['bert_sum']=bert_sum

        #d=pd.DataFrame(d)
        #join

        if i==0:
            d1=d
        else:
            d1=d1.append(d1)

        #https://stackoverflow.com/questions/52538795/convert-list-to-dataframe-and-split-nested-dictionary-inside-dataframe-column
        i=i+1
#         pd.set_option('display.max_rows',None)
#         print(df)
    #finished
    return d1


#processing pdf files and output NLP array
def docrtfodt_text_nlp(root,files,lang):
    i = 0
    
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')

    start = time.time()
    rootfl=''
    d1=[]
    for file in files:
        try:
            rawtext =  get_alldocs_to_text(file, root)
            #rawtext = pdftotext.pdftotext(rootfl,str(file)+".txt")
        except:
            rawtext='convert failed'



        final_reading_time = readingtime(rawtext)
        #locate to the algorithm tab, show the special tab
    
        tact='1'  #initializing
  
        ginza_plus='0'  #initializing
       
        final_reading_time = readingtime(rawtext)
        
        try:
            final_summary_spacy = text_summarizer(rawtext)
        except:
            final_summary_spacy = ''
        summary_reading_time = readingtime(final_summary_spacy)
        
        # Gensim Summarizer
        try:
            final_summary_gensim = summarize(rawtext)
        except:
            final_summary_gensim = ''
        summary_reading_time_gensim = readingtime(final_summary_gensim)
        
        try:
            # NLTK
            final_summary_nltk = nltk_summarizer(rawtext,lang)
        except:
            final_summary_nltk= ''
        summary_reading_time_nltk = readingtime(final_summary_nltk)
        
        try:
            # Sumy
            final_summary_sumy = sumy_summary(rawtext,lang)
        except:   
            final_summary_sumy = ''
        summary_reading_time_sumy = readingtime(final_summary_sumy)
    
        #Sentiment score return
        sent = analyzeText(rawtext,lang)
        bert_scr=None
        bert_sum=None #bert_sent(rawtext)
        print('Please re designing bert method,bert_sent(rawtext)')
        end = time.time()
        final_time = end - start
 
        print("pdf text nlp processing,"+str(i))
       
        d={}
        
        d['file']=str(file)
        d['rawtext'] =rawtext
        d['summary_spacy']=final_summary_spacy
        d['summary_gensim']=final_summary_gensim
        d['summary_nltk']=final_summary_nltk
        d['summary_sumy']=final_summary_sumy
        d['sent']=sent
        d['bert_scr']=bert_scr
        d['bert_sum']=bert_sum

        #d=pd.DataFrame(d)
        #join

        if i==0:
            d1=d
        else:
            d1=d1.append(d1)

        #https://stackoverflow.com/questions/52538795/convert-list-to-dataframe-and-split-nested-dictionary-inside-dataframe-column
        i=i+1
#         pd.set_option('display.max_rows',None)
#         print(df)
    #finished
    return d1


#processing img files and output NLP array
def img_text_nlp(root,files,lang1):
    i = 0
    lang = None
    try:
        
        lang=session['lang']
        #user name getout
        email1= session['email'] 
    except:
        lang='English'
    start = time.time()
    rootfl=''
    d1=[] #list
    for file in files:
        #if pdf then 
        rootfl = root+"/{}".format(file)
       
  
        ext5 = "*.jpg"
        ext6 = "*.png"
        ext7 = "*.bmp"
        ext8 = "*.gif"
        #text type
        if fnmatch(file, ext5) or fnmatch(file,ext6) or fnmatch(file,ext7) or fnmatch(file,ext8):
            try:

                rawtext = img_save_txt(rootfl,lang1)
                #print(rawtext)
                
            except:
                rawtext='convert failed'       
        else:
            rawtext='not supporting img type'
              

        #######public processing text part###    
        #####return analyze_public(rawtext,lang,lang1,start,1)
        
        start=time.time()
    
        try:
            final_summary_spacy = text_summarizer(rawtext)
        except:
            final_summary_spacy = '002,Maybe you input some illegal text for this NLP library,please input at least one sentence.'
  
        
        # Gensim Summarizer
        try:
            final_summary_gensim = summarize(rawtext)
        except:
            final_summary_gensim = '003,Maybe you input some illegal text for this NLP library ,please input at least one sentence.'
    
        
        try:
            # NLTK
            final_summary_nltk = nltk_summarizer(rawtext,lang1)
        except Exception as e:
            print(str(e))
            final_summary_nltk= '004,Maybe you input some illegal textfor this NLP library,please input at least one sentence.'
        
        
        try:
            # Sumy ,https://qiita.com/hideki/items/5e9892094ae786d2ad6c
            final_summary_sumy = sumy_summary(rawtext,lang1)
        except Exception as e:
            print('sumy sum:'+str(e)) 
            final_summary_sumy = '005,Maybe you input some illegal text for this NLP library,please input at least one sentence.'

        #Sentiment score return
        sent = analyzeText(rawtext,lang1)
        
        #########end of public text processing##############


        bert_scr=None
        bert_sum=None #bert_sent(rawtext)
        print('Please re designing bert method,bert_sent(rawtext)')

 
        print("img nlp processing,"+str(i))
       
        d={} #dict
        
        d['file']=str(file)
        d['rawtext'] =rawtext
        d['summary_spacy']=final_summary_spacy
        d['summary_gensim']=final_summary_gensim
        d['summary_nltk']=final_summary_nltk
        d['summary_sumy']=final_summary_sumy
        d['sent']=sent
        d['bert_scr']=bert_scr
        d['bert_sum']=bert_sum
        
       
        #join
 
        if i==0:
            d1=d
        else:
            d1=d1.append(d)
        print('convert :'+str(i))
        #https://stackoverflow.com/questions/52538795/convert-list-to-dataframe-and-split-nested-dictionary-inside-dataframe-column
        i=i+1
#         pd.set_option('display.max_rows',None)
#         print(df)
    #finished
    return d1

#######


#processing img files and output NLP array
def audio_txt_nlp(rawtext,lang1,filen):
    i = 0
    #######public processing text part###    
    #####return analyze_public(rawtext,lang,lang1,start,1)
    
    start=time.time()

    try:
        final_summary_spacy = text_summarizer(rawtext)
    except:
        final_summary_spacy = '002,Maybe you input some illegal text for this NLP library,please input at least one sentence.'

    
    # Gensim Summarizer
    try:
        final_summary_gensim = summarize(rawtext)
    except:
        final_summary_gensim = '003,Maybe you input some illegal text for this NLP library ,please input at least one sentence.'

    
    try:
        # NLTK
        final_summary_nltk = nltk_summarizer(rawtext,lang1)
    except Exception as e:
        print(str(e))
        final_summary_nltk= '004,Maybe you input some illegal textfor this NLP library,please input at least one sentence.'
    
    
    try:
        # Sumy ,https://qiita.com/hideki/items/5e9892094ae786d2ad6c
        final_summary_sumy = sumy_summary(rawtext,lang1)
    except Exception as e:
        print('sumy sum:'+str(e)) 
        final_summary_sumy = '005,Maybe you input some illegal text for this NLP library,please input at least one sentence.'

    #Sentiment score return
    sent = analyzeText(rawtext,lang1)
    
    #########end of public text processing##############


    bert_scr=None
    bert_sum=None #bert_sent(rawtext)
    print('Please re designing bert method,bert_sent(rawtext)')


    print("img nlp processing,"+str(i))
   
    d={}
    
    d['file']=str(filen)
    d['rawtext'] =rawtext
    d['summary_spacy']=final_summary_spacy
    d['summary_gensim']=final_summary_gensim
    d['summary_nltk']=final_summary_nltk
    d['summary_sumy']=final_summary_sumy
    d['sent']=sent
    d['bert_scr']=bert_scr
    d['bert_sum']=bert_sum

    d1=pd.DataFrame(d)
    #join

    if i==0:
        df=d1
    else:
        df=df.join(d1)

    #https://stackoverflow.com/questions/52538795/convert-list-to-dataframe-and-split-nested-dictionary-inside-dataframe-column
    print('times:'+str(i))
    i=i+1
    pd.set_option('display.max_rows',None)
    print(df)
    #finished
    return df


    

def ajax_response(status, msg):
    status_code = "ok" if status else "error"
    return json.dumps(dict(
        status=status_code,
        msg=msg,
    ))

######end of upload file part #################

#jp stock list 
@app.route('/get_jp_news', methods=['GET', 'POST'])
def get_jp_news():
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    lang = None
    try:
        
        lang=session['lang']
        email1= session['email'] 
    except:
        lang='English'
    if lang=='Japan':
        lang1='ja'
    elif lang=='China':
        lang1='cn'
    else:
        lang1='en'
        
    if request.method =='GET':
        usr_id,super_id,_=get_user(email1)
        if super_id>1:
        #keywords: list = None, language='ja', limit=50, retrieve_content_behind_links=False, num_threads=1
        #in this page, will start the download scraping function
#         if lang=='Japan':
#             return render_template('j_progress.html')
#             return redirect(url_for("progress", keywords=None,language=lang1,limit=2,retrieve_content_behind_links=False,num_threads=1))
#         #('/progress<keywords><language><limit><retrieve_content_behind_links><num_threads>
#         else:
#             return render_template('progress.html')
        
                #start threading of scraping
            try:
                th2 = threading.Thread(target = main_vpn.run_goog_vpn_scraping_news, args=(None, lang1, News_scrape_max, True, 1,) )
                
                            #(keywords: list = None, language='ja', limit=100, retrieve_content_behind_links=True, num_threads=1)
  
  
                threads.append(th2)
                th2.start()
                #record the spec words
                
                save_srch('All General News',lang1)
                print ("Scraping Thread(s) started..")
                #now can redirect to new page.
                return redirect(url_for("progress", keywords=''))
            
            except Exception as e:
                print ("Error: unable to start thread(s),"+str(e))
                logger.info('Error: user %s unable to start scraping thread.' % (email1)) 
                os._exit(1)
        
            #main_vpn.run_goog_vpn_scraping_news(None, lang1, 2, False, 1)
            logger.info('user %s  download general news into DB.' % (email1))
            print('download finished')
            flash('download finished')
        else:
            logger.info('user %s  download general news into DB.failed ,no permission' % (email1))
            
            flash('You are not super user level 2, no general news DB storage permission')
            return render_template('account_login.html')
        return redirect('/jp_list')

    else:
        return redirect('/jp_list')


#get special news by the key words ,and saving the key words.
@app.route('/spec_news_words', methods=['GET', 'POST'])
def spec_news_words():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
        else:
            #user name getout
            email1= session['email'] 
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    try:
        pgmode= session['pgmode']
    except:
        pgmode= 1
        session['pgmode']=1

    usr_id,super_id,_=get_user(email1)
    lang = None
    try:

        lang=session['lang']
    except:
        lang='English'
        
    if flask.request.method == 'POST':
        try:
            pre_str = request.form['tags_1']
        except:
            if lang=='Japan': 
                return flask.render_template('j_key_words.html',pre_str='' ) 
            else:
                return flask.render_template('key_words.html',pre_str='' ) 
        if pre_str is None:
            if lang=='Japan': 
                return flask.render_template('j_key_words.html',pre_str='' ) 
            else:
                return flask.render_template('key_words.html',pre_str='' ) 

        pre_str = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",pre_str)
        
        if len(pre_str)<2:
            if lang=='Japan': 
                return flask.render_template('j_key_words.html',pre_str='' ) 
            else:
                return flask.render_template('key_words.html',pre_str='' ) 
        #main data fetch and single Category view request
        #print(pre_str)
        
        #only super user can del record
        if  int(super_id)<2:
             flash('You are not super user level 2, no download news permission')
             return render_template('account_login.html')
        else:
            #need saving this news setting
            pass
            
        #get user prefer again
        #run the  scrapihng and saving to the DB
        #JP
        if lang=='Japan':
            lang1='ja'
        elif lang=='China':
            lang1='cn'
        else:
            lang1='en'        

   
        key_words=pre_str.split(",") #https://github.com/philipperemy/google-news-scraper

#         run_goog_vpn_scraping_news(keywords: list = None, language='ja', limit=50, retrieve_content_behind_links=True, num_threads=1):
#         if lang=='Japan':
#             return render_template('j_progress.html')
#         else:
#             return render_template('progress.html')


        ################################################

        #main_vpn.run_goog_vpn_scraping_news(key_words, lang1, 2, True, 1)
        
        
        #start threading of scraping
        try:
            th3 = threading.Thread(target= main_vpn.run_goog_vpn_scraping_news, args=(key_words, lang1, News_scrape_max, True, 1,) )
                    
            threads.append(th3)
            th3.start()
      
            if save_srch(pre_str,lang1):
                logger.info('user %s  Save tags [%s] into DB,false.' % (email1, pre_str))
            print ("Scraping Thread(s) started..")
            #now can redirect to new page.
            return redirect(url_for("progress", keywords=str(pre_str) ))
            
        except Exception as e:
            print ("Error: unable to start thread(s)," +str(e))
            logger.info('Error: user %s unable to start scraping thread-[%s].' % (email1, pre_str)) 
            os._exit(1)
     
        #get the data from DB,already be filter
        pre_str1  = pre_str

        if len(pre_str1)>2:
    
            # 使用正则表达式去匹配标点符号
            pre_str1  = pre_str1.strip().replace(',', '|')
            pre_str1 = ' and Article RLIKE ' +'\''+pre_str1+'\''
        #pre_str1 = "|".join([x.repace(',','').strip() for x in pre_str1])
        
        else:
            #index page, 100 is enough
            pre_str1=' limit 0,100 '
    
        engine =get_conn()
        #del_flag  this record had been filter by user
        
        #JP
        if lang=='Japan':
            com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_JP a right join scr_jp b on a.News_English_id =b.News_English_id where b.del_flag !=True  '+ pre_str1
        else:
            #English news
            com_sql1 ='select b.News_English_id,Category,Source,Link,Author,Date,Title,Article,b.edit_flag,b.del_flag,b.Article_spacy_sum,b.Article_nltk_sum,b.Article_gensim_sum,b.Article_sumy_sum ,b.Article_positive, b.Article_negative, b.Article_neutral, b.Article_compound, b.Title_positive, b.Title_negative, b.Title_neutral, b.Title_compound from News_English a right join scr_table b on a.News_English_id =b.News_English_id where b.del_flag !=True  '+ pre_str1
    
        #print(com_sql1)
        data_df1 = pd.read_sql_query(com_sql1, engine)



    #method of get    
    else:
        print(' user,get input panel')  
        if lang=='Japan': 
            return flask.render_template('j_key_words.html',pre_str='' ) 
        else:
            return flask.render_template('key_words.html',pre_str='' ) 
        ####data_df1= get_usr_news(email1,lang)
        
    algm='spacy'
    ####_,_,pre_str=get_user(email1)
    
    try:
        data_df1 = data_df1[~( data_df1['Article'].isnull() )]
        #data_df2 = data_df2[~( data_df2['Article'].isnull() )]
           
        #clean the data of article ,clean the extra return
        data_df1=data_df1.replace('\n\n', '\n')
        #data_df2=data_df2.replace('\n\n', '\n')
    except:
        pass
    #jtag = 0,not show the prefer
    return show_nlp_index(data_df1,algm,lang,pre_str,-99,pgmode)

#https://stackoverflow.com/questions/28568687/download-multiple-csvs-using-flask
#download files multiple files ,zip them ,and download
@app.route('/download_all')
def download_all():
    zipf = zipfile.ZipFile('Name.zip','w', zipfile.ZIP_DEFLATED)
    for root,dirs, files in os.walk('output/'):
        for file in files:
            zipf.write('output/'+file)
    zipf.close()
    return send_file('Name.zip',
            mimetype = 'zip',
            attachment_filename= 'Name.zip',
            as_attachment = True)

#load stock list ,from excel files
def load_xls(lang):
    curPath = os.path.abspath(os.path.dirname(__file__))
    rootPath = os.path.split(curPath)[0]

    if lang=='English':
        excel_file = '/usa_nasdaq_companylist.csv'
    else:
        excel_file = '/stock_jp.xls'   
                    #导入excel数据
    filename= curPath+excel_file
    try:
        if lang=='English':
            with open( filename, 'r')  as f: df_lc  = pd.read_csv(f,encoding='utf-8')
            #need return part of the content of df
            df_lc.columns = df_lc.columns.str.lower()
            
            data = df_lc[['symbol','name']]
            #save one copy
            data.index.rename('symbol',inplace=True)
            data.set_index('symbol',inplace=True)
            data.to_csv('a copy of '+lang+'.csv',encoding='utf-8')
#             data =data.reset_index(level=None, drop=False, inplace=False)
#             data.to_csv('onecopy1 of '+lang+'.csv',encoding='utf-8')
            
        else:
            #data = pd.read_excel(filename, index_col=['ticker','tname'])      
            data=pd.read_excel(filename,usecols=['ticker','tname'],sheet_name='Sheet1') 
            data.set_index('ticker',inplace=True)
           
            data.to_csv('a copy of '+lang+'.csv',encoding='utf-8') 
            #这个的index_col就是index，可以选择任意字段作为索引index，读入数据
            #print(data.loc['李四'])
            #data.columns=['ticker','tname']
        return data
    except Exception as e:
        print("Fail to open file. File may not exist."+str(e))
        return None
    
    
#load stock list
def load_stock(lang):
    stock_list = []
    
    curPath = os.path.abspath(os.path.dirname(__file__))
    rootPath = os.path.split(curPath)[0]

    if lang=='English':
        filename = './stock_us.txt'
    elif lang== 'Japan':
        filename = './stock_jp.txt'
    else:
        print("Fail to open market symbol .")
        sys.exit(1)  
    #filename = os.path.join(rootPath,filename)
    filename= rootPath+filename
    if os.path.exists( filename ):
        file = open(filename, 'r')
        for line in file:
            stock_list.append(line.replace("\r", "").replace("\n", ""))
    else:
        print("Fail to open file. File may not exist.")
        sys.exit(1)
    jsonfiles = json.loads(stock_list.to_json(orient='records'))
    return jsonfiles

###### update the basic data set begin #########
       

###### end of update the basic data set ############

#@@@@csv news prefer setting file operation###
#uuid for csv file
def generate_id():
    new_id =uuid4()
    return str(new_id)

#load stock list ,from excel files
def load_setting(lang):
    if lang=='English':
        excel_file = en_user_file
    else:
        excel_file = jp_user_file
                    #导入excel数据
    filename= os.getcwd()+excel_file
    try:
        with open( filename, 'r')  as f: df_lc  = pd.read_csv(f,encoding='utf-8')
        #need return part of the content of df
        df_lc.columns = ['id','name']
        data = df_lc[['name']]

        return data
    except Exception as e:
        print("Fail to open file. File may not exist."+str(e))
        return None


#scraping data
def scraping():
    #USA company
    lang='English'
    df11= load_setting(lang)
    #load stock list ,from excel files
    if lang=='Japan':
        lang1='ja'
    elif lang=='China':
        lang1='cn'
    else:
        lang1='en'
    key_words=df11['name'].tolist()
    #run_goog_vpn_scraping_news(keywords: list = None, language='ja', limit=50, retrieve_content_behind_links=True, num_threads=1):
    ###main_vpn.run_goog_vpn_scraping_news(key_words, lang1, 2, True, 1)
    #start threading of scraping
    try:
       
        th1 = threading.Thread(target = main_vpn.run_goog_vpn_scraping_news, args=(key_words, lang1, News_scrape_max, True, 1,) )
        threads.append(th1)
        th1.start()
 
        print ("Scraping Thread(s) started...")
 
    except Exception as e:
        print ("Error: unable to start thread(s) for english,"+str(e))
        #return redirect('/index_main')
        

    #jp company
    lang='Japan'
    df11= load_xls(lang)
    #load stock list ,from excel files
    if lang=='Japan':
        lang1='ja'
    elif lang=='China':
        lang1='cn'
    else:
        lang1='en'
    key_words=df11['name'].tolist()
    #run_goog_vpn_scraping_news(keywords: list = None, language='ja', limit=50, retrieve_content_behind_links=True, num_threads=1):
    
    #start threading of scraping
    try:

        th1 = threading.Thread(target = main_vpn.run_goog_vpn_scraping_news, args=(key_words, lang1, News_scrape_max, True, 1,) )
        threads.append(th1)
        th1.start()
        #record the spec words
         
        if save_srch(wrd,lang1):
            logger.info('user %s  Save tags [%s] into DB,false.' % (email1, pre_str))
        print ("Scraping Thread(s) started..")
        #now can redirect to new page.
        return redirect(url_for("progress", keywords=wrd))
    except Exception as e:
        print ("Error: unable to start thread(s),"+str(e))
        logger.info('Error: user %s unable to start scraping thread-[%s].' % (email1, wrd)) 
        return redirect('/index_main')
        #os._exit(1)

#scraping data of spec, now for the stock news.
def scraping_spec(df11,lang):

    try:
        email1= session['email'] 
    except:
        email1='-'

    #rename, avoid error
    df11.columns = ['name']
    #df11= load_xls(lang)
    #load stock list ,from excel files
    if lang=='Japan':
        lang1='ja'
    elif lang=='China':
        lang1='cn'
    else:
        lang1='en'
    key_words=df11['name'].tolist()
    #run_goog_vpn_scraping_news(keywords: list = None, language='ja', limit=50, retrieve_content_behind_links=True, num_threads=1):
    
    #start threading of scraping
    try:

        th1 = threading.Thread(target = main_vpn.run_goog_vpn_scraping_news, args=(key_words, lang1, News_scrape_max, True, 1,) )
        threads.append(th1)
        th1.start()
        #record the spec words
         
        if save_srch(wrd,lang1):
            logger.info('user %s  Save tags [%s] into DB,false.' % (email1, pre_str))
        print ("Scraping Thread(s) started..")
        #now can redirect to new page.
        return redirect( url_for("progress", keywords=wrd ) )
    except Exception as e:
        print ("Error: unable to start thread(s),"+str(e))
        logger.info('Error: user %s unable to start scraping thread-[%s].' % (email1, '')) 
        return redirect('/index_main')
        #os._exit(1)
        

@app.route('/enews_index')
def enews_index():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')

    lang = None
    try:
        lang=session['lang']
    except:
        lang='English'
    if lang=='English':
        excel_file = en_user_file
    else:
        excel_file = jp_user_file
                    #导入excel数据
  
    filen= os.getcwd()+excel_file
    stories = read_csv(filen)
    return render_template('news_index.html', stories=stories,lang=lang)


@app.route('/news_story')
def news_story():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')

    lang = None
    try:
        lang=session['lang']
    except:
        lang='English'
    if lang=='English':
        excel_file = en_user_file
    else:
        excel_file = jp_user_file
                    #导入excel数据

    filen= os.getcwd()+excel_file
    stories = read_csv(filen)
    if len(stories)>200:
        flash('Over 100 items,please remove some items.')
        return render_template('news_index.html',stories=stories,lang=lang)
    return render_template('news_story.html', action="/save_story",lang=lang)

@app.route('/save_story', methods=['POST'])
def save_story():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')

    lang = None
    try:
        lang=session['lang']
    except:
        lang='English'
    if lang=='English':
        excel_file = en_user_file
    else:
        excel_file = jp_user_file
                    #导入excel数据

    filen= os.getcwd()+excel_file
    
    list_label = label_news_like
    story = []
    story.insert(0, generate_id())
    for input_name in list_label:
        pre_str1 = request.form[input_name]
        # 使用正则表达式去匹配标点符号
        pre_str1 = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",pre_str1)

        # 所有标点--result = re.sub("[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？、~@#￥%……&*（）]+", "",result)
        pre_str1  = pre_str1.strip().replace(',', ' ')
        story.append(pre_str1)
    append_csv(story,filen)
    stories = read_csv(filen)
    return render_template('news_index.html',stories=stories,lang=lang)

@app.route('/story/<post_id>')
def route_edit_story(post_id):
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')

    lang = None
    try:
        lang=session['lang']
    except:
        lang='English'
    if lang=='English':
        excel_file = en_user_file
    else:
        excel_file = jp_user_file
                    #导入excel数据
   
    filen= os.getcwd()+excel_file
    
    stories = read_csv(filen)
    for row in stories:
        if len(row):
            if row[0] == post_id:
                return render_template("news_story.html", row=row,lang=lang)
        else:
            pass
    return render_template('news_index.html',stories=stories,lang=lang)

@app.route("/save_edited_story/<post_id>", methods=["POST"])
def route_save_edited_story(post_id):
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')

    lang = None
    try:
        lang=session['lang']
    except:
        lang='English'
    if lang=='English':
        excel_file = en_user_file
    else:
        excel_file = jp_user_file
                    #导入excel数据
 
    filen= os.getcwd()+excel_file
    
    
    list_label = label_news_like
    edited_story = []
    edited_story.insert(0, post_id)
    for input_name in list_label:
        pre_str1 = request.form[input_name]
        # 使用正则表达式去匹配标点符号
        pre_str1 = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",pre_str1)

        # 所有标点--result = re.sub("[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？、~@#￥%……&*（）]+", "",result)
        pre_str1  = pre_str1.strip().replace(',', ' ')
        
        edited_story.append(pre_str1)
    stories = read_csv(filen)
    edit_csv(stories, edited_story,filen)
    stories = read_csv(filen)
    return render_template('news_index.html',stories=stories,lang=lang)


@app.route('/delete/<post_id>')
def route_delete_story(post_id):
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')

    lang = None
    try:
        lang=session['lang']
    except:
        lang='English'
    if lang=='English':
        excel_file = en_user_file
    else:
        excel_file = jp_user_file
                    #导入excel数据
 
    filen= os.getcwd()+excel_file
    
    stories = read_csv(filen)
    index = 0
    try:
        for row in stories:
            if row[0] == post_id:
                popindex = index
                stories.pop(popindex)
                write_csv(stories,filen)
                break
            else:
                pass
            index += 1
            print('row index:'+str(index))
    except Exception as e:
        print(str(e))
       
    stories = read_csv(filen)
    return render_template('news_index.html',stories=stories,lang=lang)


@app.route('/man_begin')
def man_begin():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
        email1=session['email']
        usr_id,super_id,_=get_user(email1)
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    if super_id<2:
        flash("Only user level 3 can updating all the companys pictures,plz logout and login with level 2")
        return redirect('/index_main')
    
    scraping()


@app.route('/begin_stk_scrape')
def begin_stk_scrape():
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    #get the language mode
    try:
        if not session['logged_in']:
            return render_template('account_login.html')
        email1=session['email']
        usr_id,super_id,_=get_user(email1)
    except:
        session['logged_in'] = False
        session['username'] = None
        session['email'] = None
        return render_template('account_login.html')
    if super_id<2:
        flash("Only user level 3 can updating all the companys pictures,plz logout and login with level 2")
        return redirect('/index_main')

    
    df11=load_xls('Japan')
    scraping_spec(df11,'Japan')
#     df11=load_xls('English')
#     scraping_spec(df11,'English')
    return redirect('/index_main')

##end of csv news file setting end ##



############################# End of ESG ###########################


################################################
################################################
####################### money impact begin #####

from flask import jsonify
import json
from mp_config import chk_train_data

#0 is jp stock
base_dict={
    'base_tbl':['moneyImpact.mst_corporate_jp'],\
    'base_price':['moneyImpact.mkt_eqty_price'],\
    'base_currency':['JPY']
    }

#news showing solution configuration,策略1
base_new_default ={
    'default0':[''],\
    'default1':['limit 10'],\
    'default2':['limit 10'],\
    'default3':['limit 50'],\
    'default4':['limit 120'],\
    'default5':['limit 200']
    }

#this is a base para for keyword news searching,
open_default=True
deflt_length=1

#get portfolio list
def get_pf_list(uid,uflag):
    #connect with DB
    if not uid:
        return None
    
    engine =get_conn()
    com_sql1 =''
    df1=None
    if  uflag:
        #Right
        com_sql1='select a.pid ,a.uid,a.pf_name,a.pf_news_subscribe,a.priority_level,a.active,a.created_date,a.updated_date,b.security_code,b.security_type,b.holding_amount,b.price,b.currency_code,b.acquisition_date,b.financial_institution_code,b.int_created_date,b.int_updated_date from  moneyImpact.mst_portfolios  as  a  right join moneyImpact.trs_portfolio_details as b on a.pid=b.pid and a.active<>False and uid='+str(uid)
    else:
         com_sql1='select * from  moneyImpact.mst_portfolios where active<>false and uid='+str(uid)
    print(com_sql1)
    df1 = pd.read_sql_query(com_sql1, engine)
    df1 = df1.drop_duplicates()
    #print(df1.columns)
 
    return df1

#get portfolio list
def get_one_pf(uid,pid):
    #connect with DB
    if not uid or not pid:
        return None
    
    engine =get_conn()
    com_sql1 =''
    df1=None

    com_sql1='select * from  moneyImpact.mst_portfolios where uid='+str(uid) +' and pid='+str(pid)
    #print(com_sql1)
    df1 = pd.read_sql_query(com_sql1, engine)
    df1 = df1.drop_duplicates()
    #print(df1.columns)
 
    return df1
    
##get one invest from table
#abstract the public part, reuse it    .search key word from db
#def srch_one_int(wrd,tbl_name):
   



##################
### store the user keyowrd of one investment
#def new_keyword(uid,pid,keyword,create_date,update_date):


#sub create portfolio function
def a_new_pf(uid, pf_name,pf_news_subscribe,priority_level,active,created_date,updated_date):
    #connect with DB
    print(str( updated_date ))
    print(str( created_date ))
    print(str( active ))
    print(str( priority_level ))
    print(str( pf_news_subscribe ))
    print(str( pf_name ))
    print(str( uid ))    
    engine =get_conn()
    com_sql1 =''
    valuess=''
    df1=None
    if  uid:
        
        valuess='VALUES ({},\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\')'.format(uid, pf_name,pf_news_subscribe,priority_level,active,created_date,updated_date)
        com_sql1 ='insert into moneyImpact.mst_portfolios (uid,pf_name,pf_news_subscribe,priority_level,active,created_date,updated_date) '+valuess
        
        
        
        #com_sql1='INSERT INTO mst_portfolios (uid,pf_name,pf_news_subscribe,priority_level,active,created_date,updated_date) VALUES'+(str(uid), str(pf_name),str(pf_news_subscribe),str(priority_level),str(active),str(created_date),str(updated_date))
    print(com_sql1)
    try:
        with engine.begin() as conn:
            conn.execute(com_sql1)
        return True
    except Exception as e:
        print(str(e)) 
        return False


# pid int(11) PK 
# security_code varchar(12) PK 
# security_type tinyint(4) PK 
# holding_amount int(11) 
# price decimal(10,2) 
# currency_code char(3) 
# acquisition_date datetime 
# financial_institution_code char(4) 
# int_created_date datetime 
# int_updated_date
#A new investment for one portfolio
#sub create portfolio function
def a_new_invest(uid,addway,pid, security_code,company_name,security_type,holding_amount,price,currency_code,acquisition_date,financial_institution_code,int_created_date,int_updated_date ):
    #connect with DB
    company_name=company_name.strip()
    engine =get_conn()

    com_sql1 =''
    com_sql2=''
    com_sql3=''
    valuess1=''
    valuess2=''
    valuess3=''
    df1=None
    if addway:
        
        
        valuess1=' VALUES ({},\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\')'.format(pid, security_code,security_type,holding_amount,price,currency_code,acquisition_date,financial_institution_code,int_created_date,int_updated_date)
        com_sql1 ='insert into moneyImpact.trs_portfolio_details (pid, security_code,security_type,holding_amount,price,currency_code,acquisition_date,financial_institution_code,int_created_date,int_updated_date) '+valuess1
        
        #valuess2=' VALUES ({},\'{}\',\'{}\',{},\'{}\',\'{}\')'.format(pid, uid,security_code,True,int_created_date,int_updated_date)
        valuess3=' VALUES ({},{},\'{}\',{},\'{}\',\'{}\')'.format(pid, uid,company_name,True,int_created_date,int_updated_date)
        #com_sql2='insert into moneyImpact.mst_keyword (pid,uid,keyword,active,create_date,updated_date) '+valuess2
        com_sql3='insert into moneyImpact.mst_keyword (pid,uid,keyword,active,create_date,updated_date) '+valuess3
    else:
        com_sql1 ='DELETE FROM moneyImpact.trs_portfolio_details WHERE pid={} and security_code={} and security_type={} '.format(pid,security_code,security_type)
        #com_sql2 ='DELETE FROM moneyImpact.mst_keyword WHERE pid={} and uid={} and keyword={} '.format(pid,uid,security_code)
        com_sql3 ='DELETE FROM moneyImpact.mst_keyword WHERE pid={} and uid={} and keyword=\'{}\' '.format(pid,uid,company_name)
        #return False
        #com_sql1='INSERT INTO mst_portfolios (uid,pf_name,pf_news_subscribe,priority_level,active,created_date,updated_date) VALUES'+(str(uid), str(pf_name),str(pf_news_subscribe),str(priority_level),str(active),str(created_date),str(updated_date))
    print(com_sql1)
    #print(com_sql2)
    print(com_sql3)
  
#     conn=engine.connect()
#     
# 
#     trans = conn.begin()
#     try:
#    
#         conn.execute(com_sql3)
#         conn.execute(com_sql1)
#         trans.commit()
#      
#     except Exception as e:
#         print(str(e)) 
#         trans.rollback()
#         return False

    conn=engine.connect()
    

    #trans = conn.begin()
    try:
        conn.execute(com_sql3)
    except Exception as e:
        print(str(e)) 
    try:
   
        conn.execute(com_sql1)
    except Exception as e:
        print(str(e))    
    
    conn.close()
    return True
    
######## update one investment
###########################################
def up_new_invest(addway,pid, security_code,security_type,holding_amount,price,currency_code,acquisition_date,financial_institution_code,int_created_date,int_updated_date ):

    #connect with DB
    uid=1
    engine =get_conn()
    com_sql1 =''
    valuess=''
    df1=None
    if   addway:
        
        com_sql1='UPDATE  moneyImpact.trs_portfolio_details SET holding_amount={},price={},currency_code=\'{}\',financial_institution_code=\'{}\',int_updated_date=\'{}\''.format(holding_amount,price,currency_code,financial_institution_code,int_updated_date )
        com_sql1=com_sql1+ ' WHERE pid=\'{}\' and security_code=\'{}\''.format(pid,security_code)
            
            

    else:
        #delete action   
        com_sql1='DELETE FROM moneyImpact.trs_portfolio_details WHERE '
        com_sql1=com_sql1+ '  pid=\'{}\' and security_code=\'{}\' and security_type =\'{}\''.format(pid,security_code,security_type)


        #com_sql1='INSERT INTO mst_portfolios (uid,pf_name,pf_news_subscribe,priority_level,active,created_date,updated_date) VALUES'+(str(uid), str(pf_name),str(pf_news_subscribe),str(priority_level),str(active),str(created_date),str(updated_date))
    print(com_sql1)
    try:
        with engine.begin() as conn:
            conn.execute(com_sql1)
        return True
    except Exception as e:
        print(str(e)) 
        return False

######## update one portfolio
###########################################
def up_new_pf(addway,pid,opf_name, pfname,subflag,pf_memo,updated_date ):

    #connect with DB
    uid=1
    engine =get_conn()
    com_sql1 =''
    subflag1=True
    subs=False
    if subflag:
        subflag1=True
    else:
        subflag1=False
    #udate
    if  addway:
        
        com_sql1='UPDATE  moneyImpact.mst_portfolios SET pf_name=\'{}\',pf_news_subscribe={},pf_memo=\'{}\',updated_date=\'{}\''.format(pfname,subflag1,pymysql.escape_string(pf_memo),updated_date )
        com_sql1=com_sql1+ ' WHERE pid=\'{}\' and pf_name=\'{}\''.format(pid,opf_name)
    #remove
    else:
     
        com_sql1='UPDATE  moneyImpact.mst_portfolios SET active=False, pf_news_subscribe=False,updated_date=\'{}\''.format(updated_date)
        com_sql1=com_sql1+ ' WHERE pid= {} and uid={} '.format(pid,uid)


        #com_sql1='INSERT INTO mst_portfolios (uid,pf_name,pf_news_subscribe,priority_level,active,created_date,updated_date) VALUES'+(str(uid), str(pf_name),str(pf_news_subscribe),str(priority_level),str(active),str(created_date),str(updated_date))
    print(com_sql1)
    try:
        with engine.begin() as conn:
            conn.execute(com_sql1)
        return True
    except Exception as e:
        print(str(e)) 
        return False

  
    
####### remove one record from investment table
##############################   
def mp_rmv_int_run(pid, security_code,security_type ):

    #connect with DB
    uid=1
    engine =get_conn()
    com_sql1 =''
    
   
    if  uid:
        com_sql1='DELETE FROM moneyImpact.trs_portfolio_details WHERE '
        com_sql1=com_sql1+ '  pid=\'{}\' and security_code=\'{}\' and security_type =\'{}\''.format(pid,security_code,security_type)

    else:
        return False
        #com_sql1='INSERT INTO mst_portfolios (uid,pf_name,pf_news_subscribe,priority_level,active,created_date,updated_date) VALUES'+(str(uid), str(pf_name),str(pf_news_subscribe),str(priority_level),str(active),str(created_date),str(updated_date))
    print(com_sql1)
    try:
        with engine.begin() as conn:
            conn.execute(com_sql1)
        return True
    except Exception as e:
        print(str(e)) 
        return False
    


#####################################
#########Update data or insert data into DB with dataframe format
#insert training result into database table
def mp_upd_data(df4,tbl_name):
    try:
        engine =get_conn()
    #             - fail: If table exists, do nothing.
    #             - replace: If table exists, drop it, recreate it, and insert data.
    #             - append: If table exists, insert data. Create if does not exist.
        df4.to_sql(tbl_name, engine, if_exists='append', index= False)
        print("Write to MySQL successfully!")
        return True
    except:
        print("Write to MySQL failed!")
        return False
       


#get portfolio list
def spec_pf_int_list(uid,pid,tbl_name):
    #connect with DB
    if not uid:
        return None
    third_tbl=' left join '+tbl_name+' as c on c.mkt_ticker_code=b.security_code '
    engine =get_conn()
    com_sql1 =''
    df1=None
  
        #Right
    com_sql1='select c.company_name,a.pid ,a.uid,a.pf_name,a.pf_news_subscribe,a.priority_level,a.active,a.created_date,a.updated_date,b.security_code,b.security_type,b.holding_amount,b.price,b.currency_code,b.acquisition_date,b.financial_institution_code,b.int_created_date,b.int_updated_date from ( moneyImpact.mst_portfolios  as  a  right join moneyImpact.trs_portfolio_details as b on a.pid=b.pid and a.active<>False'+third_tbl+' ) where b.pid='+str(pid)+' and a.uid='+str(uid)

    print(com_sql1)
    try:
        df1 = pd.read_sql_query(com_sql1, engine)
        df1 = df1.drop_duplicates()
    except:
        df1=None
    #print(df1.columns)
 
    return df1


#get one news details ,called by news dtl show page
def get_news_dtl(news_id):
    #if not illegal ,return None
    if int(news_id)<0:
        return None

    #default_show=base_new_default.get('default2')
    news_lst=None
    engine=get_conn()
    com_sql1=''
    pre_str1=''

    pre_str1 = '  where a.news_id=\'{}\' '.format(news_id)
    #'select b.news_id,category_id,n_source,n_link,author,n_date,title,article,n_img,b.article_spacy_sum,b.article_nltk_sum,b.article_gensim_sum,b.article_sumy_sum ,b.article_positive, b.article_negative, b.title_positive, b.title_negative from moneyImpact.nw_news a right join moneyImpact.nw_scores b on a.news_id =b.news_id where b.del_flag !=True  '
    com_sql1 ='select b.news_id,category_id,n_source,n_link,author,n_date,title,article,n_img,b.article_spacy_sum,b.article_nltk_sum,b.article_gensim_sum,b.article_sumy_sum ,b.article_positive, b.article_negative, b.title_positive, b.title_negative from moneyImpact.nw_news a right join moneyImpact.nw_scores b on (a.news_id =b.news_id) '
    com_sql1=com_sql1+pre_str1
    print(com_sql1)
    try:
        news_lst = pd.read_sql_query(com_sql1, engine)
    except Exception as e:
        print(str(e)) 
        #return None
    try:
        news_lst = news_lst.drop_duplicates()
    except Exception as e:
        print(str(e)) 
    #return
    return news_lst




#now is the  main index page
@app.route('/', methods=['GET', 'POST'])
def index():
    #replace it now
    return redirect('/news_index')
    



#now is the  main index page
@app.route('/spec_pf_list', methods=['GET', 'POST'])
def spec_pf_list():
    tbl_name=base_dict.get('base_tbl')[0]
    if  flask.request.method == 'GET':
        uid=1
        try:
            pid = request.args.get('pid')
            pf_name = request.args.get('pf_name')
        except:
            print('request args fail')
        return sub_spec_pf_list(uid,pid,pf_name,tbl_name)
            

#return to pf list of one special portfolio and investment
def sub_spec_pf_list(uid,pid,pf_name,tbl_name):
    
    df3,df2,pid,pf_name,df4,df5=get_one_pf_all(uid,pid,pf_name,tbl_name)
    
    df2['created_date'] = df2['created_date'].dt.strftime('%Y-%m-%d')
    df2['updated_date'] = df2['updated_date'].dt.strftime('%Y-%m-%d')
    #iso of the datetime format, 
    lines2 = json.loads(df2.to_json(orient='records',date_format='iso'))
    
    
           
    df3['created_date'] = df3['created_date'].dt.strftime('%Y-%m-%d')
    df3['updated_date'] = df3['updated_date'].dt.strftime('%Y-%m-%d')
    
    #the currency number format
    df3['holding_amount'] = df3['holding_amount'].astype('int')
    df3['holding_amount'] = ['{:,}'.format(i) for i in list(df3['holding_amount'])]
    df3['price'] = df3['price'].astype('float')
    df3['price'] = ['{:,.2f}'.format(i) for i in list(df3['price'])]
    
    
    
    #iso of the datetime format, 
    lines1 = json.loads(df2.to_json(orient='records',date_format='iso'))
    
    json_currency = json.loads(df4.to_json(orient='records'))

    json_asset = json.loads(df5.to_json(orient='records'))
        
    return flask.render_template('moneyimpact/pf_sub_list.html',lines1=lines1,lines2=lines2,pid=pid,pf_name=pf_name,json_currency=json_currency,json_asset=json_asset)  

def get_one_pf_all(uid,pid,pf_name,tbl_name):
    #get the spec pf info
    uid=1
    if not pid or not pf_name:
        return redirect('/pf_list')
    engine =get_conn()
    com_sql1 =''
    df1=None
    df2=None
    df3=None
    df4=None
    df5=None
    item_list_id=7
        
    com_sql1='select * from   moneyImpact.mst_portfolios where active<>False and pid='+str(pid)+' and uid='+str(uid)
     
    #print(com_sql1)
    df1 = pd.read_sql_query(com_sql1, engine)
    #df1 = df1.drop_duplicates()
    #print(df1.columns)
  
    df2=df1
 
    if len(df2)>0:
        df2 = df2.drop_duplicates()
        #df2.index.rename('ppid',inplace=True)
        df2.reset_index(drop=True, inplace=True)


    else:
        df2 = None
 
    
    #get investment 

    df3 = spec_pf_int_list(uid,pid,tbl_name)
    if len(df3) >0:
        df3 = df3.drop_duplicates()
        #df2.index.rename('ppid',inplace=True)
        df3.reset_index(drop=True, inplace=True)
        #df2 = df2.set_index(['pid', 'uid'],inplace=True)
        #print(df2.columns)
        #df2 = df2.drop(columns = ['pid'])
        #print(df3.columns)
        #keep the date format when to json
        
        #the currency number format
        df3['holding_amount'] = df3['holding_amount'].astype('int')
        #df3['holding_amount'] = ['{:,}'.format(i) for i in list(df3['holding_amount'])]
        #(12345.67).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); 
        #the currency number format
        df3['price'] = df3['price'].astype('float')
        #df3['price'] = ['{:,.2f}'.format(i) for i in list(df3['price'])]

 
    else:
        df3 = None
        
    #3. get currency list,will make it static later
    df4= get_currency_list(uid)
    if len(df4 )>0:
        df4 = df4.drop_duplicates()
        df4.reset_index(drop=True, inplace=True)

    else:
        df4=None 
 
    
    #4. get the asset code
    df5=  get_asset_list(uid,item_list_id)
    if len(df5 )>0:
        df5 = df5.drop_duplicates()
        df5.reset_index(drop=True, inplace=True)

    else:
        df5=None 

        
    
    return df3,df2,pid,pf_name,df4,df5 

#get special user news 
#1. keywords_lst is list type,
#2. uid is user id in the database
def get_mp_news(keywords_lst,uid):
    if len(keywords_lst)<1:
        return None
    #global setting
    #default_show=base_new_default.get('default3')[0]
    default_show=base_new_default.get('default4')[0]
    #default_show=base_new_default.get('default2')
    news_lst=None
    engine=get_conn()
    com_sql1=''
    pre_str1=''
    tmpr=''
 
 # 方法1 ,RLIKE,屏蔽了

#     #step 1, convert dataframe to list
#     pre_str1='|'.join(keywords_lst)
#     #step 2, filter the list
#     # 使用正则表达式去匹配标点符号
#     pre_str1 = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",pre_str1)
# 
#     pre_str1  = pre_str1.strip()   
#     #step 3,convert list to rlike string
#     if len(pre_str1)>0:
#         # 所有标点--result = re.sub("[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？、~@#￥%……&*（）]+", "",result)
#         ##pre_str1  = pre_str1.strip().replace(',', '|') 
#         pre_str1 = ' and category_id is not null and article RLIKE \'{}\' OR title  RLIKE \'{}\' order by article_positive desc {}'.format(pre_str1,pre_str1,default_show)
#         #pre_str1 = "|".join([x.repace(',','').strip() for x in pre_str1])
#     else:
#         #index page, 100 is enough
#         pre_str1=' and category_id is not null  limit 0,100 '
#     com_sql1 ='select b.news_id,category_id,n_source,n_link,author,n_date,title,article,n_img,b.article_spacy_sum,b.article_nltk_sum,b.article_gensim_sum,b.article_sumy_sum ,b.article_positive, b.article_negative, b.title_positive, b.title_negative from moneyImpact.nw_news a right join moneyImpact.nw_scores b on a.news_id =b.news_id where b.del_flag !=True  '
#     
    
#方法2，LIKE %S%
  
    pre_str1=''
    ttt=''
    tmprr=''
    for  xx in keywords_lst[1:]:
        tmprr=' or article like \'%{}%\' '.format(xx)
        ttt=ttt+tmprr
    pre_str1=' \'%'+keywords_lst[0]+'%\''+ttt
    ttt=''
    tmprr=''
    for  xx in keywords_lst[1:]:
        tmprr=' or title like \'%{}%\' '.format(xx)
        ttt=ttt+tmprr
    tmpr    =' \'%'+keywords_lst[0]+'%\' '+ttt
    #pre_str1=pre_str1+tmpr
 
    # 使用正则表达式去匹配标点符号
    pre_str1 = re.sub("[\s+\.\!\/$^*=(+\");\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥……&*；（）]+", " ",pre_str1)
    tmpr = re.sub("[\s+\.\!\/$^*=(+\");\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥……&*；（）]+", " ",tmpr)
 

    pre_str1  = pre_str1.strip()   
    #step 3,convert list to rlike string
    if len(pre_str1)>0:
        # 所有标点--result = re.sub("[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？、~@#￥%……&*（）]+", "",result)
        ##pre_str1  = pre_str1.strip().replace(',', '|') 
        pre_str1 = ' and category_id is not null and article LIKE {} OR title  LIKE {} order by article_positive desc {}'.format(pre_str1,tmpr,default_show)
        #pre_str1 = "|".join([x.repace(',','').strip() for x in pre_str1])
    else:
        #index page, 100 is enough
        pre_str1=' and category_id is not null  limit 0,100 '
    com_sql1 ='select b.news_id,category_id,n_source,n_link,author,n_date,title,article,n_img,b.article_spacy_sum,b.article_nltk_sum,b.article_gensim_sum,b.article_sumy_sum ,b.article_positive, b.article_negative, b.title_positive, b.title_negative from moneyImpact.nw_news a right join moneyImpact.nw_scores b on a.news_id =b.news_id where b.del_flag !=True  '
    





    
    #connect the keywords
    #values1='  '
    com_sql1=com_sql1+pre_str1
    print(com_sql1)
    try:
        news_lst = pd.read_sql_query(com_sql1, engine)
    except Exception as e:
        print(str(e)) 
        #return None
    
    #return
    return news_lst

#######get the news basic category list
def get_catey_list():
    #connect with DB
    engine =get_conn()
    com_sql1 =''
    df1=None

    com_sql1='SELECT * FROM moneyImpact.mst_news_category'

    #print(com_sql1)
    df1 = pd.read_sql_query(com_sql1, engine)
    df1 = df1.drop_duplicates()
    #print(df1.columns)
 
    return df1



#news index page,for one user
@app.route('/admin_train_data', methods=['GET', 'POST'])
def admin_train_data():
    for i in range(10):
        lang='Japan'
        chk_train_data('moneyp_train_temp.csv',lang)




#loss profits, index page,for one user, will need one pf name as begin
@app.route('/profits_idx', methods=['GET', 'POST'])
def profits_idx():
    uid=1
    pid=-1
    pf_name=''

    #the  'moneyImpact.mst_corporate_jp'
    tbl_name=base_dict.get('base_tbl')[0] 
    
    if request.method =='POST':
        #try to get the portfolio id
        try:
            opf_name = str(request.form.get('opf_name')).strip()
           
        except:
            print('not using now original pf name')
        try:
            pid = str(request.form.get('pid')).strip()

        except:    
            #will fetch all pf
            pid=-1
            print('wrong pid')
        
        #search the pf name 

      
    #GET method
    elif  request.method =='GET':
      #try to get the portfolio id
        try:
            opf_name = str( request.args.get('opf_name')).strip()
       
        except:
            print('not using now original pf name')

        try:
            pid = str( request.args.get('pid')).strip()

        except:    
            pid=-1
            print('wrong pid')

    else:
        return redirect(request.referrer or url_for('/pf_list'))
        
        
        

        


    return profits_result(pid ,pf_name,uid)







#news index page,for one user
@app.route('/news_index', methods=['GET', 'POST'])
def news_index():
    uid=1
    engine=get_conn()
    pid=0
    pf_name=''
    com_sql1=''
    keyword_lst=None
    
    kywd=[]

    #step 1. global setting
    default_show=base_new_default.get('default1')[0]
    #news show 策略1
    com_sql1='SELECT * FROM moneyImpact.mst_keyword where uid={} and active<>False  order by create_date '.format(uid)
    #default show
    com_sql1=com_sql1 + default_show
    print(com_sql1)
    
    try:
        keyword_lst = pd.read_sql_query(com_sql1, engine)
        #if too long ,have to cut it,
        if open_default:
            keyword_lst=keyword_lst[:-deflt_length]
        kywd=keyword_lst['keyword'].tolist()
    except Exception as e:
        print(str(e)) 
        #return None
    
        # new job 1
        # 'a common news index page will be created'
        kywd=['トヨタ自動車']
    return news_result(pid,pf_name,uid,kywd)

# special pf news page
#news  page,search one pf news 
@app.route('/mp_srch_pf', methods=['GET', 'POST'])
def mp_srch_pf():
    uid=1
    engine=get_conn()
    pid=0
    pf_name=''
    com_sql1=''
    keyword_lst=None
   
    kywd=[]

    #the  'moneyImpact.mst_corporate_jp'
    tbl_name=base_dict.get('base_tbl')[0] 
    
    if request.method =='POST':
        #try to get the portfolio id
        try:
            opf_name = str(request.form.get('opf_name')).strip()
           
        except:
            print('not using now original pf name')
        try:
            pid = str(request.form.get('pid')).strip()
            #pf_memo =  (flask.request.form['pf_memo']).strip()
            wrd = str(request.form.get('keyword')).strip()
        except:    
            return redirect(request.referrer or url_for('/news_index'))
        
        #search the pf name 
        try:
            df4=get_one_pf(uid,int(pid) )
            if len(df4)>0:
                pf_name= (df4['pf_name'][0])
            else:
                return redirect(request.referrer or url_for('/news_index'))
            print(pf_name)
        except:
            pf_name=''
            #return redirect("/pf_list")
      
    #GET method
    elif  request.method =='GET':
      #try to get the portfolio id
        try:
            opf_name = str( request.args.get('opf_name')).strip()
       
        except:
            print('not using now original pf name')
            return redirect(request.referrer or url_for('/news_index'))
        try:
            pid = str( request.args.get('pid')).strip()
            #pf_memo =  (flask.request.form['pf_memo']).strip()
            wrd = str( request.args.get('keyword')).strip()
        except:    
            return redirect(request.referrer or url_for('/news_index'))
        try:
            #search the pf name 
            df4=get_one_pf(uid,int(pid) )
            if len(df4)>0:
                pf_name= (df4['pf_name'][0])
            else:
                return redirect('/pf_list')
            print(pf_name)
        except:
            pf_name=''
            return redirect(request.referrer or url_for('/news_index'))
    else:
        return redirect(request.referrer or url_for('/news_index'))
        
        
        

    #step 1. global setting
    default_show=base_new_default.get('default1')[0]
    #news show 策略1
    com_sql1='SELECT * FROM moneyImpact.mst_keyword where uid={} and active<>False and pid={} '.format(uid,pid)
    #default show
    com_sql1=com_sql1 + default_show
    print(com_sql1)
    
    try:
        keyword_lst = pd.read_sql_query(com_sql1, engine)
        #no data 
        if len(keyword_lst)<1:
            print('Null investment')
            
            tbl_name=base_dict.get('base_tbl')[0]
            return sub_spec_pf_list(uid,pid,pf_name,tbl_name)

        kywd=keyword_lst['keyword'].tolist()
    except Exception as e:
        print(str(e)) 
        #return None
    
        # new job 1
        # 'a common news index page will be created'
        kywd=['トヨタ自動車']
    return news_result(pid,pf_name,uid,kywd)



#news details of article
@app.route('/mp_news_dtl', methods=['GET', 'POST'])
def mp_news_dtl():
    uid=1
    engine=get_conn()
    pid=0
    pf_name=''

    news_id=9


    if request.method =='GET':
        try:
            news_id = int( request.args.get('news_id'))
            
        except:    
            return redirect(request.referrer or url_for('/news_index'))
        
    elif request.method =='POST':
        try:
            news_id=  int(flask.request.form['news_id'])
        except:    
            return redirect(request.referrer or url_for('/news_index'))
    else:
        return redirect(request.referrer or url_for('/news_index'))    
   
    return sub_news_dtl(news_id,pid,uid,pf_name)


def sub_news_dtl(news_id,pid,uid,pf_name):
    json_pf=None
    json_caty=None

    news_json=None

    #step 2. get pf list again
    df3=None
    df3 = get_pf_list(uid,False)
    if len(df3 )>0:
        df3 = df3.drop_duplicates()
        #df2.index.rename('ppid',inplace=True)
        df3.reset_index(drop=True, inplace=True)
        #df2 = df2.set_index(['pid', 'uid'],inplace=True)
        #print(df2.columns)
        #df2 = df2.drop(columns = ['pid'])
        print(df3.columns)
        json_pf = json.loads(df3.to_json(orient='records'))
         
        #if not a valid value
        if pid==0:
            pf_name= (df3['pf_name'][0])
            pid =df3['pid'][0]
     
    else:
        json_pf=None
    df3=None
    
    # step 3, get the news list
    
    news_json= get_news_dtl(news_id)
    #news_json.to_csv('money_impact_news_temp1.csv',encoding='utf-8')
    print(news_json.columns)
    #keep the date format when to json
    try:
        news_json = news_json[~( news_json['article'].isnull() )]
    except:
        print('null clear failed')
    try:
        news_json['n_date']= pd.to_datetime(news_json['n_date'], errors='coerce')
        news_json['n_date'] = news_json['n_date'].dt.strftime('%Y-%m-%d')
    except:
        print('datetime format cleaning failed')
                        
    #iso of the datetime format, 
    news_json = json.loads(news_json.to_json(orient='records',date_format='iso'))
    
    
    #step 4. get the news category 
    df3=  get_catey_list()
    if len(df3)>0:
        df3 = df3.drop_duplicates()
        df3.reset_index(drop=True, inplace=True)

        print(df3.columns)
        json_caty = json.loads(df3.to_json(orient='records'))
    else:
        json_caty=None 
    df3=None 
        
    
    
    #json.dumps(lines1)
    print('ready to front page news detail')
 
    return flask.render_template('moneyimpact/news_dtl.html', pid=pid,pf_name=pf_name,lines1=news_json,lines2=json_pf,json_caty=json_caty)  




#the sub function of profits  
#calc profits and return to page
def profits_result(pid,pf_name,uid):   
    
    json_pf=None
    json_caty=None
    tbl_name=base_dict.get('base_tbl')[0]
    subs=False
    news_json=None
   
    if pid is None:
        return redirect(request.referrer or url_for('/pf_list'))
    
    if pid ==-1:
        print('display ll pf will develop later')
    else:
        try:
            json_pf=get_one_pf(uid,int(pid) )
            if len(json_pf)>0:
                pf_name= (json_pf['pf_name'][0])
      
            print(pf_name)
        except:
            pf_name=''
     
     
            json_pf=None
            #got one replacement name of portfolio    
            json_pf = get_pf_list(uid,False)
            if json_pf is not None:
                json_pf = json_pf.drop_duplicates()
                json_pf.reset_index(drop=True, inplace=True)
                pf_name= (json_pf['pf_name'][0])
                pid= (json_pf['pid'][0])
            #no pf values ,create a new please
            else:
                return redirect(request.referrer or url_for('/pf_list'))
    json_pf=None

    #got this returns value
    lines1,lines2,_,pf_name,json_currency,json_asset=get_one_pf_all(uid,int(pid),pf_name,tbl_name)

    
    # step 3, get the news list
    #according to the keyword table, fetch news from database
    #keyword is the 
    
    keyword_lst=None
    
    kywd=[]
    engine=get_conn()
    #step 1. global setting
    default_show=base_new_default.get('default1')[0]
    #news show 策略1
#     com_sql1='SELECT * FROM moneyImpact.mst_keyword where uid={} and pid={} and active<>False  order by create_date '.format(uid,pid)
#     #default show
#     com_sql1=com_sql1 + default_show
#     print(com_sql1)
#     
#     try:
#         keyword_lst = pd.read_sql_query(com_sql1, engine)
#         #if too long ,have to cut it,
#         if open_default:
#             keyword_lst=keyword_lst[:-deflt_length]
#         kywd=keyword_lst['keyword'].tolist()
#     except Exception as e:
#         print(str(e)) 
#         #return None
#     
#         # new job 1
#         # 'a common news index page will be created'
#         kywd=['トヨタ自動車']
        
        
    news_json=None
#     news_json= get_mp_news(kywd,int(uid))
#     #news_json.to_csv('money_impact_news_temp1.csv',encoding='utf-8')
#     #print(news_json.columns)
#     #keep the date format when to json
#     try:
#         news_json = news_json[~( news_json['article'].isnull() )]
#     except:
#         print('null clear failed')
#     try:
#         news_json['n_date']= pd.to_datetime(news_json['n_date'], errors='coerce')
#         news_json['n_date'] = news_json['n_date'].dt.strftime('%Y-%m-%d')
#     except:
#         print('datetime format cleaning failed')
#                         
#     #iso of the datetime format, 
#     if len(news_json)>0:
#         news_json = json.loads(news_json.to_json(orient='records',date_format='iso'))
#     else:
#         print('None news json')
    
    json_caty=None 
    #step 4. get the news category 
#     df3=  get_catey_list()
#     if len(df3)>0:
#         df3 = df3.drop_duplicates()
#         df3.reset_index(drop=True, inplace=True)
#  
#         print(df3.columns)
#         json_caty = json.loads(df3.to_json(orient='records'))
#     else:
#         json_caty=None 
#     df3=None 
     

    #json.dumps(lines1)
    print('ready to front page pf list')
    
 
    lines1 = mp_calc_profits(uid,pid,lines1)
 
 
    #get all pf list,
    #get pf list again

    #这个函数还要改造成所有的投资损益，
    lines3 = get_pf_list(uid,False)
    if len(lines3 )>0:
        lines3 = lines3.drop_duplicates()
        lines3.reset_index(drop=True, inplace=True)
        lines3['created_date'] = lines3['created_date'].dt.strftime('%Y-%m-%d')
        lines3['updated_date'] = lines3['updated_date'].dt.strftime('%Y-%m-%d')
        #iso of the datetime format, 
        lines3 = json.loads(lines3.to_json(orient='records',date_format='iso'))
    
    else:
        lines3=None
   
    #one pf json
    lines2['created_date'] = lines2['created_date'].dt.strftime('%Y-%m-%d')
    lines2['updated_date'] = lines2['updated_date'].dt.strftime('%Y-%m-%d')
    #iso of the datetime format, 
    lines2 = json.loads(lines2.to_json(orient='records',date_format='iso'))
    
    #pf investment list json    
    lines1['created_date'] = lines1['created_date'].dt.strftime('%Y-%m-%d')
    lines1['updated_date'] = lines1['updated_date'].dt.strftime('%Y-%m-%d')
    
    #the currency number format
    lines1['holding_amount'] = lines1['holding_amount'].astype('int')
    lines1['holding_amount'] = ['{:,}'.format(i) for i in list(lines1['holding_amount'])]
    #(12345.67).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); 
    #the currency number format
    lines1['price'] = lines1['price'].astype('float')
    lines1['price'] = ['{:,.2f}'.format(i) for i in list(lines1['price'])]
    
    
    #iso of the datetime format, 
    lines1 = json.loads(lines1.to_json(orient='records',date_format='iso'))
    
    json_currency = json.loads(json_currency.to_json(orient='records'))

    json_asset = json.loads(json_asset.to_json(orient='records'))
    
 
    return flask.render_template('moneyimpact/profits_idx.html', pid=pid,pf_name=pf_name,json_invest=lines1,json_news=news_json,json_pf=lines2,json_all_pf=lines3,json_caty=json_caty,json_asset=json_asset,json_currency=json_currency)  



####define the calculation of profits
#pid is not the essential para, but keep it now 
def mp_calc_profits(uid,pid,df2):
    #calculate the profits now 
    if df2 is None or uid is None:
        return None
 
    #columns
    print(df2.columns)
#     
#      ['company_name', 'pid', 'uid', 'pf_name', 'pf_news_subscribe',
#        'priority_level', 'active', 'created_date', 'updated_date',
#        'security_code', 'security_type', 'holding_amount', 'price',
#        'currency_code', 'acquisition_date', 'financial_institution_code',
#        'int_created_date', 'int_updated_date'],
#       dtype='object')
    
   
    df2['holding_amount'] = df2['holding_amount'].fillna(0).astype('int')
    #before processing 
    df2['price'] = df2['price'].fillna(0).astype('float')
    #get stock price of this date,input the security code as ticker close price index
    df2['price_now'] = df2['security_code'].apply(invest_now_price)
    
    df2['profits']=df2.apply(lambda x:profits_output( x.price,x.holding_amount,x.price_now),axis=1 )
    #df[['A','C']].apply(lambda x: my_func(x) if(np.all(pd.notnull(x[1]))) else x, axis = 1)

    #df2['profits']=df2.apply( lambda x: (x['price'])* (x['holding_amount'])-(x['price_now'])*(x['holding_amount']) if not (  np.all(pd.notnull(x['price'] ) ) and np.all(pd.notnull(x['holding_amount'] ) )  and np.all(pd.notnull(x['price_now'] ) ) ) else x , axis=1)
    
    #columns
    #print(df2.columns)
#     Index(['company_name', 'pid', 'uid', 'pf_name', 'pf_news_subscribe',
#        'priority_level', 'active', 'created_date', 'updated_date',
#        'security_code', 'security_type', 'holding_amount', 'price',
#        'currency_code', 'acquisition_date', 'financial_institution_code',
#        'int_created_date', 'int_updated_date', 'price_now', 'profits'],
#       dtype='object')

    print(str(df2['profits'].tolist()) )
    return df2

# return the date profits of  investment
def profits_output(x1,x2,x3):
    if (not x1 or not x2 or not x3):
        return None
    else:

        tmpn=float( float(x3)*int(x2) - float(x1)*int(x2) )
    
        return tmpn
    
# return the date price of investment
def invest_now_price(xx):
    if xx is None:
        return None
    engine =get_conn()
    com_sql1 =''
    df1=None
    now        =datetime.now()
    curr       =now.strftime('%Y-%m-%d')
    #testing data
    datet='2020-01-16'
    # moneyImpact.mkt_eqty_price  --1  tbl_name=base_dict.get('base_price')[0]
    tbl_name=base_dict.get('base_price')[0]
    #tbl_name=base_dict.get('base_tbl')[1]
    
    #print(str(xx))
    com_sql1='select close_price as price1 from  {}  where mkt_ticker_code={}  and mkt_date=\'{}\''.format(tbl_name,xx,datet)

    print(com_sql1+";")
    try:
        df1 = pd.read_sql_query(com_sql1, engine)
        df1 = df1.drop_duplicates()
    except:
        df1=None
    #print(df1.columns)
    if len(df1)>0:
        return float(df1.iloc[0, 0])
    else:
        return None


#define the profits calculation
def calc_profits(price_old,amount1,price_now):
    amount1=int(amount1)
    price_old=float(price_old)
    price_now=float(price_now)
    a1=price_old*amount1-price_now*amount1
#     a2=price_old*amount1
#     a3=price_now*amount1
    return a1


#the sub function of news searching process
#just a sub function of return to news page
def news_result(pid,pf_name,uid,kywd):   
    json_pf=None
    json_caty=None

    subs=False
    news_json=None
    
    
    #step 2. get pf list again
    df3=None
    df3 = get_pf_list(uid,False)
    if len(df3 )>0:
        df3 = df3.drop_duplicates()
        #df2.index.rename('ppid',inplace=True)
        df3.reset_index(drop=True, inplace=True)
        #df2 = df2.set_index(['pid', 'uid'],inplace=True)
        #print(df2.columns)
        #df2 = df2.drop(columns = ['pid'])
        print(df3.columns)
        json_pf = json.loads(df3.to_json(orient='records'))
         
        #if not a valid value
        if pid==0:
            pf_name= (df3['pf_name'][0])
            pid =df3['pid'][0]
     
    else:
        json_pf=None
    df3=None
    
    # step 3, get the news list
    #according to the keyword table, fetch news from database
    news_json= get_mp_news(kywd,uid)
    #news_json.to_csv('money_impact_news_temp1.csv',encoding='utf-8')
    #print(news_json.columns)
    #keep the date format when to json
    try:
        news_json = news_json[~( news_json['article'].isnull() )]
    except:
        print('null clear failed')
    try:
        news_json['n_date']= pd.to_datetime(news_json['n_date'], errors='coerce')
        news_json['n_date'] = news_json['n_date'].dt.strftime('%Y-%m-%d')
    except:
        print('datetime format cleaning failed')
                        
    #iso of the datetime format, 
    if len(news_json)>0:
        news_json = json.loads(news_json.to_json(orient='records',date_format='iso'))
    else:
        print('None news json')
    
    
    #step 4. get the news category 
    df3=  get_catey_list()
    if len(df3)>0:
        df3 = df3.drop_duplicates()
        df3.reset_index(drop=True, inplace=True)

        print(df3.columns)
        json_caty = json.loads(df3.to_json(orient='records'))
    else:
        json_caty=None 
    df3=None 
        
    #if a search string
    if len(kywd)==1:
        wrd1=kywd[0]
    # a list
    else:
        wrd1=''
    #json.dumps(lines1)
    print('ready to front page pf list')
 
    return flask.render_template('moneyimpact/news_index.html', pid=pid,pf_name=pf_name,wrd1=wrd1,lines1=news_json,lines2=json_pf,json_caty=json_caty)  


#searching the keywords in investment table
# this is first version, only search the stock
#searching in the table of mst_corporate_jp
@app.route('/mp_srch_news',methods=['GET','POST'])
def mp_srch_news():
    uid=1
    pid=0
    pf_name=''
    wrd=''
    kywd=[]
    
    if request.method =='GET':
        try:
            wrd = str( request.args.get('keyword')).strip()
            
        except:    
            return redirect(request.referrer or url_for('/news_index'))
        
    elif request.method =='POST':
        try:
            wrd=  (str(flask.request.form['keyword'])).strip()
        except:    
            return redirect(request.referrer or url_for('/news_index'))
    else:
        return redirect(request.referrer or url_for('/news_index'))        
             
    if len(wrd)<1:
        return redirect(request.referrer or url_for('/news_index'))
    else:
        kywd.append(wrd)                    
    return news_result(pid,pf_name,uid,kywd)
        







#now is the  main index page
#portfolio list table
@app.route('/pf_list', methods=['GET', 'POST'])
def pf_list():
    uid=1
    df2 = get_pf_list(uid,True)
    if df2 is not None:
        df2 = df2.drop_duplicates()
        #df2.index.rename('ppid',inplace=True)
        df2.reset_index(drop=True, inplace=True)
        #df2 = df2.set_index(['pid', 'uid'],inplace=True)
        #print(df2.columns)
        #df2 = df2.drop(columns = ['pid'])
        print(df2.columns)
        #keep the date format when to json
        df2['created_date'] = df2['created_date'].dt.strftime('%Y-%m-%d')
        df2['updated_date'] = df2['updated_date'].dt.strftime('%Y-%m-%d')
        #iso of the datetime format, 
        lines1 = json.loads(df2.to_json(orient='records',date_format='iso'))
    else:
        lines1 = None
        
        
    df2 = get_pf_list(uid,False)
    if df2 is not None:
        df2 = df2.drop_duplicates()
        #df2.index.rename('ppid',inplace=True)
        df2.reset_index(drop=True, inplace=True)
        #df2 = df2.set_index(['pid', 'uid'],inplace=True)
        #print(df2.columns)
        #df2 = df2.drop(columns = ['pid'])
        print(df2.columns)
        #keep the date format when to json
        df2['created_date'] = df2['created_date'].dt.strftime('%Y-%m-%d')
        df2['updated_date'] = df2['updated_date'].dt.strftime('%Y-%m-%d')
        #iso of the datetime format, 
        lines2 = json.loads(df2.to_json(orient='records',date_format='iso'))
    else:
        lines2= None

    print('ready to front page pf list')
 
    return flask.render_template('moneyimpact/pf_list.html', lines1=lines1,lines2=lines2)  

@app.route('/new_pf', methods=['GET', 'POST'])
def new_pf():
    if  flask.request.method == 'POST':
        subs=False
        uid='1'
        opert=False
        pf_name =  flask.request.form['pf_name']
        priority =  flask.request.form['level1']
        try:
            stepflag =  flask.request.form['stepflags']
        except:
            stepflag ='1'
            
        try:
            subscribe =  flask.request.form['subscribe']
        except:
            subscribe ='0'
        
        if subscribe =='1':
            subs=1
        else:
            subs=0
        print(str(subscribe))
        now        =datetime.now()
        curr       =now.strftime('%Y-%m-%d')

        opert=a_new_pf(uid, pf_name,subs,priority,'1',curr,curr)
       
        #get pf list again

    return redirect('/pf_list')


#step 3, commit investment to one pf table and sub table
#20210426,modify it to ajax json function
@app.route('/new_invest', methods=['GET', 'POST'])
def new_invest():
  
    tbl_name=base_dict.get('base_tbl')[0]  #'moneyImpact.mst_corporate_jp'
    base_curr= base_dict.get('base_currency')[0]
    if  flask.request.method == 'POST':
        subs=False
        uid='1'
        pf_name=''
        opert=False
        addway=1
        

#     firstname = request.form['firstname']
#     lastname = request.form['lastname']
#     d = {'name': firstname + ' ' + lastname, 'age': 18}
#     print(d)
#     return jsonify(d)

        try:
            addway=  int(flask.request.form['addway'])
            print(str(addway))
           
        except:
            addway=1
        
        df4=None
        try:
            pid =  flask.request.form['hd_pflst']
        except:
            #because no Portfolio,please create it firstly.
            return flask.render_template('moneyimpact/pf_list.html')
        try:
            wrd1 =  flask.request.form['wrd1']
        except:
            
            wrd1=None
            
            
        print(pid)

#                      <option value="1" valid="true"> 株 </option>                 
#                      <option value="2" valid="true"> 債券 </option>                     
#                      <option value="3" valid="true"> 投信 </option>               
#                      <option value="4" valid="true"> 暗号資産 </option>

              
        try:
            assettype =  flask.request.form['assettype']
        except:
            assettype = 1
        try:
            code1=  flask.request.form['code1']
            company_name=  flask.request.form['company_name']
        except:
            return redirect('/pf_list')
      
        print(code1)
        #name1=  flask.request.form['name1']
        try:
            amount1=  (flask.request.form['amount1']).strip()
            amount1=int(amount1)
        except:
            amount1=0
        try:
            price1=  (flask.request.form['price1']).strip()
            price1=float(price1)
            
        except:
            price1=0


  
        now        =datetime.now()
        curr       =now.strftime('%Y-%m-%d')

        opert=a_new_invest(uid,addway,pid,code1,company_name,assettype,amount1,price1,base_curr,curr,'',curr,curr)

        # pid int(11) PK 
        # security_code varchar(12) PK 
        # security_type tinyint(4) PK 
        # holding_amount int(11) 
        # price decimal(10,2) 
        # currency_code char(3) 
        # acquisition_date datetime 
        # financial_institution_code char(4) 
        # int_created_date datetime 
        # int_updated_date
      

        #stepflags=int(stepflag)+1
        #stay in stage 2,untill another button of finished be clicked
     
        #get pf list again
        if not wrd1:
            return redirect('/pf_list')
        #back to search result
        else:

            d = {'opert': opert}
            return jsonify(d)
#             df4=get_one_pf(uid,pid)
#             if len(df4)>0:
#                 pf_name= (df4['pf_name'][0])
#             else:
#                 return redirect('/pf_list')
#             print(pf_name)
#             
#             return sub_search_int(pid,pf_name,uid,wrd1)     

            

#########edit one portfolio investment################
###edit it ,with the pid and ticker and type
#step 3, commit investment to one pf table and sub table
@app.route('/mp_rmv_int', methods=['GET', 'POST'])
def mp_rmv_int():
    if  flask.request.method == 'GET':
        subs=False
        uid='1'
        tbl_name='moneyImpact.mst_corporate_jp'
        opert=False
        try:
            pid = request.args.get('pid')
            code1 = request.args.get('ticker')
            assettype = request.args.get('asset')
            pf_name=request.args.get('pf_name')
        except:
            print('request args fail')

        opert = mp_rmv_int_run(pid, code1,assettype)
        #return to this pf name list
        return  sub_spec_pf_list(uid,pid,pf_name,tbl_name)   
     
    return redirect('/pf_list')

###########edit pf invest #############
###################
#step 3, commit investment to one pf table and sub table
@app.route('/mp_edit_int', methods=['GET', 'POST'])
def mp_edit_int():
    if  flask.request.method == 'POST':
        subs=False
        uid='1'
        opert=False

        addway=1
   
        try:
            addway=  int(flask.request.form['addway'])
            print(str(addway))
        except Exception as e:
            print(str(e))
            d = {'name': 'xmr', 'age': 18}
            return jsonify(d)
        
        
        try:
            pid =  flask.request.form['pid1']
            pf_name =  flask.request.form['pf_name']
            assettype =  flask.request.form['assettype']
            code1=  flask.request.form['code1']
            amount1=  flask.request.form['amount1']
            price1=  flask.request.form['price1']
            currency1=flask.request.form['currency1']
            #filer symbol
            price1 = re.sub("[\s+\,\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", "",price1)
            amount1 = re.sub("[\s+\,\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", "",amount1)
        except Exception as e:
            print(str(e))
            return redirect('/pf_list')

        print(pid)
        print(code1)


        now        =datetime.now()
        curr       =now.strftime('%Y-%m-%d')

        
        opert = up_new_invest(addway,pid, code1,assettype,int(amount1),float(price1),currency1,'','','',curr )
        d = {'name': 'xmr', 'age': 18}
        return jsonify(d)
    
        #return  sub_spec_pf_list(uid,pid,pf_name)

    # GET METHOD
    else:
        print('not supporting function calling')

        return redirect('/pf_list')

###########remove pf invest #############
###################
#step 3, commit investment to one pf table and sub table
@app.route('/mp_rmv_pf', methods=['GET', 'POST'])
def mp_rmv_pf():
    if  flask.request.method == 'POST':
        addway=0
        uid='1'
        opert=False
        try:
            pid =  flask.request.form['pid']
            pfname =  flask.request.form['pfname']
  
            addway=  int(flask.request.form['addway'])
            print(str(addway))

        except Exception as e:
            print(str(e))
            return redirect('/pf_list')
        now        =datetime.now()
        curr       =now.strftime('%Y-%m-%d')       
       
        opert = up_new_pf(addway,pid,'', pfname,0,'',curr )
#         d = {'name': 'xmr', 'age': 18}
#         return jsonify(d)
        return redirect('/pf_list')

###########edit pf invest #############
###################
#step 3, commit investment to one pf table and sub table
@app.route('/mp_edit_pf', methods=['GET', 'POST'])
def mp_edit_pf():
    if  flask.request.method == 'POST':
        subs=False
        uid='1'
        opert=False
        pf_memo=''
        addway=1
        try:
            pid =  flask.request.form['pid1']
            pfname =  flask.request.form['pfname1']
            #original pf name
            opf_name =  flask.request.form['opf_name']
            try:
                sub1 =  flask.request.form['sub1']
                if sub1=='on':
                    sub1=1
                else:
                    sub1=0
            except:
                sub1= False
                return redirect('/pf_list')
            try:
                addway=  int(flask.request.form['addway'])
                print(str(addway))
            except:
                addway=1
            
            if sub1:
                subs=True
            else:
                subs=False
            try:
                pf_memo =  (flask.request.form['pf_memo']).strip()
            except:
                pf_memo=''
        except Exception as e:
            print(str(e))
            return redirect('/pf_list')
        now        =datetime.now()
        curr       =now.strftime('%Y-%m-%d')
        opert = up_new_pf(addway,pid,opf_name, pfname,subs,pf_memo,curr )
        d = {'name': 'xmr', 'age': 18}
        return jsonify(d)
        return sub_spec_pf_list(uid,pid,pfname)
    # GET METHOD
    else:
        print('not supporting function calling')
     
    return redirect('/pf_list')


###the supporting search sub function of money impact#######
#abstract the public part, reuse it    .search key word from db
def sub_sch_int(wrd,tbl_name):
    pre_str1=str(wrd).strip()
    engine =get_conn()
    df3 = None  
    com_sql1=''

 
    if pre_str1 is  None:
        return None
  

        # 使用正则表达式去匹配标点符号
    pre_str1 = re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！●，。？、~@#￥%……&*；（）]+", " ",pre_str1)
        #cc1=re.sub("[\s+\.\!\/$%^*=(+\"\');\[\]{}]+|[+——()?【】“”‘’！，。？、~@#￥%……&*；（）]+", "",cc1)
        #print(cc1)
    if len(pre_str1)>0:   
        # 所有标点--result = re.sub("[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？、~@#￥%……&*（）]+", "",result)
        ##########pre_str1  = pre_str1.strip().replace(',', '|')
        pre_str1 = "  WHERE   a.mkt_ticker_code  Like   '%%%%%s%%%%'   or  a.company_name Like '%%%%%s%%%%'  "%(pre_str1,pre_str1)
        
    #pre_str1 = "|".join([x.repace(',','').strip() for x in pre_str1])
    
    else:
        #index page, 100 is enough
        pre_str1=' limit 0,100 '

    
    engine =get_conn()
    #del_flag  this record had been filter by user
    #with a left join filter, if no pid (pid is null ,that means not a investment in the portfolio)
    
    #1. 考虑加入其它数据表
    
    
    #2. 考虑 ，加入货币符号表
    
    
    com_sql1 ='select  a.mkt_ticker_code,a.company_name,a.industry_name,a.industry_code,b.* from  '+tbl_name+' as a  left join moneyImpact.trs_portfolio_details  as b  on a.mkt_ticker_code=b.security_code '+ pre_str1

    print(com_sql1)
    df3 = pd.read_sql_query(com_sql1, engine)
    return df3



#searching the keywords in investment table
# this is first version, only search the stock
#searching in the table of mst_corporate_jp
@app.route('/search_int',methods=['GET','POST'])
def search_int():
    uid=1
    pid=0
    pf_name=''
    wrd=''
    json_pf=None
    json_ticker=None
    opf_name=''
    item_list_id=7
    

    #the  'moneyImpact.mst_corporate_jp'
    tbl_name=base_dict.get('base_tbl')[0] 
    
    if request.method =='POST':
        #try to get the portfolio id
        try:
            opf_name = str(request.form.get('opf_name')).strip()
           
        except:
            print('not using now original pf name')
        try:
            pid = str(request.form.get('pid')).strip()
            #pf_memo =  (flask.request.form['pf_memo']).strip()
            wrd = str(request.form.get('keyword')).strip()
        except:    
            return redirect('/pf_list')
        try:
            #search the pf name 
            df4=get_one_pf(uid,int(pid) )
            if len(df4)>0:
                pf_name= (df4['pf_name'][0])
            else:
                return redirect('/pf_list')
            print(pf_name)
        except:
            pf_name=''
            #return redirect("/pf_list")
      
        return sub_search_int(pid,pf_name,uid,wrd,item_list_id,tbl_name)
    #GET method
    elif  request.method =='GET':
      #try to get the portfolio id
        try:
            opf_name = str( request.args.get('opf_name')).strip()
       
        except:
            print('not using now original pf name')
        try:
            pid = str( request.args.get('pid')).strip()
            #pf_memo =  (flask.request.form['pf_memo']).strip()
            wrd = str( request.args.get('keyword')).strip()
        except:    
            return redirect('/pf_list')
        try:
            #search the pf name 
            df4=get_one_pf(uid,int(pid) )
            if len(df4)>0:
                pf_name= (df4['pf_name'][0])
            else:
                return redirect('/pf_list')
            print(pf_name)
        except:
            pf_name=''
            return redirect("/pf_list")
      
        return sub_search_int(pid,pf_name,uid,wrd,item_list_id,tbl_name)
        
        
        
    else:
        return redirect('/pf_list')
    
#get the currency symbols
def get_currency_list(uid):
    #connect with DB
    if not uid:
        return None
    
    engine =get_conn()
    com_sql1 =''
    df1=None

    com_sql1='SELECT currency_code,currency_name FROM moneyImpact.mst_currency'
    #print(com_sql1)
    df1 = pd.read_sql_query(com_sql1, engine)
    df1 = df1.drop_duplicates()
    print(df1.columns)
 
    return df1
    

#get the asset symbols
def get_asset_list(uid,item_list_id):
    #connect with DB
    if not uid:
        return None
    
    engine =get_conn()
    com_sql1 =''
    df1=None

    com_sql1='SELECT item_list_id,data_value,display_name FROM moneyImpact.mst_item_list WHERE item_list_id={}'.format(item_list_id)
    #print(com_sql1)
    df1 = pd.read_sql_query(com_sql1, engine)
    df1 = df1.drop_duplicates()
    print(df1.columns)
 
    return df1
    


###sub search instance            
def sub_search_int(pid,pf_name,uid,wrd,item_list_id,tbl_name):
    if pid is None:
        pid=0
        pf_name=''
    if pid =='None':
        pid=0
        pf_name=''
        
    #1. search content
    df2= sub_sch_int(wrd,tbl_name)
    if df2 is not None:
        df2 = df2.drop_duplicates()
       
        df2.reset_index(drop=True, inplace=True)
     
     
        #the currency number format
      
        df2['holding_amount'] = df2['holding_amount'].fillna(0).astype('int')
        df2['holding_amount'] = ['{:,}'.format(i) for i in list(df2['holding_amount'])]
        #(12345.67).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); 
        #the currency number format
        df2['price'] = df2['price'].fillna(0).astype('float')
        df2['price'] = ['{:,.2f}'.format(i) for i in list(df2['price'])]
     
     
        #print(df2.columns)
        json_ticker = json.loads(df2.to_json(orient='records'))
       

    else:
        json_ticker=None
    df2=None   
    
    #2 . get pf list again
    df3 = get_pf_list(uid,False)
    if len(df3 )>0:
        df3 = df3.drop_duplicates()
        #df2.index.rename('ppid',inplace=True)
        df3.reset_index(drop=True, inplace=True)
        #df2 = df2.set_index(['pid', 'uid'],inplace=True)
        #print(df2.columns)
        #df2 = df2.drop(columns = ['pid'])
        print(df3.columns)
        json_pf = json.loads(df3.to_json(orient='records'))
        
        #if not a valid value
        if pid==0:
            pf_name= (df3['pf_name'][0])
            pid =df3['pid'][0]
    
    else:
        return redirect('/')
    df3=None
    
    #3. get currency list,will make it static later
    df4= get_currency_list(uid)
    if len(df4 )>0:
        df4 = df4.drop_duplicates()
        df4.reset_index(drop=True, inplace=True)

        print(df4.columns)
        json_currency = json.loads(df4.to_json(orient='records'))
    else:
        json_currency=None 
        
    df4=None     
   
    #4. get the asset code
    df4=  get_asset_list(uid,item_list_id)
    if len(df4 )>0:
        df4 = df4.drop_duplicates()
        df4.reset_index(drop=True, inplace=True)

        print(df4.columns)
        json_asset = json.loads(df4.to_json(orient='records'))
    else:
        json_asset=None 
    df4=None 


        
    return flask.render_template('moneyimpact/pf_srch_result_add.html', pid=pid,pf_name=pf_name,lines2=json_pf,lines3=json_ticker,wrd1=wrd,json_currency=json_currency, json_asset=json_asset) 





### searching result of company will be added


###############append one invest to a portfolio
@app.route('/mp_add_invest',methods=['GET','POST'])
def mp_add_invest():
    
#opert=a_new_invest(pid,code1,assettype,amount1,price1,'Y',curr,'',curr,curr)
    return None


########### money impact end ###################
if __name__ == '__main__':

    app.debug = False
    #progress bar ,db scraping 多线程,否则其他用户无法使用.

    #important for te user auth
    #app.config['MYSQL_DATABASE_CHARSET'] = 'utf8mb4'
    app.secret_key = "VatsalParsaniya"
    app.run(host='0.0.0.0')

